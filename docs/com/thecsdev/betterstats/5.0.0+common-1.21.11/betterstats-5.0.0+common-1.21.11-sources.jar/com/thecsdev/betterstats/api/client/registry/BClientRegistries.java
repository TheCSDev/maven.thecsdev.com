package com.thecsdev.betterstats.api.client.registry;

import com.thecsdev.betterstats.BetterStats;
import com.thecsdev.betterstats.api.mcbs.view.menubar.MenubarItem;
import com.thecsdev.betterstats.api.mcbs.view.statsview.StatsView;
import com.thecsdev.betterstats.mcbs.view.menubar.MenubarItemAbout;
import com.thecsdev.betterstats.mcbs.view.menubar.MenubarItemFile;
import com.thecsdev.betterstats.mcbs.view.menubar.MenubarItemView;
import com.thecsdev.betterstats.mcbs.view.statsview.*;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2370;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import static com.mojang.serialization.Lifecycle.stable;
import static com.thecsdev.betterstats.BetterStats.MOD_ID;
import static net.minecraft.class_2960.method_60655;
import static net.minecraft.class_5321.method_29180;

/**
 * {@link BetterStats}'s client-sided registries for adding features to the mod.
 * <p>
 * <b>Important note:</b><br>
 * These {@link class_2378}s are <b>NOT</b> registered in the game's <b>ROOT</b>
 * {@link class_7923#field_41167}! Avoid any and all operations that involve
 * the game's <b>ROOT</b> registry!
 */
@Environment(EnvType.CLIENT)
public class BClientRegistries
{
	// ==================================================
	private BClientRegistries() {}
	// ==================================================
	public static final class_2378<MenubarItem> MENUBAR_ITEM;
	public static final class_2378<StatsView>   STATS_VIEW;
	// ==================================================
	public static final void bootstrap() { /*invokes <clinit>*/ }
	static
	{
		//create registry instances
		STATS_VIEW   = new class_2370<>(method_29180(id("stats_view")), stable());
		MENUBAR_ITEM = new class_2370<>(method_29180(id("menubar_item")), stable());

		//register menubar items
		class_2378.method_10230(MENUBAR_ITEM, id("file"),  MenubarItemFile.INSTANCE);
		class_2378.method_10230(MENUBAR_ITEM, id("view"),  MenubarItemView.INSTANCE);
		class_2378.method_10230(MENUBAR_ITEM, id("about"), MenubarItemAbout.INSTANCE);

		//register stats views
		class_2378.method_10230(STATS_VIEW, id("general"), StatsViewGeneral.INSTANCE);
		class_2378.method_10230(STATS_VIEW, id("items"),   StatsViewItems.INSTANCE);
		class_2378.method_10230(STATS_VIEW, id("blocks"),  StatsViewBlocks.INSTANCE);
		class_2378.method_10230(STATS_VIEW, id("mobs"),    StatsViewMobs.INSTANCE);
		class_2378.method_10230(STATS_VIEW, id("food"),    StatsViewFood.INSTANCE);
		class_2378.method_10230(STATS_VIEW, id("hunter"),  StatsViewHunter.INSTANCE);
	}
	// --------------------------------------------------
	private static final @ApiStatus.Internal class_2960 id(@NotNull String id) {
		return method_60655(MOD_ID, id);
	}
	// ==================================================
}
