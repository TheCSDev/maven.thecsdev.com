package com.thecsdev.betterstats.api.mcbs.model;

import com.mojang.serialization.Codec;
import com.thecsdev.commonmc.api.stats.IStatsProvider;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3445;
import net.minecraft.class_3448;
import net.minecraft.class_7923;

/**
 * Container for holding statistics values, used by {@link McbsFile}.
 */
public final class McbsStats implements IStatsProvider
{
	// ================================================== ==================================================
	//                                          McbsStats IMPLEMENTATION
	// ================================================== ==================================================
	private final @NotNull ConcurrentHashMap<class_2960, ConcurrentHashMap<class_2960, Integer>> intStats;
	// ==================================================
	//cannot be instantiated by outsiders. is bound to its corresponding file
	McbsStats() { this(new ConcurrentHashMap<>()); }
	private McbsStats(
			@NotNull ConcurrentHashMap<class_2960, ConcurrentHashMap<class_2960, Integer>> intStats)
			throws NullPointerException
	{
		//the map must be truly independent and not associated with any other instances
		this.intStats = Objects.requireNonNull(intStats);
	}
	// ==================================================
	/**
	 * Clears redundant statistic data like zero-value entries and empty maps.
	 */
	private final @ApiStatus.Internal void cleanUp()
	{
		//remove zero-value statistic entries
		for(final var statTypeEntry : this.intStats.entrySet())
			statTypeEntry.getValue().entrySet().removeIf(e -> e.getValue() == 0);
		//remove empty stat-type maps
		this.intStats.entrySet().removeIf(e -> e.getValue().isEmpty());
	}
	// ==================================================
	/**
	 * Returns raw direct access to the main {@link Map} that holds all
	 * integer-based statistics values.
	 */
	public final @NotNull ConcurrentHashMap<class_2960, ConcurrentHashMap<class_2960, Integer>> getIntValues() {
		cleanUp();
		return this.intStats;
	}

	/**
	 * Returns the {@link Map} that contains integer-based statistics values for
	 * a given {@link class_3448}.
	 * @param type The {@link class_3448}'s unique identifier.
	 * @throws NullPointerException If the argument is {@code null}.
	 */
	public final @NotNull ConcurrentHashMap<class_2960, Integer> getIntValues(
			@NotNull class_2960 type) throws NullPointerException
	{
		Objects.requireNonNull(type);
		cleanUp();
		return this.intStats.computeIfAbsent(type, __ -> new ConcurrentHashMap<>());
	}
	// ==================================================
	/**
	 * Returns the value of a given integer-based statistic.
	 * @param stat The {@link class_3445} whose value is to be returned.
	 * @throws NullPointerException If the argument is {@code null}.
	 * @throws IllegalStateException If a corresponding feature is not registered.
	 */
	public final @Override <T> int getIntValue(@NotNull class_3445<T> stat) throws NullPointerException {
		return getIntValue(stat.method_14949(), stat.method_14951());
	}

	/**
	 * Returns the value of a given integer-based statistic.
	 * @param type The {@link class_3448}.
	 * @param subject The statistic subject.
	 * @throws NullPointerException If an argument is {@code null}.
	 * @throws IllegalStateException If a corresponding feature is not registered.
	 */
	public final @Override <T> int getIntValue(@NotNull class_3448<T> type, @NotNull T subject)
			throws NullPointerException, IllegalStateException
	{
		//obtain id-s from registries
		final @Nullable var statTypeId    = class_7923.field_41193.method_10221(Objects.requireNonNull(type));
		final @Nullable var statSubjectId = type.method_14959().method_10221(Objects.requireNonNull(subject));
		//ensure the id-s are not null
		if(statTypeId == null)
			throw new IllegalStateException("StatType not registered: " + type);
		else if(statSubjectId == null)
			throw new IllegalStateException("Feature not registered: " + subject);
		//get and return the stat value
		return getIntValue(statTypeId, statSubjectId);
	}

	/**
	 * Returns the value of a given integer-based statistic.
	 * @param type The {@link class_3448}'s unique identifier.
	 * @param subject The statistic subject's unique identifier.
	 * @throws NullPointerException If an argument is {@code null}.
	 */
	public final int getIntValue(@NotNull class_2960 type, @NotNull class_2960 subject)
			throws NullPointerException {
		return getIntValues(Objects.requireNonNull(type)).getOrDefault(Objects.requireNonNull(subject), 0);
	}
	// ==================================================
	/**
	 * Sets the value of a given integer-based statistic.
	 * @param stat The {@link class_3445} whose value is to be set.
	 * @param value The value to set.
	 * @throws NullPointerException If the argument is {@code null}.
	 */
	public final <T> void setIntValue(@NotNull class_3445<T> stat, int value) throws NullPointerException {
		setIntValue(stat.method_14949(), stat.method_14951(), value);
	}

	/**
	 * Sets the value of a given integer-based statistic.
	 * @param type The {@link class_3448}.
	 * @param subject The statistic subject.
	 * @param value The value to set.
	 * @throws NullPointerException If an argument is {@code null}.
	 * @throws IllegalStateException If a corresponding feature is not registered.
	 */
	public final <T> void setIntValue(
			@NotNull class_3448<T> type, @NotNull T subject, int value)
			throws NullPointerException, IllegalStateException
	{
		//obtain id-s from registries
		final @Nullable var statTypeId    = class_7923.field_41193.method_10221(Objects.requireNonNull(type));
		final @Nullable var statSubjectId = type.method_14959().method_10221(Objects.requireNonNull(subject));
		//ensure the id-s are not null
		if(statTypeId == null)
			throw new IllegalStateException("StatType not registered: " + type);
		else if(statSubjectId == null)
			throw new IllegalStateException("Feature not registered: " + subject);
		//set the stat value
		setIntValue(statTypeId, statSubjectId, value);
	}

	/**
	 * Sets the value of a given integer-based statistic.
	 * @param type The {@link class_3448}'s unique identifier.
	 * @param subject The statistic subject's unique identifier.
	 * @param value The value to set.
	 * @throws NullPointerException If an argument is {@code null}.
	 */
	public final void setIntValue(
			@NotNull class_2960 type, @NotNull class_2960 subject, int value)
			throws NullPointerException
	{
		if(value == 0) {
			final var map = getIntValues(Objects.requireNonNull(type));
			map.remove(Objects.requireNonNull(subject));
			if(map.isEmpty()) this.intStats.remove(type);
		}
		else getIntValues(Objects.requireNonNull(type)).put(Objects.requireNonNull(subject), value);
	}
	// ==================================================
	/**
	 * Adds {@link class_3445} entries from another {@link IStatsProvider} into this one,
	 * summing up values where applicable. Supports {@link McbsStats} instances as
	 * argument.
	 * @param statsProvider The other {@link IStatsProvider}.
	 * @throws NullPointerException If the argument is {@code null}.
	 */
	@SuppressWarnings("unchecked")
	public final void addAll(@NotNull IStatsProvider statsProvider)
	{
		//argument not null check
		Objects.requireNonNull(statsProvider);
		//handle mcbs stats providers by adding all their values here
		if(statsProvider instanceof McbsStats other) {
			other.forEach((statTypeId, statSubjectId, otherValue) -> {
				final int thisValue = getIntValue(statTypeId, statSubjectId);
				setIntValue(statTypeId, statSubjectId, thisValue + otherValue);
			});
			return;
		}
		//handle all other stat provider types by iterating game's registries
		//and querying values manually
		for(final var statType : (class_2378<class_3448<Object>>)(Object) class_7923.field_41193) {
			for(final var statSubject : statType.method_14959()) {
				//get value and add it to this mcbs stats provider
				final int otherValue = statsProvider.getIntValue(statType, statSubject);
				if(otherValue == 0) continue;
				final int thisValue = getIntValue(statType, statSubject);
				setIntValue(statType, statSubject, thisValue + otherValue);
			}
		}
	}

	/**
	 * Clears all existing {@link class_3445} entries and adds all entries from
	 * another {@link IStatsProvider}.
	 * @param statsProvider The other {@link IStatsProvider}.
	 * @throws NullPointerException If the argument is {@code null}.
	 */
	public final void clearAndAddAll(@NotNull IStatsProvider statsProvider) throws NullPointerException {
		Objects.requireNonNull(statsProvider);
		if(statsProvider == this) return;
		clear();
		addAll(statsProvider);
	}
	// ==================================================
	/**
	 * Clears all statistics data.
	 */
	public final void clear() { this.intStats.clear(); }
	// --------------------------------------------------
	/**
	 * Iterates all integer values stored in this {@link McbsStats} instance.
	 * Note that this does not offer value manipulation capabilities.
	 * @param consumer The consumer that will consume each value.
	 * @throws NullPointerException If the argument is {@code null}.
	 */
	public final void forEach(@NotNull McbsStats.IntValueConsumer consumer) throws NullPointerException
	{
		Objects.requireNonNull(consumer);
		cleanUp();
		for(final var statTypeEntry : this.intStats.entrySet()) {
			final var statTypeId = statTypeEntry.getKey();
			for(final var statSubjectEntry : statTypeEntry.getValue().entrySet()) {
				final var statSubjectId = statSubjectEntry.getKey();
				final int value = statSubjectEntry.getValue();
				consumer.accept(statTypeId, statSubjectId, value);
			}
		}
	}
	// ================================================== ==================================================
	//                                   IntEntryConsumer IMPLEMENTATION
	// ================================================== ==================================================
	/**
	 * {@link FunctionalInterface} for consuming integer values stored in an
	 * {@link McbsStats} instance.
	 * @see #forEach(IntValueConsumer)
	 */
	public static @FunctionalInterface interface IntValueConsumer
	{
		/**
		 * Consumes a single {@link class_3445} entry.
		 * @param statType The {@link class_3448}'s unique identifier.
		 * @param statSubject The {@link class_3445} subject's unique identifier.
		 * @param value The {@link class_3445}'s value.
		 * @throws NullPointerException If an argument is {@code null}.
		 */
		void accept(@NotNull class_2960 statType, @NotNull class_2960 statSubject, int value);
	}
	// ================================================== ==================================================
	//                                              Codec IMPLEMENTATION
	// ================================================== ==================================================
	/**
	 * {@link Codec} implementation for {@link #intStats}.
	 */
	@ApiStatus.Internal
	private static final Codec<ConcurrentHashMap<class_2960, ConcurrentHashMap<class_2960, Integer>>> CODEC_INT_STATS =
			Codec.unboundedMap(class_2960.field_25139, Codec.unboundedMap(class_2960.field_25139, Codec.INT))
					.xmap(map -> {
						final var root = new ConcurrentHashMap<class_2960, ConcurrentHashMap<class_2960, Integer>>();
						map.forEach((k, v) -> root.put(k, new ConcurrentHashMap<>(v)));
						return root;
					}, ConcurrentHashMap::new);

	/**
	 * {@link Codec} implementation for {@link McbsStats}.
	 */
	@ApiStatus.Internal
	static final Codec<McbsStats> CODEC = CODEC_INT_STATS.xmap(McbsStats::new, McbsStats::getIntValues);
	// ================================================== ==================================================
}
