package com.thecsdev.betterstats.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.SimpleCommandExceptionType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import com.thecsdev.betterstats.BetterStats;
import com.thecsdev.betterstats.mixin.hooks.AccessorStatsCounter;
import com.thecsdev.betterstats.resource.BLanguage;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.StreamSupport;
import net.minecraft.class_12099;
import net.minecraft.class_2168;
import net.minecraft.class_2172;
import net.minecraft.class_2186;
import net.minecraft.class_2232;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3445;
import net.minecraft.class_3448;
import net.minecraft.class_5321;
import net.minecraft.class_7157;
import net.minecraft.class_7733;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

import static net.minecraft.class_2170.method_9244;
import static net.minecraft.class_2170.method_9247;

/**
 * Logic for the {@code /statistics} (or {@code /stats}) command.
 */
public final class StatisticsCommand
{
	// ==================================================
	private StatisticsCommand() {}
	// ==================================================
	/**
	 * Registers the {@code /statistics} (or {@code /stats}) command.
	 * @param dispatcher The {@link CommandDispatcher}.
	 * @param buildContext The {@link class_7157}.
	 * @throws NullPointerException If a {@link NotNull} argument is {@code null}.
	 */
	public static void register(
			@NotNull CommandDispatcher<class_2168> dispatcher,
			@NotNull class_7157 buildContext) throws NullPointerException
	{
		//define the command and its alias
		final var statistics = method_9247("statistics").requires(scs -> scs.method_75037().hasPermission(class_12099.field_63210))
				.then(statistics_edit(buildContext))
				.then(statistics_clear())
				.then(statistics_query(buildContext));
		final var stats = method_9247("stats").requires(scs -> scs.method_75037().hasPermission(class_12099.field_63210))
				.then(statistics_edit(buildContext))
				.then(statistics_clear())
				.then(statistics_query(buildContext));

		//register the command to the dispatcher
		dispatcher.register(statistics);
		dispatcher.register(stats);
	}
	// ==================================================
	/**
	 * Returns an {@link ArgumentBuilder} for the {@code edit} argument.
	 * @param cbc The {@link class_7157}.
	 * @throws NullPointerException If a {@link NotNull} argument is {@code null}.
	 */
	private static ArgumentBuilder<class_2168, ?> statistics_edit(
			@NotNull class_7157 cbc) throws NullPointerException
	{
		return method_9247("edit")
				.then(method_9244("targets", class_2186.method_9308())
						.then(method_9244("stat_type", class_7733.method_45603(cbc, class_7924.field_41226))
								.then(method_9244("stat", class_2232.method_9441()).suggests(SUGGEST_STAT)
										.then(method_9247("set")
												.then(method_9244("value", IntegerArgumentType.integer(0))
														.executes(ctx -> execute_edit(ctx, true))
														)
												)
										.then(method_9247("increase")
												.then(method_9244("value", IntegerArgumentType.integer())
														.executes(ctx -> execute_edit(ctx, false))
														)
												)
										)
								)
						);
	}

	/**
	 * Returns an {@link ArgumentBuilder} for the {@code clear} argument.
	 */
	private static ArgumentBuilder<class_2168, ?> statistics_clear()
	{
		return method_9247("clear")
				.then(method_9244("targets", class_2186.method_9308())
						.executes(StatisticsCommand::execute_clear));
	}

	/**
	 * Returns an {@link ArgumentBuilder} for the {@code query} argument.
	 * @param cra The {@link class_7157}.
	 * @throws NullPointerException If a {@link NotNull} argument is {@code null}.
	 */
	private static ArgumentBuilder<class_2168, ?> statistics_query(
			@NotNull class_7157 cra) throws NullPointerException
	{
		return method_9247("query")
				.then(method_9244("target", class_2186.method_9305())
						.then(method_9244("stat_type", class_7733.method_45603(cra, class_7924.field_41226))
								.then(method_9244("stat", class_2232.method_9441()).suggests(SUGGEST_STAT)
										.executes(StatisticsCommand::execute_query)
										)
								)
					);
	}
	// --------------------------------------------------
	/**
	 * {@link SuggestionProvider} instance that suggests {@link class_3445} registry entries.<br/>
	 * Credit: <a href="https://github.com/TheCSMods/mc-better-stats/issues/102#issuecomment-2045698948">TCDC Issue #102</a>
	 * @apiNote The context should define a {@link class_3448} with the name "stat_type".
	 */
	private static final SuggestionProvider<class_2168> SUGGEST_STAT = (context, builder) ->
	{
		//try to obtain the type of stats we want to be suggesting
		@Nullable class_3448<?> statType = null;
		try { statType = class_7733.method_45602(context, "stat_type", class_7924.field_41226).comp_349(); }
		catch(Exception ignored) {}

		//if a stat type was not provided properly or at all, use default behavior
		if(statType == null) return class_2232.method_9441().listSuggestions(context, builder);

		//next up, after obtaining the target stat type, list the suggestions
		@Nullable Iterable<class_2960> suggestions = statType.method_14959().method_42021()
				.stream().map(class_5321::method_29177).toList();
		return class_2172.method_9264(
				StreamSupport.stream(suggestions.spliterator(), false).map(Objects::toString),
				builder);
	};
	// ==================================================
	/**
	 * Executes the {@code /statistics edit} command.
	 * @param context The {@link CommandContext}.
	 * @param setOrIncrease If {@code true}, sets the statistic to the given value; if {@code false}, increases it by the given value.
	 * @throws NullPointerException If a {@link NotNull} argument is {@code null}.
	 */
	@SuppressWarnings("unchecked")
	private static int execute_edit(
			@NotNull CommandContext<class_2168> context,
			boolean setOrIncrease) throws NullPointerException
	{
		try
		{
			//get parameter values
			final var arg_targets = class_2186.method_9312(context, "targets");
			final var arg_stat_type = (class_3448<Object>)class_7733.method_45602(context, "stat_type", class_7924.field_41226).comp_349();
			final var arg_stat = class_2232.method_9443(context, "stat");
			final int arg_value = IntegerArgumentType.getInteger(context, "value");

			final var stat_object = arg_stat_type.method_14959().method_17966(arg_stat).orElse(null);
			Objects.requireNonNull(stat_object, "Registry entry '" + arg_stat + "' does not exist for registry '" + arg_stat_type.method_14959() + "'.");
			final var stat = arg_stat_type.method_14956(stat_object);

			//execute
			final AtomicInteger affected = new AtomicInteger();
			for(final var target : arg_targets)
			{
				//null check
				if(target == null) continue;

				//set stat value
				if(setOrIncrease) target.method_14248().method_15023(target, stat, arg_value);
				else target.method_14248().method_15022(target, stat, arg_value);
				affected.incrementAndGet();

				//update the client
				target.method_14248().method_14910(target);
			}

			//send feedback
			context.getSource().method_9226(() -> BLanguage.cmd_stats_edit_out(
					class_2561.method_43470("[" + class_7923.field_41193.method_10221(arg_stat_type) + " / " + arg_stat + "]"),
					affected.get()
				), false);

			//return affected count, so command blocks and data-packs can know it
			return affected.get();
		}
		catch(Exception e) { handleError(context, e); return -1; }
	}

	/**
	 * Executes the {@code /statistics clear} command.
	 * @param context The {@link CommandContext}.
	 * @throws NullPointerException If a {@link NotNull} argument is {@code null
	 */
	private static int execute_clear(
			@NotNull CommandContext<class_2168> context) throws NullPointerException
	{
		try
		{
			//get parameter values
			final var targets = class_2186.method_9312(context, "targets");

			//execute
			final AtomicInteger affected = new AtomicInteger();
			for(final var target : targets)
			{
				//null check
				if(target == null) continue;

				//clear statistics
				((AccessorStatsCounter)(Object)target.method_14248()).getStats().clear();
				affected.incrementAndGet();

				//disconnect the player because that's the only way to update the client
				target.field_13987.method_52396(class_2561.method_43470("")
						.method_10852(BLanguage.cmd_stats_clear_kick())
						.method_27693("\n\n[EN]: Your statistics were cleared, which requires you to disconnect and re-join."));
			}

			//send feedback
			context.getSource().method_9226(() -> BLanguage.cmd_stats_clear_out(affected.get()), false);

			//return affected count, so command blocks and data-packs can know it
			return affected.get();
		}
		catch(Exception e) { handleError(context, e); return -1; }
	}

	/**
	 * Executes the {@code /statistics query} command.
	 * @param context The {@link CommandContext}.
	 * @throws NullPointerException If a {@link NotNull} argument is {@code null}.
	 */
	@SuppressWarnings({"unchecked", "ConstantValue"})
	private static int execute_query(
			@NotNull CommandContext<class_2168> context) throws NullPointerException
	{
		try
		{
			//get parameter values
			final var arg_target = class_2186.method_9315(context, "target");
			if(arg_target == null) throw new SimpleCommandExceptionType(class_2561.method_43470("Player not found.")).create();
			final var arg_stat_type = (class_3448<Object>)class_7733.method_45602(context, "stat_type", class_7924.field_41226).comp_349();
			final var arg_stat = class_2232.method_9443(context, "stat");

			final var stat_object = arg_stat_type.method_14959().method_17966(arg_stat).orElse(null);
			Objects.requireNonNull(stat_object, "Registry entry '" + arg_stat + "' does not exist for registry '" + arg_stat_type.method_14959() + "'.");

			final var stat = arg_stat_type.method_14956(stat_object);
			final int statValue = arg_target.method_14248().method_15025(stat);

			//execute
			context.getSource().method_9226(() -> BLanguage.cmd_stats_query_out(
					arg_target.method_5476(),
					class_2561.method_43470("[" + class_7923.field_41193.method_10221(arg_stat_type) + " / " + arg_stat + "]"),
					statValue
				), false);
			return statValue;
		}
		catch(Exception e) { handleError(context, e); return -1; }
	}
	// ==================================================
	/**
	 * Handles errors that occur during command execution.
	 * @param context The {@link CommandContext}.
	 * @param throwable The {@link Throwable} that occurred.
	 * @throws NullPointerException If a {@link NotNull} argument is {@code null}.
	 */
	public static @ApiStatus.Internal void handleError(
			@NotNull CommandContext<class_2168> context,
			@NotNull Throwable throwable) throws NullPointerException
	{
		//not-null requirements
		Objects.requireNonNull(context);
		Objects.requireNonNull(throwable);
		//handle Errors-s
		final var msg = "An unexpected error occurred trying to execute the /statistics command";
		if(throwable instanceof Error) throw new Error(msg, throwable);
		//handle command syntax errors
		context.getSource().method_9213(class_2561.method_43471("command.failed").method_27693(":\n    " + throwable.getMessage()));
		BetterStats.LOGGER.error(msg, throwable);
	}
	// ==================================================
}