package com.thecsdev.betterstats.mcbs.view.menubar;

import com.thecsdev.betterstats.BetterStats;
import com.thecsdev.betterstats.api.mcbs.controller.McbsEditor;
import com.thecsdev.betterstats.api.mcbs.view.menubar.MenubarItem;
import com.thecsdev.betterstats.resource.BLanguage;
import com.thecsdev.betterstats.resource.BSprites;
import com.thecsdev.commonmc.api.client.gui.ctxmenu.TContextMenu;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_407;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

import static com.thecsdev.commonmc.resource.TComponent.*;
import static net.minecraft.class_2561.method_43470;
import static net.minecraft.class_2561.method_43469;

/**
 * {@link MenubarItem} implementation for "About".
 */
@ApiStatus.Internal
@Environment(EnvType.CLIENT)
public final class MenubarItemAbout extends MenubarItem
{
	// ==================================================
	public static final MenubarItemAbout INSTANCE = new MenubarItemAbout();
	// ==================================================
	public final @Override @NotNull class_2561 getDisplayName() { return BLanguage.gui_menubar_about(); }
	// --------------------------------------------------
	@SuppressWarnings("removal")
	public final @Override @NotNull TContextMenu createContextMenu(
			@NotNull class_310 client, @NotNull McbsEditor mcbsEditor)
	{
		Objects.requireNonNull(client, "Missing 'client' instance");
		Objects.requireNonNull(mcbsEditor, "Missing 'editor' instance");
		return new TContextMenu.Builder(Objects.requireNonNull(client))
				.addButton(
						item("item/filled_map").method_27693(" ").method_10852(BLanguage.gui_menubar_about_sourceCode()),
						__ -> showUriScreen(BetterStats.getProperty("mod.link.sources"), true))
				.addButton(
						head("MHF_Spider").method_27693(" ").method_10852(method_43471("menu.reportBugs")),
						__ -> showUriScreen(BetterStats.getProperty("mod.link.issues"), true))
				.addButton(
						item("item/paper").method_27693(" ").method_10852(BLanguage.gui_menubar_about_legalNotices()),
						__ -> showUriScreen(BetterStats.getProperty("mod.link.legal"), true))
				.addSeparator()
				.addButton(
						gui(BSprites.gui_icon_faviconCf()).method_27693(" ").method_10852(method_43470("CurseForge")),
						__ -> showUriScreen(BetterStats.getProperty("mod.link.curseforge"), true))
				.addButton(
						gui(BSprites.gui_icon_faviconMr()).method_27693(" ").method_10852(method_43470("Modrinth")),
						__ -> showUriScreen(BetterStats.getProperty("mod.link.modrinth"), true))
				.addSeparator()
				.addButton(
						gui(BSprites.gui_icon_heart()).method_27693(" ").method_10852(BLanguage.gui_menubar_about_supportMe().method_27692(class_124.field_1054)),
						__ -> showUriScreen(BetterStats.getProperty("mod.link.support_me"), true))
				.build();
	}
	// ==================================================
	/**
	 * Opens a {@link class_407} that asks the user whether
	 * they want to open the specified URI.
	 * @param uri The URI to show.
	 * @param isTrusted Whether the URI is trusted.
	 * @throws NullPointerException If the argument is {@code null}.
	 */
	@ApiStatus.Internal
	@SuppressWarnings("SameParameterValue")
	public static final void showUriScreen(@NotNull String uri, boolean isTrusted)
			throws NullPointerException
	{
		//argument validity assertion
		Objects.requireNonNull(uri);

		//obtain client variables stuff
		final var client     = Objects.requireNonNull(class_310.method_1551());
		final var lastScreen = client.field_1755;

		//create and set the confirmation screen
		final var screen     = new class_407(accepted -> {
			if(accepted) class_156.method_668().method_670(uri);
			client.method_1507(lastScreen);
		}, uri, isTrusted);
		client.method_1507(screen);
	}
	// ==================================================
}
