package com.thecsdev.betterstats.mcbs.view.statsview;

import com.thecsdev.betterstats.api.mcbs.view.statsview.StatsView;
import com.thecsdev.common.util.annotations.Virtual;
import com.thecsdev.commonmc.api.client.gui.widget.stats.TItemStatsWidget;
import com.thecsdev.commonmc.api.stats.util.ItemStats;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2561;
import net.minecraft.class_9334;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.util.function.Predicate;

import static com.thecsdev.betterstats.api.mcbs.view.statsview.StatsViewUtils.FID_SEARCH;
import static com.thecsdev.commonmc.resource.TComponent.item;
import static net.minecraft.class_2561.method_43469;

/**
 * {@link StatsView} that displays "Food &amp; Drinks" statistics.
 */
@Environment(EnvType.CLIENT)
public final @ApiStatus.Internal class StatsViewFood extends StatsViewItems
{
	// ==================================================
	/**
	 * The main instance of this {@link Class}.
	 */
	public static final StatsViewFood INSTANCE = new StatsViewFood();
	// ==================================================
	private StatsViewFood() {}
	// ==================================================
	public @Override @NotNull class_2561 getDisplayName() {
		return item("item/apple").method_27693(" ").method_10852(method_43471("itemGroup.foodAndDrink"));
	}
	// --------------------------------------------------
	protected @Virtual @Override @NotNull Predicate<ItemStats> getStatsPredicate(final @NotNull Filters filters) throws NullPointerException {
		//get filter values
		final var f_query = filters.getProperty(String.class, FID_SEARCH, "");
		//construct and return predicate
		return stat -> stat.getSubject().method_57347().method_57832(class_9334.field_50075) && stat.isSearchMatch(f_query);
	}
	// --------------------------------------------------
	protected final @Override void postProcessWidget(@NotNull StatsInitContext context, @NotNull TItemStatsWidget widget)
	{
		//super post process
		super.postProcessWidget(context, widget);
		//obtain stats and assert non-null
		final var stats = widget.statsProperty().get();
		assert stats != null;
		//set outline color based on usage
		if(stats.getTimesUsed() > 0)
			widget.outlineColorProperty().set(OC_DONE, StatsViewFood.class);
		else if(!stats.isEmpty())
			widget.outlineColorProperty().set(OC_INPROGRESS, StatsViewFood.class);
	}
	// ==================================================
}
