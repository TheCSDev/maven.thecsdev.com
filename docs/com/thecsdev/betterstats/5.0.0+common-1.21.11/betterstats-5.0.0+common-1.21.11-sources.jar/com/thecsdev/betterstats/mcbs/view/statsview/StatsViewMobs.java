package com.thecsdev.betterstats.mcbs.view.statsview;

import com.thecsdev.betterstats.BetterStats;
import com.thecsdev.betterstats.api.mcbs.view.statsview.StatsView;
import com.thecsdev.betterstats.api.mcbs.view.statsview.StatsViewUtils;
import com.thecsdev.betterstats.client.gui.panel.StatsPageChooser;
import com.thecsdev.betterstats.client.gui.panel.StatsSummaryPanel;
import com.thecsdev.betterstats.resource.BLanguage;
import com.thecsdev.betterstats.resource.BSprites;
import com.thecsdev.common.util.annotations.Virtual;
import com.thecsdev.commonmc.api.client.gui.TElement;
import com.thecsdev.commonmc.api.client.gui.ctxmenu.TContextMenu;
import com.thecsdev.commonmc.api.client.gui.misc.TTextureElement;
import com.thecsdev.commonmc.api.client.gui.screen.TTextDialogScreen;
import com.thecsdev.commonmc.api.client.gui.tooltip.TTooltip;
import com.thecsdev.commonmc.api.client.gui.widget.TDropdownWidget;
import com.thecsdev.commonmc.api.client.gui.widget.stats.TEntityStatsWidget;
import com.thecsdev.commonmc.api.stats.IStatsProvider;
import com.thecsdev.commonmc.api.stats.util.EntityStats;
import com.thecsdev.commonmc.api.util.modinfo.ModInfoProvider;
import com.thecsdev.commonmc.resource.TLanguage;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1311;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.thecsdev.betterstats.BetterStats.MOD_ID;
import static com.thecsdev.commonmc.resource.TComponent.*;
import static java.util.Comparator.comparing;
import static net.minecraft.class_2561.method_43470;
import static net.minecraft.class_2561.method_43469;
import static net.minecraft.class_2960.field_33381;
import static net.minecraft.class_2960.method_60655;
import static org.apache.commons.lang3.exception.ExceptionUtils.getStackTrace;

/**
 * {@link StatsView} that displays "Mobs" statistics.
 */
@Environment(EnvType.CLIENT)
public sealed @ApiStatus.Internal class StatsViewMobs extends SubjectStatsView<EntityStats>
		permits StatsViewHunter
{
	// ================================================== ==================================================
	//                                      StatsViewMobs IMPLEMENTATION
	// ================================================== ==================================================
	/**
	 * The main instance of this {@link Class}.
	 */
	public static final StatsViewMobs INSTANCE = new StatsViewMobs();
	// ==================================================
	protected StatsViewMobs() {}
	// ==================================================
	public @Override @NotNull class_2561 getDisplayName() {
		return head("MHF_Pig").method_27693(" ").method_10852(method_43471("stat.mobsButton"));
	}
	// ==================================================
	public final @Override void initFilters(@NotNull FiltersInitContext context) {
		super.initFilters(context);
		SortBy.initFilter(context);
		GroupBy.initFilter(context);
	}
	// --------------------------------------------------
	public @Override void initStats(@NotNull StatsInitContext context)
	{
		//obtain stats
		final var allStats = EntityStats.getEntityStats(
				context.getStats(),
				getStatsPredicate(context.getFilters()),
				getStatsSorter(context.getFilters()));
		if(allStats.isEmpty()) return; //nothing to show
		final int perPage    = 200;
		final var pagedStats = StatsPageChooser.applyFilter(allStats, context.getFilters(), perPage);

		//group stats and initialize each group
		StatsPageChooser.initPanel(context.getPanel(), context.getFilters(), perPage, allStats.size());
		getStatsGrouper(context.getFilters())
				.apply(pagedStats).forEach((gName, gStats) ->
						StatsViewUtils.initMobStats(
								context.getPanel(), gName, gStats,
								widget -> postProcessWidget(context, widget)
						));
		StatsPageChooser.initPanel(context.getPanel(), context.getFilters(), perPage, allStats.size());
		StatsSummaryPanel.initPanel(context.getPanel(), allStats);
	}
	// ==================================================
	/**
	 * Post-processes each {@link TEntityStatsWidget} after its creation.
	 * @param context The {@link StatsView.StatsInitContext}.
	 * @param widget The {@link TEntityStatsWidget} to post-process.
	 * @throws NullPointerException If any of the arguments is {@code null}.
	 */
	protected @Virtual void postProcessWidget(@NotNull StatsView.StatsInitContext context, @NotNull TEntityStatsWidget widget)
	{
		//obtain stats instance
		final var stats = widget.statsProperty().get();
		assert stats != null;
		//noinspection unchecked - context menu
		widget.contextMenuProperty().set((Function<TElement, TContextMenu>)(Object) CTX_MENU, StatsViewMobs.class);
		widget.followsCursorProperty().set(BetterStats.getConfig().getGuiMobsFollowCursor(), StatsViewMobs.class);
	}

	/**
	 * Constructs a context menu for a given {@link TEntityStatsWidget}.
	 */
	private static final Function<TEntityStatsWidget, TContextMenu> CTX_MENU = widget ->
	{
		//obtain the stats data and ensure it is present
		final var stats = widget.statsProperty().get();
		assert stats != null;

		//create the context menu builder
		final var client  = Objects.requireNonNull(widget.getClient(), "Missing 'client' instance");
		final var builder = new TContextMenu.Builder(client);

		//error information
		final @Nullable var displayError = widget.getDisplayError();
		if(displayError != null)
			builder.addButton(
					missingNo().method_27693(" ").method_10852(BLanguage.gui_statsview_stats_ctxMenu_viewErrorInfo()),
					__ -> {
						final var parent = client.field_1755;
						final var title  = missingNo().method_27693(" ").method_10852(TLanguage.misc_somethingWentWrong());
						final var text   = method_43470(getStackTrace(displayError).replace("\r\n", "\n").replace("\t", "    "));
						final var dialog = new TTextDialogScreen(parent, title, text);
						client.method_1507(dialog.getAsScreen());
					});

		//wiki url
		if(Objects.equals(stats.getSubjectID().method_12836(), field_33381)) {
			final var url_wiki = String.format("https://minecraft.wiki/w/%s", stats.getSubjectID().method_12832());
			builder.addButton(
					gui(BSprites.gui_icon_faviconWiki()).method_27693(" ").method_10852(BLanguage.gui_statsview_stats_ctxMenu_viewOnWiki()),
					__ -> class_156.method_668().method_670(url_wiki));
		}

		//close button, and thenbuild and return a new context menu
		builder.addButton(
			gui(BSprites.gui_icon_close()).method_27693(" ").method_10852(BLanguage.gui_menubar_file_close()),
			__ -> {});
		return builder.build();
	};
	// --------------------------------------------------
	protected @Virtual @Override @NotNull Comparator<EntityStats> getStatsSorter(@NotNull Filters filters) throws NullPointerException {
		return filters.getProperty(SortBy.class, SortBy.FID, SortBy.VANILLA).getStatsSorter();
	}

	protected final @Override @NotNull Function<Iterable<EntityStats>, LinkedHashMap<class_2561, Iterable<EntityStats>>> getStatsGrouper(@NotNull Filters filters) {
		return filters.getProperty(GroupBy.class, GroupBy.FID, GroupBy.MOD).getStatsGrouper();
	}
	// ================================================== ==================================================
	//                                             SortBy IMPLEMENTATION
	// ================================================== ==================================================
	/**
	 * {@link TDropdownWidget.Entry}s for sorting {@link EntityStats}.
	 */
	public static final class SortBy implements TDropdownWidget.Entry
	{
		// ==================================================
		public static final SortBy VANILLA = new SortBy(
				"VANILLA", class_2561.method_43470("-"),
				(o1, o2) -> 0);
		public static final SortBy ALPHABETICAL = new SortBy(
				"ALPHABETICAL", class_2561.method_43470("A-Z"),
				comparing(stat -> stat.getSubjectDisplayName().getString()));
		public static final SortBy LACITEBAHPLA = new SortBy(
				"LACITEBAHPLA", class_2561.method_43470("Z-A"),
				ALPHABETICAL.sorter.reversed());
		// --------------------------------------------------
		/**
		 * The main "filter id" used for {@link StatsView.Filters}.
		 */
		public static final class_2960 FID = method_60655(MOD_ID, "entities_sort_by");
		// --------------------------------------------------
		private final @NotNull Object handle;
		private final @NotNull class_2561 name;
		private final @NotNull Comparator<EntityStats> sorter;
		// ==================================================
		private SortBy(
				@NotNull Object handle,
				@NotNull class_2561 name,
				@NotNull Comparator<EntityStats> sorter) throws NullPointerException {
			this.handle = Objects.requireNonNull(handle);
			this.name   = Objects.requireNonNull(name);
			this.sorter = Objects.requireNonNull(sorter);
		}
		// ==================================================
		public final @Override @NotNull class_2561 getDisplayName() { return this.name; }
		public @NotNull Comparator<EntityStats> getStatsSorter() { return this.sorter; }
		// ==================================================
		public final @Override int hashCode() { return Objects.hash(this.handle); }
		public final @Override boolean equals(Object obj) {
			if(obj == this) return true;
			if(!(obj instanceof SortBy other)) return false;
			return Objects.equals(this.handle, other.handle);
		}
		// ==================================================
		/**
		 * Initializes GUI for the {@link SortBy} filter.
		 * @param context The {@link StatsView.FiltersInitContext}.
		 * @throws NullPointerException If the argument is {@code null}.
		 */
		public static final void initFilter(@NotNull StatsView.FiltersInitContext context) throws NullPointerException
		{
			//create and add the icon and widget
			final var panel = context.getPanel();
			final var nextY = panel.computeNextYBounds(20, StatsViewUtils.GAP);

			final var icon = new TTextureElement(BSprites.gui_icon_filterSort());
			icon.setBounds(nextY.x, nextY.y, 20, nextY.height);
			panel.add(icon);

			final var dropdown = new TDropdownWidget<SortBy>();
			dropdown.setBounds(nextY.x + 25, nextY.y, nextY.width - 25, nextY.height);
			dropdown.getEntries().addAll(values());
			dropdown.tooltipProperty().set(__ -> TTooltip.of(BLanguage.gui_statsview_filter_sortBy()), SortBy.class);
			panel.add(dropdown);

			//set initial value and apply filters on value update
			dropdown.selectedEntryProperty().set(
					context.getFilters().getProperty(SortBy.class, FID, VANILLA),
					SortBy.class);
			dropdown.selectedEntryProperty().addChangeListener((p, o, n) ->
					context.getFilters().setProperty(SortBy.class, FID, n));
		}
		// ==================================================
		/**
		 * Retuns all {@link SortBy} instances that are to be used.
		 */
		public static final @NotNull Collection<SortBy> values()
		{
			//initialize the list
			final var ist  = IStatsProvider.getEntityStatTypes();
			final var list = new ArrayList<SortBy>(3 + ist.size());
			//add sorting entries
			list.add(VANILLA);
			list.add(ALPHABETICAL);
			list.add(LACITEBAHPLA);
			for(final var statType : ist)
				list.add(new SortBy(
						statType, IStatsProvider.getStatTypeName(statType),
						comparing((EntityStats s) -> s.getStatsProvider().getIntValue(statType, s.getSubject())).reversed()
				));
			//return the result
			return list;
		}
		// ==================================================
	}
	// ================================================== ==================================================
	//                                            GroupBy IMPLEMENTATION
	// ================================================== ==================================================
	/**
	 * {@link TDropdownWidget.Entry}s for grouping {@link EntityStats}.
	 */
	public static enum GroupBy implements TDropdownWidget.Entry
	{
		// ==================================================
		ALL(BLanguage.gui_statsview_filter_groupBy_all(), stats -> {
			final var map = new LinkedHashMap<class_2561, Iterable<EntityStats>>();
			map.put(class_2561.method_43470("*"), stats);
			return map;
		}),
		MOD(class_2561.method_43470("Mod"), stats -> {
			//create a new map to group stats based on mod id-s
			final var map = new LinkedHashMap<String, ArrayList<EntityStats>>();
			//group the stats
			for(final var stat : stats)
				map.computeIfAbsent(stat.getSubjectID().method_12836(), __ -> new ArrayList<>())
						.add(stat);
			//remap the map and return it
			return map.entrySet().stream().collect(Collectors.toMap(
					entry -> {
						assert ModInfoProvider.getInstance() != null;
						return ModInfoProvider.getInstance().getModInfo(entry.getKey()).getName();
					},
					Map.Entry::getValue,
					(existing, replacement) -> existing,
					LinkedHashMap::new
			));
		}),
		CATEGORY(BLanguage.gui_statsview_filter_groupBy_mobCategory(), stats -> {
			//create a new map to group stats based on mob categories
			final var map = new LinkedHashMap<class_1311, ArrayList<EntityStats>>();
			//group the stats
			for(final var stat : stats) {
				final var category = stat.getSubject().method_5891();
				map.computeIfAbsent(category, __ -> new ArrayList<>()).add(stat);
			}
			//remap the map and return it
			return map.entrySet().stream().collect(Collectors.toMap(
					entry -> method_43471("mobCategory." + entry.getKey().method_6133()),
					Map.Entry::getValue,
					(existing, replacement) -> existing,
					LinkedHashMap::new
			));
		});
		// --------------------------------------------------
		/**
		 * The main "filter id" used for {@link StatsView.Filters}.
		 */
		public static final class_2960 FID = method_60655(MOD_ID, "entities_group_by");
		// --------------------------------------------------
		private final @NotNull class_2561 name;
		private final @NotNull Function<Iterable<EntityStats>, LinkedHashMap<class_2561, Iterable<EntityStats>>> grouper;
		// ==================================================
		GroupBy(@NotNull class_2561 name,
				@NotNull Function<Iterable<EntityStats>, LinkedHashMap<class_2561, Iterable<EntityStats>>> grouper) {
			this.name    = Objects.requireNonNull(name);
			this.grouper = grouper;
		}
		// ==================================================
		public final @Override @NotNull class_2561 getDisplayName() { return this.name; }
		public final @NotNull Function<Iterable<EntityStats>, LinkedHashMap<class_2561, Iterable<EntityStats>>> getStatsGrouper() { return this.grouper; }
		// ==================================================
		/**
		 * Initializes GUI for the {@link StatsViewMobs.GroupBy} filter.
		 * @param context The {@link StatsView.FiltersInitContext}.
		 * @throws NullPointerException If the argument is {@code null}.
		 */
		public static final void initFilter(@NotNull StatsView.FiltersInitContext context) throws NullPointerException
		{
			//create and add the icon and widget
			final var panel = context.getPanel();
			final var nextY = panel.computeNextYBounds(20, StatsViewUtils.GAP);

			final var icon = new TTextureElement(BSprites.gui_icon_filterGroup());
			icon.setBounds(nextY.x, nextY.y, 20, nextY.height);
			panel.add(icon);

			final var dropdown = new TDropdownWidget<StatsViewMobs.GroupBy>();
			dropdown.setBounds(nextY.x + 25, nextY.y, nextY.width - 25, nextY.height);
			Collections.addAll(dropdown.getEntries(), StatsViewMobs.GroupBy.values());
			dropdown.tooltipProperty().set(__ -> TTooltip.of(BLanguage.gui_statsview_filter_groupBy()), GroupBy.class);
			panel.add(dropdown);

			//set initial value and apply filters on value update
			dropdown.selectedEntryProperty().set(
					context.getFilters().getProperty(StatsViewMobs.GroupBy.class, FID, MOD),
					StatsViewMobs.GroupBy.class);
			dropdown.selectedEntryProperty().addChangeListener((p, o, n) ->
					context.getFilters().setProperty(GroupBy.class, FID, n));
		}
		// ==================================================
	}
	// ================================================== ==================================================
}
