package com.thecsdev.betterstats.mixin.hooks;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import net.minecraft.class_3445;
import net.minecraft.class_3469;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_3469.class)
public interface AccessorStatsCounter
{
	public abstract @Accessor("stats") Object2IntMap<class_3445<?>> getStats();
}
