package com.thecsdev.betterstats.resource;

import com.thecsdev.betterstats.BetterStats;
import com.thecsdev.common.util.annotations.Reflected;
import org.jetbrains.annotations.NotNull;

import java.net.URI;
import java.util.Objects;
import net.minecraft.class_124;
import net.minecraft.class_2558;
import net.minecraft.class_2561;
import net.minecraft.class_2568;
import net.minecraft.class_5250;

import static com.thecsdev.betterstats.BetterStats.MOD_ID;
import static net.minecraft.class_2561.method_43470;
import static net.minecraft.class_2561.method_43469;

/**
 * {@link BetterStats}'s language translation keys.
 */
public final class BLanguage
{
	// ==================================================
	public static final class_2561 WATERMARK;
	// ==================================================
	private BLanguage() {}
	static {
		//define the 'betterstats' watermark
		{
			final var bss = Objects.requireNonNull(BetterStats.getInstance(), "Mod not initialized: 'betterstats'");

			//create the hover event for the watermark
			final var hoverText = method_43470(bss.getModName()).method_27692(class_124.field_1054)
					.method_27693("\n")
					.method_10852(method_43470(MOD_ID).method_27692(class_124.field_1080));
			final var hoverEvent = new class_2568.class_10613(hoverText);
			@SuppressWarnings("removal")
			final var clickEvent = new class_2558.class_10608(URI.create(BetterStats.getProperty("mod.link.homepage")));

			//create the watermark text
			final var text = method_43470("[≡] <" + MOD_ID + ">").method_27692(class_124.field_1064);
			text.method_10862(text.method_10866().method_10949(hoverEvent).method_10958(clickEvent));
			WATERMARK = text;
		}
	}
	// ==================================================
	public static final class_5250 mmName_betterstats() { return method_43471("modmenu.nameTranslation.betterstats"); }
	public static final class_5250 mmSummary_betterstats() { return method_43471("modmenu.summaryTranslation.betterstats"); }
	// ==================================================
	public static final class_5250 stat_betterstats_timeSinceLogin() { return method_43471("stat.betterstats.time_since_login"); }
	// --------------------------------------------------
	public static final class_5250 config_common_registerCommands() { return method_43471("betterstats.config.common.register_commands"); }
	public static final class_5250 config_common_registerCommands_tooltip() { return method_43471("betterstats.config.common.register_commands.tooltip"); }
	public static final class_5250 config_common_apiEndpoint() { return method_43471("betterstats.config.common.api_endpoint"); }
	public static final class_5250 config_common_apiEndpoint_tooltip() { return method_43471("betterstats.config.common.api_endpoint.tooltip"); }
	public static final class_5250 config_client_allowChatPsa() { return method_43471("betterstats.config.client.allow_chat_psa"); }
	public static final class_5250 config_client_allowChatPsa_tooltip() { return method_43471("betterstats.config.client.allow_chat_psa.tooltip"); }
	public static final class_5250 config_client_guiMobsFollowCursor() { return method_43471("betterstats.config.client.gui_mobs_follow_cursor"); }
	public static final class_5250 config_client_guiMobsFollowCursor_tooltip() { return method_43471("betterstats.config.client.gui_mobs_follow_cursor.tooltip"); }
	// --------------------------------------------------
	public static final class_5250 cmd_stats_edit_out(@NotNull class_2561 stat, int affectedPlayerCount) { return method_43469("commands.statistics.edit.output", stat, affectedPlayerCount); }
	public static final class_5250 cmd_stats_clear_out(int affectedPlayerCount) { return method_43469("commands.statistics.clear.output", affectedPlayerCount); }
	public static final class_5250 cmd_stats_clear_kick() { return method_43471("commands.statistics.clear.kick"); }
	public static final class_5250 cmd_stats_query_out(@NotNull class_2561 player, @NotNull class_2561 stat, int value) { return method_43469("commands.statistics.query.output", player, stat, value); }
	// --------------------------------------------------
	public static final class_5250 gui_menubar_file() { return method_43471("betterstats.gui.menubar.file"); }
	public static final class_5250 gui_menubar_file_new() { return method_43471("betterstats.gui.menubar.file.new"); }
	public static final class_5250 gui_menubar_file_open() { return method_43471("betterstats.gui.menubar.file.open"); }
	public static final class_5250 gui_menubar_file_saveAs() { return method_43471("betterstats.gui.menubar.file.save_as"); }
	public static final class_5250 gui_menubar_file_settings() { return method_43471("betterstats.gui.menubar.file.settings"); }
	public static final class_5250 gui_menubar_file_close() { return method_43471("betterstats.gui.menubar.file.close"); }
	public static final class_5250 gui_menubar_view() { return method_43471("betterstats.gui.menubar.view"); }
	public static final class_5250 gui_menubar_view_vanillaScreen() { return method_43471("betterstats.gui.menubar.view.vanilla_screen"); }
	public static final class_5250 gui_menubar_view_homepage() { return method_43471("betterstats.gui.menubar.view.homepage"); }
	public static final class_5250 gui_menubar_view_localPlayerStats() { return method_43471("betterstats.gui.menubar.view.local_player_stats"); }
	public static final class_5250 gui_menubar_view_statsView() { return method_43471("betterstats.gui.menubar.view.stats_view"); }
	public static final class_5250 gui_menubar_about() { return method_43471("betterstats.gui.menubar.about"); }
	public static final class_5250 gui_menubar_about_sourceCode() { return method_43471("betterstats.gui.menubar.about.source_code"); }
	public static final class_5250 gui_menubar_about_supportMe() { return method_43471("betterstats.gui.menubar.about.support_me"); }
	public static final class_5250 gui_menubar_about_legalNotices() { return method_43471("betterstats.gui.menubar.about.legal_notices"); }
	// --------------------------------------------------
	public static final class_5250 gui_statsview_filters() { return method_43471("betterstats.gui.statsview.filters"); }
	public static final class_5250 gui_statsview_filter_selectedView() { return method_43471("betterstats.gui.statsview.filter.selected_view"); }
	public static final class_5250 gui_statsview_filter_search() { return method_43471("betterstats.gui.statsview.filter.search"); }
	public static final class_5250 gui_statsview_filter_showAllStats() { return method_43471("betterstats.gui.statsview.filter.show_all_stats"); }
	public static final class_5250 gui_statsview_filter_sortBy() { return method_43471("betterstats.gui.statsview.filter.sort_by"); }
	public static final class_5250 gui_statsview_filter_groupBy() { return method_43471("betterstats.gui.statsview.filter.group_by"); }
	public static final class_5250 gui_statsview_filter_groupBy_all() { return method_43471("betterstats.gui.statsview.filter.group_by.all"); }
	public static final class_5250 gui_statsview_filter_groupBy_mod() { return method_43471("betterstats.gui.statsview.filter.group_by.mod"); }
	public static final class_5250 gui_statsview_filter_groupBy_mobCategory() { return method_43471("betterstats.gui.statsview.filter.group_by.mob_category"); }
	public static final class_5250 gui_statsview_filter_groupBy_createiveModeTab() { return method_43471("betterstats.gui.statsview.filter.group_by.creative_mode_tab"); }
	public static final class_5250 gui_statsview_filter_distanceUnit() { return method_43471("betterstats.gui.statsview.filter.distance_unit"); }
	public static final class_5250 gui_statsview_filter_timeUnit() { return method_43471("betterstats.gui.statsview.filter.time_unit"); }
	public static final class_5250 gui_statsview_stats_noStats() { return method_43471("betterstats.gui.statsview.stats.no_stats"); }
	public static final class_5250 gui_statsview_stats_ctxMenu_viewErrorInfo() { return method_43471("betterstats.gui.statsview.stats.ctxmenu.view_error_info"); }
	public static final class_5250 gui_statsview_stats_ctxMenu_viewOnWiki() { return method_43471("betterstats.gui.statsview.stats.ctxmenu.view_on_wiki"); }
	// --------------------------------------------------
	public static final class_5250 gui_homeTab_featuredStats() { return method_43471("betterstats.gui.home_tab.featured_stats"); }
	// ==================================================
	public static final @Reflected class_5250 credits() { return method_43471("betterstats.credits"); }
	public static final @Reflected class_5250 credits_section_topSponsors() { return method_43471("betterstats.credits.section.top_sponsors"); }
	public static final @Reflected class_5250 credits_section_topSponsors_summary() { return method_43471("betterstats.credits.section.top_sponsors.summary"); }
	public static final @Reflected class_5250 credits_section_recentSponsors() { return method_43471("betterstats.credits.section.recent_sponsors"); }
	public static final @Reflected class_5250 credits_section_recentSponsors_summary() { return method_43471("betterstats.credits.section.recent_sponsors.summary"); }
	public static final @Reflected class_5250 credits_section_recentSponsors_entry_sponsor() { return method_43471("betterstats.credits.section.recent_sponsors.entry.sponsor"); }
	public static final @Reflected class_5250 credits_section_recentSponsors_entry_sponsor_summary() { return method_43471("betterstats.credits.section.recent_sponsors.entry.sponsor.summary"); }
	public static final @Reflected class_5250 credits_section_specialThanks() { return method_43471("betterstats.credits.section.special_thanks"); }
	public static final @Reflected class_5250 credits_section_specialThanks_summary() { return method_43471("betterstats.credits.section.special_thanks.summary"); }
	public static final @Reflected class_5250 credits_section_specialThanks_entry_you() { return method_43471("betterstats.credits.section.special_thanks.entry.you"); }
	public static final @Reflected class_5250 credits_section_specialThanks_entry_you_summary() { return method_43471("betterstats.credits.section.special_thanks.entry.you.summary"); }
	public static final @Reflected class_5250 credits_section_specialThanks_entry_contributors() { return method_43471("betterstats.credits.section.special_thanks.entry.contributors"); }
	public static final @Reflected class_5250 credits_section_specialThanks_entry_contributors_summary() { return method_43471("betterstats.credits.section.special_thanks.entry.contributors.summary"); }
	public static final @Reflected class_5250 credits_section_contributors() { return method_43471("betterstats.credits.section.contributors"); }
	public static final @Reflected class_5250 credits_section_contributors_summary() { return method_43471("betterstats.credits.section.contributors.summary"); }
	public static final @Reflected class_5250 credits_section_contributors_entry_contribute() { return method_43471("betterstats.credits.section.contributors.entry.contribute"); }
	public static final @Reflected class_5250 credits_section_contributors_entry_contribute_summary() { return method_43471("betterstats.credits.section.contributors.entry.contribute.summary"); }
	public static final @Reflected class_5250 credits_section_founderContributors() { return method_43471("betterstats.credits.section.founder_contributors"); }
	public static final @Reflected class_5250 credits_section_founderContributors_summary() { return method_43471("betterstats.credits.section.founder_contributors.summary"); }
	// ==================================================
}
