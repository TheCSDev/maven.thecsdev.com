package com.thecsdev.betterstats.resource;

import com.thecsdev.betterstats.BetterStats;
import com.thecsdev.commonmc.api.client.gui.misc.TTextureElement;
import net.minecraft.class_1058;
import net.minecraft.class_10725;
import net.minecraft.class_2960;

import static com.thecsdev.betterstats.BetterStats.MOD_ID;
import static net.minecraft.class_2960.method_60655;

/**
 * {@link BetterStats}'s {@link class_2960}s for {@link class_1058}s.
 * @see class_10725
 * @see class_1058
 * @see TTextureElement.Mode#GUI_SPRITE
 */
public final class BSprites
{
	// ==================================================
	private BSprites() {}
	// ==================================================
	public static final class_2960 gui_editor_menubar_background() { return method_60655(MOD_ID, "editor/menubar/background"); }
	public static final class_2960 gui_editor_menubar_foreground() { return method_60655(MOD_ID, "editor/menubar/foreground"); }

	public static final class_2960 gui_editor_tabStrip_background() { return method_60655(MOD_ID, "editor/tab_strip/background"); }
	public static final class_2960 gui_editor_tabStrip_foreground() { return method_60655(MOD_ID, "editor/tab_strip/foreground"); }
	public static final class_2960 gui_editor_tabStrip_entry() { return method_60655(MOD_ID, "editor/tab_strip/entry"); }
	public static final class_2960 gui_editor_tabStrip_entrySelected() { return method_60655(MOD_ID, "editor/tab_strip/entry_selected"); }

	public static final class_2960 gui_editor_tab_background() { return method_60655(MOD_ID, "editor/tab/background"); }
	public static final class_2960 gui_editor_tab_foreground() { return method_60655(MOD_ID, "editor/tab/foreground"); }

	public static final class_2960 gui_editor_tab_statsFile_filtersBackground() { return method_60655(MOD_ID, "editor/tab/stats_file/filters_background"); }
	public static final class_2960 gui_editor_tab_statsFile_filtersForeground() { return method_60655(MOD_ID, "editor/tab/stats_file/filters_foreground"); }
	public static final class_2960 gui_editor_tab_statsFile_statsBackground() { return method_60655(MOD_ID, "editor/tab/stats_file/stats_background"); }
	public static final class_2960 gui_editor_tab_statsFile_statsForeground() { return method_60655(MOD_ID, "editor/tab/stats_file/stats_foreground"); }
	// --------------------------------------------------
	public static final class_2960 gui_icon_close() { return method_60655(MOD_ID, "icon/close"); }
	public static final class_2960 gui_icon_settings() { return method_60655(MOD_ID, "icon/settings"); }
	public static final class_2960 gui_icon_heart() { return method_60655(MOD_ID, "icon/heart"); }
	public static final class_2960 gui_icon_heartBss() { return method_60655(MOD_ID, "icon/heart_bss"); }
	// --------------------------------------------------
	public static final class_2960 gui_icon_filterSort() { return method_60655(MOD_ID, "icon/filter_sort"); }
	public static final class_2960 gui_icon_filterGroup() { return method_60655(MOD_ID, "icon/filter_group"); }
	public static final class_2960 gui_icon_filterUnitDist() { return method_60655(MOD_ID, "icon/filter_unit_dist"); }
	public static final class_2960 gui_icon_filterUnitTime() { return method_60655(MOD_ID, "icon/filter_unit_time"); }
	// --------------------------------------------------
	public static final class_2960 gui_icon_faviconCf() { return method_60655(MOD_ID, "icon/favicon_curseforge"); }
	public static final class_2960 gui_icon_faviconMr() { return method_60655(MOD_ID, "icon/favicon_modrinth"); }
	public static final class_2960 gui_icon_faviconWiki() { return method_60655(MOD_ID, "icon/favicon_mcwiki"); }
	// ==================================================
}
