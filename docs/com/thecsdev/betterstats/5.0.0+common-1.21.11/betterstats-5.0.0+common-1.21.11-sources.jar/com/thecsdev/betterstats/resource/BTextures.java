package com.thecsdev.betterstats.resource;

import com.thecsdev.betterstats.BetterStats;
import net.minecraft.class_2960;

import static com.thecsdev.betterstats.BetterStats.MOD_ID;
import static net.minecraft.class_2960.method_60655;

/**
 * {@link BetterStats}'s {@link class_2960}s for resource-pack textures.
 */
public final class BTextures
{
	// ==================================================
	private BTextures() {}
	// ==================================================
	public static final class_2960 icon() { return method_60655(MOD_ID, "icon.png"); }
	// --------------------------------------------------
	public static final class_2960 gui_images_nostatsSilhouette() { return method_60655(MOD_ID, "textures/gui/images/nostats_silhouette.png"); }
	// ==================================================
}
