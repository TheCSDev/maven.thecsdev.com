package com.thecsdev.betterstats.resource.dto.credits;

import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_2561;
import net.minecraft.class_8824;

/**
 * Represents a section in the "Credits" GUI of this mod, which
 * contains multiple {@link CreditsEntry} instances.
 */
public final class CreditsSection
{
	// ================================================== ==================================================
	//                                     CreditsSection IMPLEMENTATION
	// ================================================== ==================================================
	/**
	 * {@link Codec} instance for serializing and deserializing
	 * {@link CreditsSection} instances.
	 */
	public static final Codec<CreditsSection> CODEC = new CodecImpl();
	// --------------------------------------------------
	private final @NotNull  class_2561          name;
	private final @Nullable class_2561          summary;
	private final @NotNull  List<CreditsEntry> entries;
	// ==================================================
	public CreditsSection(
			@NotNull  class_2561          name,
			@Nullable class_2561          summary,
			@NotNull  List<CreditsEntry> entries) throws NullPointerException
	{
		this.name    = Objects.requireNonNull(name);
		this.summary = summary;
		this.entries = Objects.requireNonNull(entries);
	}
	// ==================================================
	/**
	 * The user-friendly name of this credits section.
	 */
	public final @NotNull class_2561 getName() { return this.name; }

	/**
	 * A brief summary or description of this credits section.
	 */
	public final @Nullable class_2561 getSummary() { return this.summary; }

	/**
	 * A collection of {@link CreditsEntry} instances that belong to
	 * this section.
	 */
	public final @NotNull List<CreditsEntry> getEntries() { return this.entries; }
	// ================================================== ==================================================
	//                                          CodecImpl IMPLEMENTATION
	// ================================================== ==================================================
	/**
	 * {@link Codec} implementation for serializing and deserializing
	 * {@link CreditsSection} instances.
	 */
	private static final class CodecImpl implements Codec<CreditsSection>
	{
		// ==================================================
		public final @Override <T> @NotNull DataResult<Pair<CreditsSection, T>> decode(
				@NotNull DynamicOps<T> ops, @NotNull T input)
		{
			try
			{
				return ops.getMap(input).flatMap(map ->
				{
					//obtain property values from the map
					final var name = class_8824.field_46597.parse(ops, map.get("name"));
					final var summary = class_8824.field_46597.parse(ops, map.get("summary")).result();
					final var entries = CreditsEntry.CODEC.listOf().parse(ops, map.get("entries"));

					//name value is required
					if (name.error().isPresent()) //noinspection OptionalGetWithoutIsPresent
						return DataResult.error(() -> name.error().get().message());
					if (entries.error().isPresent()) //noinspection OptionalGetWithoutIsPresent
						return DataResult.error(() -> name.error().get().message());

					//construct and return result
					return DataResult.success(Pair.of(new CreditsSection(
							name.getOrThrow(),
							summary.orElse(null),
							entries.getOrThrow()
					), input));
				});
			}
			catch(Exception e) { return DataResult.error(() -> e.getClass() + ": " + e.getMessage()); }
		}
		// --------------------------------------------------
		public final @Override <T> @NotNull DataResult<T> encode(
				@NotNull CreditsSection input, @NotNull DynamicOps<T> ops, @NotNull T prefix)
		{
			try
			{
				//use a map builder
				final var mapBuilder = ops.mapBuilder();

				//put property values in the map
				mapBuilder.add("name", class_8824.field_46597.encodeStart(ops, input.getName()));
				if (input.getSummary() != null)
					mapBuilder.add("summary", class_8824.field_46597.encodeStart(ops, input.getSummary()));
				mapBuilder.add("entries", CreditsEntry.CODEC.listOf().encodeStart(ops, input.getEntries()));

				//build and return the map
				return mapBuilder.build(prefix);
			}
			catch(Exception e) { return DataResult.error(() -> e.getClass() + ": " + e.getMessage()); }
		}
		// ==================================================
	}
	// ================================================== ==================================================
}
