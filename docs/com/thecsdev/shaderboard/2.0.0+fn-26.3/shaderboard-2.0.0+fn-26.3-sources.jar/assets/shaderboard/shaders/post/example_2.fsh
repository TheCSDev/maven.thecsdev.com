// ==================================================
#version 330
#extension GL_ARB_separate_shader_objects : require
// --------------------------------------------------
#include <minecraft:globals.glsl>
// ==================================================
uniform sampler2D InSampler;
layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;
// --------------------------------------------------
layout(std140) uniform SamplerInfo {
	vec2 OutSize;
	vec2 InSize;
};
// --------------------------------------------------
//binding "u_Payload" (type: "shaderboard:test_complex")
//std140 offsets, in bytes:
//  transform    0..64
//  colorMatrix 64..112
//  color      112..128
//  offset     128..140
//  time       140..144
//  mode       144..148
//  weights    160..224 (float[4], 16-byte stride)
//  inner      224..240
//total: 240 bytes
struct TestInner {
	vec2 scale;
	int  mode;
};
layout(std140) uniform u_Payload {
	mat4      transform;
	mat3      colorMatrix;
	vec4      color;
	vec3      offset;
	float     time;
	int       mode;
	float     weights[4];
	TestInner inner;
};
// --------------------------------------------------
//binding "u_Score" (type: "shaderboard:scoreboard_objective")
layout(std140) uniform u_Score { int score; };
// ==================================================
void main()
{
	// ---------- 1) mat4: rotate + scale the screen-space texture coordinates
	vec2 uv = (transform * vec4(texCoord, 0.0, 1.0)).xy;
	uv += offset.xy;
	uv  = fract(uv); //tile, so the rotation is clearly visible

	// ---------- 2) base color, mat3 channel-mix and vec4 tint
	vec3 rgb = texture(InSampler, uv).rgb;
	rgb  = clamp(colorMatrix * rgb, 0.0, 1.0);
	rgb *= color.rgb;

	// ---------- 3) nested struct: scaled + flippable checkerboard
	vec2  grid    = floor(uv * 8.0 * inner.scale);
	float checker = mod(grid.x + grid.y, 2.0);
	if(inner.mode == 1) checker = 1.0 - checker;
	rgb = mix(rgb, rgb * 0.45, checker * 0.4);

	// ---------- 4) int mode: pick one of four tints
	vec3 tints[4] = vec3[4](
		vec3(1.00, 0.35, 0.35),
		vec3(0.35, 1.00, 0.35),
		vec3(0.35, 0.35, 1.00),
		vec3(1.00, 1.00, 0.35)
	);
	rgb = mix(rgb, rgb * tints[mode % 4] * 1.2, 0.30 + 0.10 * sin(time));

	// ---------- 5) float[4]: four animated bars along the bottom
	for(int i = 0; i < 4; i++)
	{
		float x0 = 0.06 + float(i) * 0.09;
		float x1 = x0 + 0.06;
		float y1 = 0.05 + weights[i] * 0.25;
		if(texCoord.x >= x0 && texCoord.x < x1 &&
		   texCoord.y >= 0.05 && texCoord.y < y1)
			rgb = mix(rgb, vec3(0.95), 0.85);
	}

	// ---------- 6) int scoreboard value: 32-bit binary stripe at the very bottom
	if(texCoord.y >= 0.005 && texCoord.y < 0.030)
	{
		int   bitIndex = 31 - clamp(int(texCoord.x * 32.0), 0, 31);
		float bitValue = float((score >> bitIndex) & 1);
		rgb = mix(rgb, vec3(bitValue), 0.9);
	}

	// ---------- output
	fragColor = vec4(rgb, 1.0);
}
// ==================================================
