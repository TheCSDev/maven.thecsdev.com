package com.thecsdev.shaderboard.client.binding;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.thecsdev.shaderboard.api.client.binding.ShaderboardBinding;
import com.thecsdev.shaderboard.api.client.binding.value.ShaderboardValueType;
import com.thecsdev.shaderboard.api.client.binding.value.ShaderboardValueTypes;
import com.thecsdev.shaderboard.client.registry.ShaderboardBindingTypes;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix3f;
import org.joml.Matrix3fc;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.joml.Vector2f;
import org.joml.Vector2fc;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.joml.Vector4f;
import org.joml.Vector4fc;

import java.util.Objects;

/**
 * <b>Temporary stress-test binding.</b> Not intended to ship.
 * <p>
 * Exposes a struct that contains a matrix, a vector, a scalar, an integer, a
 * fixed-length array and a nested struct, and animates all of them over time.
 * Used to verify that {@link ShaderboardValueTypes} encodes complex layouts
 * correctly and that the GPU buffer is refreshed every frame.
 */
@ApiStatus.Internal
@Environment(EnvType.CLIENT)
public final class TestComplexBinding extends ShaderboardBinding<TestComplexBinding.Payload>
{
	// ==================================================
	/**
	 * {@link MapCodec} implementation for serializing {@link TestComplexBinding} instances.
	 */
	public static final MapCodec<TestComplexBinding> CODEC = RecordCodecBuilder.mapCodec(instance ->
		ShaderboardBinding.baseCodec(instance) //must inherit superclass's CODEC's properties
				.and(Codec.FLOAT.optionalFieldOf("speed", 1.0F).forGetter(TestComplexBinding::getSpeed))
				.apply(instance, TestComplexBinding::new)
	);
	// --------------------------------------------------
	/**
	 * Nested struct type: {@code struct { vec2 scale; int mode; }}, 16 bytes.
	 */
	private static final ShaderboardValueType<Inner> INNER_TYPE = ShaderboardValueTypes.<Inner>struct()
			.member(ShaderboardValueTypes.VEC2, Inner::scale)
			.member(ShaderboardValueTypes.INT,  Inner::mode)
			.build();

	/**
	 * The full payload layout. Expected {@code std140} offsets, in bytes:
	 * <pre>
	 * transform    0..64
	 * colorMatrix 64..112
	 * color      112..128
	 * offset     128..140
	 * time       140..144
	 * mode       144..148
	 * weights    160..224   (float[4], 16-byte stride)
	 * inner      224..240
	 * </pre>
	 * Total size: 240 bytes.
	 */
	private static final ShaderboardValueType<Payload> VALUE_TYPE = ShaderboardValueTypes.<Payload>struct()
			.member(ShaderboardValueTypes.MAT4,          Payload::transform)
			.member(ShaderboardValueTypes.MAT3,          Payload::colorMatrix)
			.member(ShaderboardValueTypes.VEC4,          Payload::color)
			.member(ShaderboardValueTypes.VEC3,          Payload::offset)
			.member(ShaderboardValueTypes.FLOAT,         Payload::time)
			.member(ShaderboardValueTypes.INT,           Payload::mode)
			.member(ShaderboardValueTypes.floatArray(4), Payload::weights)
			.member(INNER_TYPE,                          Payload::inner)
			.build();
	// ==================================================
	private final float speed;
	// --------------------------------------------------
	//scratch values, mutated on every #getValue() call to avoid allocating JOML objects
	private final Matrix4f transform   = new Matrix4f();
	private final Matrix3f colorMatrix = new Matrix3f();
	private final Vector4f color       = new Vector4f();
	private final Vector3f offset      = new Vector3f();
	private final float[]  weights     = new float[4];
	private final Vector2f innerScale  = new Vector2f();
	// ==================================================
	public TestComplexBinding(@NotNull String uniformName, float speed)
			throws NullPointerException, IllegalArgumentException
	{
		super(ShaderboardBindingTypes.TEST_COMPLEX, uniformName);
		this.speed = speed;
	}
	// ==================================================
	public final @Override @NotNull TestComplexBinding clone() {
		return new TestComplexBinding(getUniformName(), getSpeed());
	}
	public final @Override @NotNull ShaderboardValueType<Payload> getValueType() { return VALUE_TYPE; }
	// ==================================================
	/**
	 * Returns this binding's animation speed multiplier.
	 */
	public final float getSpeed() { return this.speed; }
	// ==================================================
	public final @Override @NotNull Payload getValue()
	{
		//seconds elapsed, cycling every 4 minutes and scaled by 'speed'
		final float t = (System.currentTimeMillis() % 240000L) / 1000.0F * this.speed;

		//mat4: rotate + non-uniformly scale around the screen center.
		//(a transposed upload would visibly spin backwards and shear)
		this.transform.identity()
				.translate(0.5F, 0.5F, 0.0F)
				.rotateZ(t * 0.35F)
				.scale(0.75F + 0.25F * (float) Math.sin(t * 0.9F), 0.75F, 1.0F)
				.translate(-0.5F, -0.5F, 0.0F);

		//mat3: hue rotation in the red/green plane.
		//(a transposed upload would make the hue cycle run backwards)
		this.colorMatrix.rotationZ(t * 0.6F);

		//vec4 + vec3
		this.color.set(0.85F, 0.90F, 1.0F, 1.0F);
		this.offset.set(
				(float) Math.sin(t * 0.4F) * 0.05F,
				(float) Math.cos(t * 0.5F) * 0.05F,
				0.0F);

		//float[4]: animated per-element weights
		for(int i = 0; i < this.weights.length; i++)
			this.weights[i] = 0.5F + 0.5F * (float) Math.sin(t * 2.0F + i);

		//nested struct
		this.innerScale.set(
				1.0F + 0.35F * (float) Math.sin(t * 1.7F),
				1.0F + 0.35F * (float) Math.cos(t * 1.3F));

		return new Payload(
				this.transform,
				this.colorMatrix,
				this.color,
				this.offset,
				t,
				(int) (t * 1.5F) % 4,
				this.weights,
				new Inner(this.innerScale, (int) (t * 2.0F) % 2));
	}
	// ================================================== ==================================================
	//                                        Payload IMPLEMENTATION
	// ================================================== ==================================================
	/**
	 * The value {@link TestComplexBinding} resolves: a struct containing a matrix,
	 * a vector, a scalar, an integer, a fixed-length array and a nested struct.
	 */
	public record Payload(
			@NotNull Matrix4fc transform,
			@NotNull Matrix3fc colorMatrix,
			@NotNull Vector4fc color,
			@NotNull Vector3fc offset,
			float time,
			int mode,
			float @NotNull [] weights,
			@NotNull Inner inner) {}

	/**
	 * Nested struct used by {@link Payload}.
	 */
	public record Inner(@NotNull Vector2fc scale, int mode) {}
	// ==================================================
}
