package com.thecsdev.commonmc.api.client.gui.misc;

import com.thecsdev.common.properties.NotNullProperty;
import com.thecsdev.common.util.annotations.Virtual;
import com.thecsdev.commonmc.api.client.gui.TElement;
import com.thecsdev.commonmc.api.client.gui.render.TGuiGraphics;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import org.jetbrains.annotations.NotNull;

/**
 * {@link TElement} that renders a given {@link class_1799} on the screen,
 * like how the game does it in the inventory screen.
 */
@Environment(EnvType.CLIENT)
public @Virtual class TItemElement extends TElement
{
	// ==================================================
	private final NotNullProperty<class_1799> itemStack = new NotNullProperty<>(class_1802.field_8162.method_7854());
	// ==================================================
	public TItemElement() {
		super();
		//this element should not be focusable or hoverable
		focusableProperty().set(false, TItemElement.class);
		hoverableProperty().set(false, TItemElement.class);
	}
	// ==================================================
	/**
	 * Returns the {@link NotNullProperty} holding the {@link class_1799}
	 * that is to be rendered by this {@link TItemElement}.
	 */
	public final NotNullProperty<class_1799> itemStackProperty() { return this.itemStack; }
	// ==================================================
	public @Virtual @Override void renderCallback(@NotNull TGuiGraphics pencil) {
		final var bb = getBounds();
		pencil.renderItem(this.itemStack.get(), bb.x, bb.y, bb.width, bb.height);
	}
	// ==================================================
}
