package com.thecsdev.commonmc.api.client.gui.misc;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.thecsdev.common.properties.IntegerProperty;
import com.thecsdev.common.properties.NotNullProperty;
import com.thecsdev.common.util.annotations.Virtual;
import com.thecsdev.commonmc.api.client.gui.TElement;
import com.thecsdev.commonmc.api.client.gui.render.TGuiGraphics;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import static net.minecraft.class_10799.field_56883;
import static net.minecraft.class_1060.field_5285;

/**
 * A {@link TElement} whose sole purpose is to render a sprite/texture.
 */
@Environment(EnvType.CLIENT)
public @Virtual class TTextureElement extends TElement
{
	// ================================================== ==================================================
	//                                    TTextureElement IMPLEMENTATION
	// ================================================== ==================================================
	private final NotNullProperty<RenderPipeline>   renderPipeline = new NotNullProperty<>(field_56883);
	private final NotNullProperty<class_2960>       texture        = new NotNullProperty<>(field_5285);
	private final NotNullProperty<Mode>             mode           = new NotNullProperty<>(Mode.TEXTURE);
	private final IntegerProperty                   color          = new IntegerProperty(0xFFFFFFFF);
	// ==================================================
	public TTextureElement() { this(null); }
	public TTextureElement(@Nullable class_2960 texture)
	{
		//initialize the texture
		if(texture != null) {
			this.texture.getHandle().set(texture);
			this.mode.getHandle().set(texture.method_12832().endsWith(".png") ? Mode.TEXTURE : Mode.GUI_SPRITE);
		}
		//this element is not supposed to be focusable or hoverable by default
		focusableProperty().set(false, TTextureElement.class);
		hoverableProperty().set(false, TTextureElement.class);
	}
	// ==================================================
	/**
	 * Returns the {@link NotNullProperty} holding the {@link RenderPipeline}
	 * used to render this {@link TTextureElement}.
	 */
	public final NotNullProperty<RenderPipeline> renderPipelineProperty() { return this.renderPipeline; }

	/**
	 * Returns the {@link NotNullProperty} holding the sprite/texture.
	 */
	public final NotNullProperty<class_2960> textureProperty() { return this.texture; }

	/**
	 * Returns the {@link NotNullProperty} holding the rendering {@link Mode}
	 * that determines how this {@link TTextureElement} is rendered.
	 */
	public final NotNullProperty<Mode> modeProperty() {return this.mode; }

	/**
	 * Returns the {@link IntegerProperty} holding the sprite's color.
	 */
	public final IntegerProperty colorProperty() { return this.color; }
	// ==================================================
	public @Virtual @Override void renderCallback(@NotNull TGuiGraphics pencil)
	{
		//get necessary property values
		@NotNull  var pipeline = this.renderPipeline.get();
		@Nullable var sprite   = this.texture.get();
		          int color    = this.color.getI();

		//get bounding box and draw
		final var bb = getBounds();
		switch(this.mode.get()) {
			case TEXTURE -> pencil.drawTexture(pipeline, sprite, bb.x, bb.y, bb.width, bb.height, color);
			case GUI_SPRITE -> pencil.drawGuiSprite(pipeline, sprite, bb.x, bb.y, bb.width, bb.height, color);
		}
	}
	// ================================================== ==================================================
	//                                               Mode IMPLEMENTATION
	// ================================================== ==================================================
	/**
	 * The method used to render a {@link TTextureElement}.
	 * @see TGuiGraphics#drawTexture(RenderPipeline, class_2960, int, int, int, int, int)
	 * @see TGuiGraphics#drawGuiSprite(RenderPipeline, class_2960, int, int, int, int, int)
	 */
	public static enum Mode
	{
		/**
		 * The {@link TTextureElement} is rendered using {@link TGuiGraphics#drawTexture(class_2960, int, int, int, int, int)}.
		 */
		TEXTURE,

		/**
		 * The {@link TTextureElement} is rendered using {@link TGuiGraphics#drawGuiSprite(class_2960, int, int, int, int, int)}.
		 */
		GUI_SPRITE
	}
	// ================================================== ==================================================
}
