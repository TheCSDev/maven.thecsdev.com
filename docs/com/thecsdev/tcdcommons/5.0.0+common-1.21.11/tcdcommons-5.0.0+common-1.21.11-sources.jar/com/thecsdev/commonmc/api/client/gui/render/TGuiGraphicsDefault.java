package com.thecsdev.commonmc.api.client.gui.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import static net.minecraft.class_2960.method_60656;

/**
 * The default implementation of {@link TGuiGraphics}, using vanilla game's
 * mechanisms to render and draw GUI elements.
 *
 * @apiNote In the event of a mod-breaking update, this abstraction layer
 * allows for an easier rewrite and portability.
 */
@ApiStatus.Internal
@Environment(EnvType.CLIENT)
final class TGuiGraphicsDefault extends TGuiGraphics
{
	// ==================================================
	public TGuiGraphicsDefault(class_332 drawContext, int mouseX, int mouseY, float deltaTicks) {
		super(drawContext, mouseX, mouseY, deltaTicks);
	}
	// ==================================================
	public final @Override void fillColor(int x, int y, int width, int height, int color) {
		getNative().method_25294(x, y, x + width, y + height, color);
	}
	// --------------------------------------------------
	public final @Override void drawTexture(
			@NotNull RenderPipeline renderPipeline, @NotNull class_2960 id,
			int x, int y, int width, int height,
			float uvX, float uvY, int uvWidth, int uvHeight,
			int textureWidth, int textureHeight, int color)
	{
		getNative().method_25293(renderPipeline, id, x, y, uvX, uvY, width, height, uvWidth, uvHeight, textureWidth, textureHeight, color);
	}

	public final @Override void drawGuiSprite(
			@NotNull RenderPipeline renderPipeline, @NotNull class_2960 id,
			int x, int y, int width, int height, int color)
	{
		getNative().method_52707(renderPipeline, id, x, y, width, height, color);
	}
	// --------------------------------------------------
	private static final @ApiStatus.Internal class_2960[] SPRITE_BUTTONS = new class_2960[] {
		method_60656("widget/button"),
		method_60656("widget/button_highlighted"),
		method_60656("widget/button_disabled")
	};

	public final @Override void drawButton(int x, int y, int width, int height, int color, boolean enabled, boolean highlighted) {
		if(!enabled)         drawGuiSprite(SPRITE_BUTTONS[2], x, y, width, height, color);
		else if(highlighted) drawGuiSprite(SPRITE_BUTTONS[1], x, y, width, height, color);
		else                 drawGuiSprite(SPRITE_BUTTONS[0], x, y, width, height, color);
	}

	private static final @ApiStatus.Internal class_2960[] SPRITE_CHECKBOXES = new class_2960[] {
		method_60656("widget/checkbox"),
		method_60656("widget/checkbox_highlighted"),
		method_60656("widget/checkbox_selected"),
		method_60656("widget/checkbox_selected_highlighted")
	};

	public final @Override void drawCheckbox(int x, int y, int width, int height, int color, boolean enabled, boolean highlighted, boolean checked) {
		if(!enabled) drawGuiSprite(SPRITE_CHECKBOXES[0], x, y, width, height, color);
		else         drawGuiSprite(SPRITE_CHECKBOXES[checked ? (highlighted ? 3 : 2) : (highlighted ? 1 : 0)], x, y, width, height, color);
	}
	// ==================================================
}
