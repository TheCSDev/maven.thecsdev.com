package com.thecsdev.commonmc.api.client.gui.screen;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_437;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.Nullable;

/**
 * This {@code interface} is implemented by {@link TScreen}s that
 * can provide information about the last {@link class_437} instance
 * that was open before them.
 * <p>
 * This is generally used to open the previous screen when closing
 * the current one.
 *
 * @see class_310#method_1507(class_437)
 * @see TScreen#close()
 */
@Environment(EnvType.CLIENT)
public interface ILastScreenProvider
{
	// ==================================================
	/**
	 * Returns the last {@link class_437} instance that was open before this one.
	 */
	public @Nullable class_437 getLastScreen();
	// ==================================================
	/**
	 * A utility method that retrieves the last {@link class_437}
	 * from a {@link TScreen} instance.
	 * @param screen The {@link TScreen} instance.
	 */
	@Contract("null -> null; _ -> _")
	public static @Nullable class_437 getLastScreen(@Nullable TScreen screen) {
		if(screen == null) return null;
		return (screen instanceof ILastScreenProvider lsp) ? lsp.getLastScreen() : getLastScreen(screen.getAsScreen());
	}

	/**
	 * A utility method that retrieves the last {@link class_437}
	 * from a {@link class_437} instance.
	 * @param screen The {@link class_437} instance.
	 */
	@Contract("null -> null; _ -> _")
	public static @Nullable class_437 getLastScreen(@Nullable class_437 screen) {
		if(screen == null) return null;
		return (screen instanceof ILastScreenProvider lsp) ? lsp.getLastScreen() : null;
	}
	// ==================================================
}
