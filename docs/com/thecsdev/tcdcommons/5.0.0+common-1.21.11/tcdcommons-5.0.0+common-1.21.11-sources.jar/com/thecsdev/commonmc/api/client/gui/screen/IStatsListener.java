package com.thecsdev.commonmc.api.client.gui.screen;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2617;
import net.minecraft.class_310;
import net.minecraft.class_437;

/**
 * This {@code interface} is implemented by {@link class_437}s and {@link TScreen}s
 * that wish to receive callback method calls for whenever the server sends a
 * {@link class_2617} to the client.
 */
@Environment(EnvType.CLIENT)
public interface IStatsListener
{
	// ==================================================
	/**
	 * Invoked automatically on {@link class_310}'s {@link Thread} whenever
	 * the server sends a {@link class_2617} to the client.
	 * @see class_310#execute(Runnable)
	 */
	public void statsReceivedCallback();
	// ==================================================
}
