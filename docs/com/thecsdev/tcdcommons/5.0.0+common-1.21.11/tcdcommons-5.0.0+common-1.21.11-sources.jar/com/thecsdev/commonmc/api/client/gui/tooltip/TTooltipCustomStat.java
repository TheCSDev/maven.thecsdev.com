package com.thecsdev.commonmc.api.client.gui.tooltip;

import com.thecsdev.commonmc.api.stats.util.CustomStat;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2960;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

import static com.thecsdev.commonmc.TCDCommonsConfig.FLAG_DEV_ENV;
import static net.minecraft.class_124.*;
import static net.minecraft.class_2561.method_43470;

/**
 * {@link TTooltip} that shows statistics about a given "custom stat",
 * also known as "general stat", aka {@link class_2960}.
 */
@Environment(EnvType.CLIENT)
final @ApiStatus.Internal class TTooltipCustomStat extends TTooltipLabel
{
	// ==================================================
	private final @NotNull CustomStat stat;
	// ==================================================
	TTooltipCustomStat(@NotNull CustomStat stat) throws NullPointerException
	{
		//not null assertions
		this.stat = Objects.requireNonNull(stat);

		//construct the label tooltip text
		{
			//start constructing the tooltip text
			final var tt = method_43470("");
			tt.method_10852(method_43470("").method_10852(stat.getSubjectDisplayName()).method_27692(field_1054)).method_27693("\n");
			tt.method_10852(method_43470("K: " + stat.getSubjectID()).method_27692(field_1080)).method_27693("\n");
			tt.method_10852(method_43470("V: " + stat.getSubject()).method_27692(field_1080));
			tt.method_27693("\n\n");

			tt.method_10852(method_43470(stat.getValueF()).method_27692(field_1065));
			if(FLAG_DEV_ENV) tt.method_10852(method_43470(" (" + stat.getValue() + ")").method_27692(field_1080));

			//set tooltip text
			textProperty().set(tt, TTooltipCustomStat.class);
		}
	}
	// ==================================================
	/**
	 * Returns the {@link CustomStat} this tooltip is about.
	 */
	public final @NotNull CustomStat getStat() { return stat; }
	// ==================================================
}
