package com.thecsdev.commonmc.api.client.gui.tooltip;

import com.thecsdev.commonmc.api.stats.util.SubjectStats;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

import static com.thecsdev.commonmc.api.stats.IStatsProvider.getStatTypeName;
import static net.minecraft.class_2561.method_43470;

/**
 * {@link TTooltip} that shows statistics related to a given {@link SubjectStats}.
 */
@Environment(EnvType.CLIENT)
final @ApiStatus.Internal class TTooltipSubjectStats extends TTooltipLabel
{
	// ==================================================
	private final @NotNull SubjectStats<?> stats;
	// ==================================================
	public TTooltipSubjectStats(@NotNull SubjectStats<?> stats) throws NullPointerException
	{
		//initialize fields
		this.stats = Objects.requireNonNull(stats);

		//construct the label tooltip text
		{
			//start constructing the tooltip text
			final var tt = method_43470("");
			tt.method_10852(method_43470("").method_10852(stats.getSubjectDisplayName()).method_27692(class_124.field_1054)).method_27693("\n");
			tt.method_10852(method_43470(stats.getSubjectID().toString()).method_27692(class_124.field_1080));
			tt.method_27693("\n\n");

			//add block stats
			final var entries = stats.getValuesF().entrySet().iterator();
			while(entries.hasNext()) {
				final var entry  = entries.next();
				final var stName = getStatTypeName(entry.getKey().method_14949());
				tt.method_10852(method_43470("- ").method_27692(class_124.field_1054));
				tt.method_10852(stName);
				tt.method_10852(method_43470(" - ").method_27692(class_124.field_1054));
				tt.method_10852(method_43470(entry.getValue()).method_27692(class_124.field_1065));
				if(entries.hasNext()) tt.method_27693("\n");
			}

			//set the tooltip text
			textProperty().set(tt, TTooltipSubjectStats.class);
		}
	}
	// ==================================================
	/**
	 * Returns the {@link SubjectStats} related to this {@link TTooltipLabel}.
	 */
	public final @NotNull SubjectStats<?> getStats() { return this.stats; }
	// ==================================================
}
