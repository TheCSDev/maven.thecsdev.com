package com.thecsdev.commonmc.api.client.gui.util;

import com.thecsdev.commonmc.api.client.gui.TElement;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_11876;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

/**
 * An enumeration representing different types of mouse cursors that can be used in the
 * graphical user interface (GUI).
 * @see TElement#getCursor()
 */
@Environment(EnvType.CLIENT)
public enum CursorType
{
	// ==================================================
	/**
	 * Default cursor icon. Same as {@link #ARROW}.
	 */
	DEFAULT(net.minecraft.class_11875.field_62449),

	/**
	 * Standard arrow. Default pointer.<br>
	 * General navigation, for non-interactive elements.
	 */
	ARROW(class_11876.field_62452),

	/**
	 * Vertical line with serifs.<br>
	 * Indicates an editable text field. For text selection and insertion.
	 */
	IBEAM(class_11876.field_62453),

	/**
	 * Crosshair. Thin plus-shaped icon.<br>
	 * For precise selection, drawing, or targeting.
	 */
	CROSSHAIR(class_11876.field_62454),

	/**
	 * Hand Pointer with index finger pointing up.<br>
	 * Indicating a clickable link or interactive UI element.
	 */
	POINTING_HAND(class_11876.field_62455),

	/**
	 * Horizontal double arrow (↔).<br>
	 * For resizing a window or element horizontally.
	 */
	RESIZE_NS(class_11876.field_62456),

	/**
	 * Vertical double arrow (↕).<br>
	 * For resizing a window or element vertically.
	 */
	RESIZE_EW(class_11876.field_62457),

	/**
	 * Four-way arrow (↔ with ↕ overlaid).<br>
	 * For moving an element or resizing in any direction.
	 */
	RESIZE_ALL(class_11876.field_62458),

	/**
	 * Slashed circle (circle with a diagonal line ⊘).<br>
	 * Indicating an action cannot be performed, like clicking or during drag-and-drop operations.
	 */
	NOT_ALLOWED(class_11876.field_62459);
	// ==================================================
	private final @NotNull net.minecraft.class_11875 nativeType;
	// ==================================================
	CursorType(@NotNull net.minecraft.class_11875 nativeType) {
		this.nativeType = nativeType;
	}
	// ==================================================
	/**
	 * Returns the game's corresponding {@link net.minecraft.class_11875}
	 * intance that is represented by this {@link CursorType}.
	 * <p>
	 * Used internally by this API mod to display said cursor on screen.
	 */
	@ApiStatus.Internal
	public final net.minecraft.class_11875 getNative() {
		return this.nativeType;
	}
	// ==================================================
}
