package com.thecsdev.commonmc.api.client.registry;

import com.thecsdev.commonmc.TCDCommons;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2370;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_437;
import net.minecraft.class_7923;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import static com.mojang.serialization.Lifecycle.stable;
import static com.thecsdev.commonmc.TCDCommons.MOD_ID;
import static net.minecraft.class_2960.method_60655;
import static net.minecraft.class_5321.method_29180;

/**
 * {@link TCDCommons}'s client-sided registries for adding features to the mod.
 * <p>
 * <b>Important note:</b><br>
 * These {@link class_2378}s are <b>NOT</b> registered in the game's <b>ROOT</b>
 * {@link class_7923#field_41167}! Avoid any and all operations that involve
 * the game's <b>ROOT</b> registry!
 */
@Environment(EnvType.CLIENT)
public final class TClientRegistries
{
	// ==================================================
	private TClientRegistries() {}
	// ==================================================
	/**
	 * {@link class_437}s that are to be rendered on the game's HUD (heads-up display).
	 */
	public static final class_2378<class_437> HUD_SCREEN;
	// ==================================================
	public static final void bootstrap() { /*invokes <clinit>*/ }
	static {
		//create registry instances
		HUD_SCREEN = new class_2370<>(method_29180(id("hud_screen")), stable());
	}
	// --------------------------------------------------
	private static final @ApiStatus.Internal class_2960 id(@NotNull String id) {
		return method_60655(MOD_ID, id);
	}
	// ==================================================
}
