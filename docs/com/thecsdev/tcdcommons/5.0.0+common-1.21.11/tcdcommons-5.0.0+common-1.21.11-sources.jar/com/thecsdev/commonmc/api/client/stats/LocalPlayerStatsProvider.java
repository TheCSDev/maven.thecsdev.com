package com.thecsdev.commonmc.api.client.stats;

import com.thecsdev.commonmc.api.stats.IStatsProvider;
import com.thecsdev.commonmc.api.stats.PlayerStatsProvider;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_310;
import net.minecraft.class_3445;
import net.minecraft.class_3448;
import net.minecraft.class_3469;
import net.minecraft.class_746;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

/**
 * A {@link IStatsProvider} that provides statistics of a {@link class_746}.
 */
@Environment(EnvType.CLIENT)
public final class LocalPlayerStatsProvider extends PlayerStatsProvider<@NotNull class_746>
{
	// ==================================================
	private final class_746  player;
	// ==================================================
	private final class_3469 _statsCounter;
	// ==================================================
	private LocalPlayerStatsProvider(@NotNull class_746 player) throws NullPointerException {
		this.player        = Objects.requireNonNull(player);
		this._statsCounter = player.method_3143();
	}
	// ==================================================
	public final @Override class_746 getPlayer() { return this.player; }
	// --------------------------------------------------
	public final @Override <T> int getIntValue(class_3445<T> stat) { return this._statsCounter.method_15025(stat); }
	public final @Override <T> int getIntValue(@NotNull class_3448<T> type, @NotNull T subject) { return this._statsCounter.method_15024(type, subject); }
	// ==================================================
	public final @Override int hashCode() { return this.player.hashCode(); }
	public final @Override boolean equals(Object obj) {
		if(obj == this) return true;
		if(obj == null || obj.getClass() != getClass()) return false;
		return (((LocalPlayerStatsProvider)obj).player == this.player);
	}
	// ==================================================
	/**
	 * Creates a {@link LocalPlayerStatsProvider} instance based on a {@link class_746}.
	 * @param player The {@link class_746}.
	 * @throws NullPointerException If the argument is {@code null}.
	 */
	public static final LocalPlayerStatsProvider of(@NotNull class_746 player) throws NullPointerException {
		return new LocalPlayerStatsProvider(player);
	}

	/**
	 * Creates a {@link LocalPlayerStatsProvider} instance using {@link class_310#field_1724}.
	 * @throws NullPointerException If {@link class_310#field_1724} is {@code null}.
	 */
	public static final LocalPlayerStatsProvider ofCurrentLocalPlayer() throws NullPointerException {
		return new LocalPlayerStatsProvider(Objects.requireNonNull(class_310.method_1551().field_1724));
	}
	// ==================================================
}
