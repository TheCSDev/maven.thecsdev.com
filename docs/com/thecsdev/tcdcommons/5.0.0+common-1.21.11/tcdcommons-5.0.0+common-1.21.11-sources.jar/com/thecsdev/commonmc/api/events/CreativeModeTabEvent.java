package com.thecsdev.commonmc.api.events;

import dev.architectury.event.Event;
import dev.architectury.event.EventFactory;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_7225;
import net.minecraft.class_7699;
import net.minecraft.class_7706;

/**
 * {@link Event}s related to {@link class_1761} / {@link class_7706}.
 */
public final class CreativeModeTabEvent
{
	// ==================================================
	private CreativeModeTabEvent() {}
	// ==================================================
	/**
	 * This {@link Event} is invoked whenever {@link class_1792}s are reorganized into {@link class_1761}s.
	 * <p>
	 * In other words, whenever the following method is invoked:
	 * {@link class_7706#method_47330(class_7699, boolean, class_7225.class_7874)}.
	 *
	 * @see RebuildContents#invoke(class_7699, boolean, class_7225.class_7874)
	 */
	public static final Event<RebuildContents> REBUILD_CONTENTS_POST = EventFactory.createLoop();
	// ==================================================
	public static interface RebuildContents
	{
		/**
		 * See {@link CreativeModeTabEvent#REBUILD_CONTENTS_POST}.
		 * @param enabledFeatures The <a href="https://www.minecraft.net/en-us/article/testing-new-minecraft-features/feature-toggles-java-edition">currently enabled feature flags</a>.
		 * @param operatorEnabled Whether the "Operator items" {@link class_1761} is enabled.
		 * @param lookup <i>Dev note: I have no idea what this is. May be useful though.</i>
		 */
		void invoke(class_7699 enabledFeatures, boolean operatorEnabled, class_7225.class_7874 lookup);
	}
	// ==================================================
}
