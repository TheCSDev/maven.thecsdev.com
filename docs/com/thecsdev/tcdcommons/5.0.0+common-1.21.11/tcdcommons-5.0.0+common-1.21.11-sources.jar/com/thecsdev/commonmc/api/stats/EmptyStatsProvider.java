package com.thecsdev.commonmc.api.stats;

import net.minecraft.class_3445;

/**
 * A {@link IStatsProvider} that always returns {@code 0} for every single stat.
 */
public final class EmptyStatsProvider implements IStatsProvider
{
	// ==================================================
	/**
	 * The main instance of {@link EmptyStatsProvider}.
	 */
	public static final IStatsProvider INSTANCE = new EmptyStatsProvider();
	// ==================================================
	private EmptyStatsProvider() {}
	// ==================================================
	public final @Override <T> int getIntValue(class_3445<T> stat) { return 0; }
	// ==================================================
}
