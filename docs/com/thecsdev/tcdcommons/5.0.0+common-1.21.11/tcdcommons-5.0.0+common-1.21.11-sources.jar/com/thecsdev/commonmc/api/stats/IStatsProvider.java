package com.thecsdev.commonmc.api.stats;

import com.thecsdev.common.util.annotations.Virtual;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.Objects;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3445;
import net.minecraft.class_3448;
import net.minecraft.class_3469;
import net.minecraft.class_5250;
import net.minecraft.class_7923;

/**
 * An abstraction layer over the game's native {@link class_3469} mechanism,
 * for reading statistics data, primarily about players.
 */
public interface IStatsProvider
{
	// ==================================================
	/**
	 * Returns the {@link Integer} value of a given {@link class_3445}.
	 * @param stat The {@link class_3445} whose value is to be obtained.
	 * @see class_3469
	 */
	public abstract <T> int getIntValue(class_3445<T> stat);

	/**
	 * Returns the {@link Integer} value of a given {@link class_3448} and its corresponding {@link class_3445}.
	 * @param type The {@link class_3448}.
	 * @param subject The subject about whom stat value is to be obtained.
	 * @see class_3469
	 * @apiNote You should not override this, as it calls {@link #getIntValue(class_3445)} by default.
	 */
	default @Virtual <T> int getIntValue(@NotNull class_3448<T> type, @NotNull T subject)
			throws NullPointerException
	{
		Objects.requireNonNull(type);
		Objects.requireNonNull(subject);
		return getIntValue(type.method_14956(subject));
	}
	// ==================================================
	/**
	 * Returns an unmodifiable {@link List} of all registered {@link class_3448}s
	 * related to {@link class_1792}s.
	 */
	@SuppressWarnings("unchecked")
	public static List<class_3448<class_1792>> getItemStatTypes() {
		return class_7923.field_41193.method_10220()
				.filter(st -> st.method_14959() == class_7923.field_41178)
				.map(st -> (class_3448<class_1792>) st)
				.toList();
	}

	/**
	 * Returns an unmodifiable {@link List} of all registered {@link class_3448}s
	 * related to {@link class_2248}s.
	 */
	@SuppressWarnings("unchecked")
	public static List<class_3448<class_2248>> getBlockStatTypes() {
		return class_7923.field_41193.method_10220()
				.filter(st -> st.method_14959() == class_7923.field_41175)
				.map(st -> (class_3448<class_2248>) st)
				.toList();
	}

	/**
	 * Returns an unmodifiable {@link List} of all registered {@link class_3448}s
	 * related to {@link class_1299}s.
	 */
	@SuppressWarnings("unchecked")
	public static List<class_3448<class_1299<?>>> getEntityStatTypes() {
		return class_7923.field_41193.method_10220()
				.filter(st -> st.method_14959() == class_7923.field_41177)
				.map(st -> (class_3448<class_1299<?>>) st)
				.toList();
	}
	// --------------------------------------------------
	/**
	 * Returns the display name of a given {@link class_3448}.
	 * @throws NullPointerException If the {@link class_3448} is not registered.
	 */
	public static class_2561 getStatTypeName(class_3448<?> statType) throws NullPointerException
	{
		//obtain the vanilla translation key
		final var stId            = Objects.requireNonNull(class_7923.field_41193.method_10221(statType));
		final var stTextKey       = String.format("stat_type.%s.%s", stId.method_12836(), stId.method_12832());
		final var stTextKeyModded = "tcdcommons." + stTextKey;

		//prioritize using modded translation key when available
		final var lang = class_2477.method_10517();
		return lang.method_4678(stTextKeyModded) ?
				class_2561.method_43471(stTextKeyModded) : //use modded when available
				(lang.method_4678(stTextKey) ?                    //else use vanilla only if it exists
						class_2561.method_43471(stTextKey) :
						class_2561.method_43470(stTextKeyModded)); //guide user to define modded translation
	}

	/**
	 * Returns the display name of a given "custom stat", also known as
	 * "general stat" in the GUI statistics menu.
	 * @param customStat The custom/general stat.
	 * @throws NullPointerException If the argument is {@code null}.
	 */
	public static class_5250 getCustomStatName(class_2960 customStat) throws NullPointerException {
		return class_2561.method_43471("stat." + customStat.toString().replace(':', '.'));
	}
	// ==================================================
}
