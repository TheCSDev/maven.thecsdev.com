package com.thecsdev.commonmc.api.stats;

import net.minecraft.class_1657;

/**
 * A {@link IStatsProvider} that is related to a {@link class_1657} entity.
 */
public abstract class PlayerStatsProvider<P extends class_1657> implements IStatsProvider
{
	// ==================================================
	/**
	 * Returns the {@link class_1657} instance this {@link PlayerStatsProvider} is related to.
	 */
	public abstract P getPlayer();
	// ==================================================
}
