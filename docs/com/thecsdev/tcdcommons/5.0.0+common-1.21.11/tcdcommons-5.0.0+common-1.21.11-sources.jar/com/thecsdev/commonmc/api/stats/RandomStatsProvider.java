package com.thecsdev.commonmc.api.stats;

import java.util.Random;
import net.minecraft.class_3445;

/**
 * A {@link IStatsProvider} that always returns random statistics.
 */
public final class RandomStatsProvider implements IStatsProvider
{
	// ==================================================
	/**
	 * The main instance of {@link RandomStatsProvider}.
	 */
	public static final RandomStatsProvider INSTANCE = new RandomStatsProvider();
	// --------------------------------------------------
	private final Random random = new Random();
	// ==================================================
	private RandomStatsProvider() {}
	// ==================================================
	public final @Override <T> int getIntValue(class_3445<T> stat)  { return this.random.nextInt(0, Integer.MAX_VALUE); }
	// ==================================================
}
