package com.thecsdev.commonmc.api.stats;

import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import net.minecraft.class_3222;
import net.minecraft.class_3442;
import net.minecraft.class_3445;
import net.minecraft.class_3448;

/**
 * A {@link IStatsProvider} that provides statistics of a {@link class_3222}.
 */
public final class ServerPlayerStatsProvider extends PlayerStatsProvider<@NotNull class_3222>
{
	// ==================================================
	private final class_3222       player;
	// ==================================================
	private final class_3442 _statsCounter;
	// ==================================================
	private ServerPlayerStatsProvider(@NotNull class_3222 player) throws NullPointerException {
		this.player        = Objects.requireNonNull(player);
		this._statsCounter = player.method_14248();
	}
	// ==================================================
	public final @Override class_3222 getPlayer() { return this.player; }
	// --------------------------------------------------
	public final @Override <T> int getIntValue(class_3445<T> stat) { return this._statsCounter.method_15025(stat); }
	public final @Override <T> int getIntValue(@NotNull class_3448<T> type, @NotNull T subject) { return this._statsCounter.method_15024(type, subject); }
	// ==================================================
	public final @Override int hashCode() { return this.player.hashCode(); }
	public final @Override boolean equals(Object obj) {
		if(obj == this) return true;
		if(obj == null || obj.getClass() != getClass()) return false;
		return (((ServerPlayerStatsProvider)obj).player == this.player);
	}
	// ==================================================
	/**
	 * Creates a {@link ServerPlayerStatsProvider} instance based on a {@link class_3222}.
	 * @param player The {@link class_3222}.
	 */
	public static final ServerPlayerStatsProvider of(@NotNull class_3222 player) throws NullPointerException {
		return new ServerPlayerStatsProvider(player);
	}
	// ==================================================
}
