package com.thecsdev.commonmc.api.stats.util;

import com.thecsdev.commonmc.api.stats.IStatsProvider;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Predicate;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_3445;
import net.minecraft.class_3468;
import net.minecraft.class_7923;

import static net.minecraft.class_7923.field_41175;

/**
 * {@link SubjectStats} utility implementation for reading statistics
 * about a given {@link class_2248}.
 */
public final class BlockStats extends SubjectStats<class_2248>
{
	// ==================================================
	private ItemStats itemStats;
	// ==================================================
	/**
	 * @throws NullPointerException  If an argument is {@code null}.
	 * @throws IllegalStateException If the subject is not properly registered in the game's registries.
	 */
	public BlockStats(
			@NotNull class_2248 subject,
			@NotNull IStatsProvider statsProvider) throws NullPointerException, IllegalStateException {
		super(class_7923.field_41175, subject, statsProvider);
	}
	// ==================================================
	public final @Override @NotNull class_2561 getSubjectDisplayName() { return getSubject().method_9518(); }
	public final @Override @NotNull LinkedHashMap<class_3445<class_2248>, Integer> getValues() {
		final var subject = getSubject();
		final var map     = new LinkedHashMap<class_3445<class_2248>, Integer>();
		for(final var st : IStatsProvider.getBlockStatTypes())
			map.put(st.method_14956(subject), getStatsProvider().getIntValue(st, subject));
		return map;
	}
	// ==================================================
	/**
	 * Returns the {@link ItemStats} of the {@link #getSubject()}'s
	 * corresponding {@link class_1792}.
	 */
	public final @NotNull ItemStats getItemStats() {
		if(this.itemStats == null)
			this.itemStats = new ItemStats(getSubject().method_8389(), getStatsProvider());
		return this.itemStats;
	}
	// ==================================================
	/**
	 * Returns the value of {@link class_3468#field_15427}.
	 */
	public final int getTimesMined() { return getStatsProvider().getIntValue(class_3468.field_15427, getSubject()); }
	// ==================================================
	/**
	 * Obtains a list of all {@link BlockStats}.
	 * @param statsProvider The {@link IStatsProvider} instance.
	 * @param predicate An optional {@link Predicate} for filtering the stats.
	 * @param comparator An optional {@link Comparator} for sorting the list.
	 * @throws NullPointerException If a {@link NotNull} argument is {@code null}.
	 */
	public static final Collection<BlockStats> getBlockStats(
			@NotNull IStatsProvider statsProvider,
			@Nullable Predicate<BlockStats> predicate,
			@Nullable Comparator<BlockStats> comparator) throws NullPointerException
	{
		//not null requirements
		Objects.requireNonNull(statsProvider);
		//initialize and populate the list
		final var result = new ArrayList<BlockStats>((predicate == null) ? field_41175.method_10204() : 0);
		for(final var statSubject : field_41175) {
			final var stat = new BlockStats(statSubject, statsProvider);
			if(predicate != null && !predicate.test(stat)) continue;
			result.add(stat);
		}
		//sort the list based on display names
		if(comparator != null) result.sort(comparator);
		//return the result
		return result;
	}
	// ==================================================
}
