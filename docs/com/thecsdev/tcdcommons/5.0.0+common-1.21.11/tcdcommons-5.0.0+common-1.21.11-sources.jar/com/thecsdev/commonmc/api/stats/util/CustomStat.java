package com.thecsdev.commonmc.api.stats.util;

import com.thecsdev.commonmc.api.stats.IStatsProvider;
import com.thecsdev.commonmc.mixin.hooks.AccessorStat;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Predicate;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3445;
import net.minecraft.class_3446;

import static net.minecraft.class_7923.field_41183;
import static net.minecraft.class_3468.field_15419;

/**
 * {@link SubjectStats} utility implementation for reading statistics
 * about a given "General" (also known as "Custom") stat.
 */
public final class CustomStat extends SubjectStats<class_2960>
{
	// ==================================================
	private final @NotNull class_2561              subjectName;
	private final @NotNull class_3445<class_2960> stat;
	private final @NotNull class_3446          statFormatter;
	// ==================================================
	/**
	 * @throws NullPointerException If an argument is {@code null}.
	 * @throws IllegalStateException If the subject is not properly registered in the game's registries.
	 */
	public CustomStat(
			@NotNull class_2960 subject,
			@NotNull IStatsProvider statsProvider) throws NullPointerException, IllegalStateException {
		super(field_41183, subject, statsProvider);
		this.subjectName   = IStatsProvider.getCustomStatName(subject);
		this.stat          = field_15419.method_14956(subject);
		final var f        = ((AccessorStat)(Object)this.stat).getFormatter();
		this.statFormatter = (f != null) ? f : class_3446.field_16975;
	}
	// ==================================================
	public final @Override @NotNull class_2561 getSubjectDisplayName() { return this.subjectName; }
	public final @Override @NotNull LinkedHashMap<class_3445<class_2960>, Integer> getValues() {
		final var map = new LinkedHashMap<class_3445<class_2960>, Integer>();
		map.put(this.stat, getValue());
		return map;
	}
	public final @Override boolean isEmpty() { return getValue() == 0; }
	// ==================================================
	/**
	 * Returns the raw (unformatted) numeric value of the "General" stat.
	 */
	public final int getValue() { return getStatsProvider().getIntValue(this.stat); }

	/**
	 * Returns {@link #getValue()} formatted using {@link class_3445#method_14953(int)}.
	 */
	public final @NotNull String getValueF() { return this.statFormatter.format(getValue()); }

	/**
	 * Returns {@link #getValue()} formatted using a custom formatter.
	 * @param formatter The {@link StatFormatterOverride} to use. If {@code null}, the default one is used.
	 */
	public final @NotNull String getValueF(@Nullable StatFormatterOverride formatter) {
		if(formatter == null) formatter = StatFormatterOverride.DEFAULT;
		return formatter.format(this.statFormatter, getValue());
	}
	// --------------------------------------------------
	/**
	 * Returns true if the {@link class_3446} of this {@link CustomStat}
	 * is {@link class_3446#field_16977}.
	 */
	public final boolean isDistance() { return this.statFormatter == class_3446.field_16977; }

	/**
	 * Returns true if the {@link class_3446} of this {@link CustomStat}
	 * is {@link class_3446#field_16979}.
	 */
	public final boolean isTime() { return this.statFormatter == class_3446.field_16979; }

	/**
	 * Returns true if the {@link class_3446} of this {@link CustomStat}
	 * is {@link class_3446#field_16978}.
	 */
	public final boolean isDivideBy10() { return this.statFormatter == class_3446.field_16978; }
	// ==================================================
	/**
	 * Obtains a list of all {@link CustomStat}.
	 * @param statsProvider The {@link IStatsProvider} instance.
	 * @param predicate An optional {@link Predicate} for filtering the stats.
	 * @param comparator An optional {@link Comparator} for sorting the list.
	 * @throws NullPointerException If a {@link NotNull} argument is {@code null}.
	 */
	public static final Collection<CustomStat> getCustomStats(
			@NotNull IStatsProvider statsProvider,
			@Nullable Predicate<CustomStat> predicate,
			@Nullable Comparator<CustomStat> comparator) throws NullPointerException
	{
		//not null requirements
		Objects.requireNonNull(statsProvider);
		//initialize and populate the list
		final var result = new ArrayList<CustomStat>((predicate == null) ? field_41183.method_10204() : 0);
		for(final var statSubject : field_41183) {
			final var stat = new CustomStat(statSubject, statsProvider);
			if(predicate != null && !predicate.test(stat)) continue;
			result.add(stat);
		}
		//sort the list based on display names
		if(comparator != null) result.sort(comparator);
		//return the result
		return result;
	}
	// ==================================================
}
