package com.thecsdev.commonmc.api.stats.util;

import com.thecsdev.commonmc.api.stats.IStatsProvider;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Predicate;
import net.minecraft.class_1299;
import net.minecraft.class_2561;
import net.minecraft.class_3445;
import net.minecraft.class_3468;

import static net.minecraft.class_7923.field_41177;

/**
 * {@link SubjectStats} utility implementation for reading statistics
 * about a given {@link class_1299}.
 */
public final class EntityStats extends SubjectStats<class_1299<?>>
{
	// ==================================================
	/**
	 * @throws NullPointerException  If an argument is {@code null}.
	 * @throws IllegalStateException If the subject is not properly registered in the game's registries.
	 */
	public EntityStats(
			@NotNull class_1299<?> subject,
			@NotNull IStatsProvider statsProvider) throws NullPointerException, IllegalStateException {
		super(field_41177, subject, statsProvider);
	}
	// ==================================================
	public final @Override @NotNull class_2561 getSubjectDisplayName() { return getSubject().method_5897(); }
	public final @Override @NotNull LinkedHashMap<class_3445<class_1299<?>>, Integer> getValues() {
		final var subject = getSubject();
		final var map     = new LinkedHashMap<class_3445<class_1299<?>>, Integer>();
		for(final var st : IStatsProvider.getEntityStatTypes())
			map.put(st.method_14956(subject), getStatsProvider().getIntValue(st, subject));
		return map;
	}
	// ==================================================
	/**
	 * Returns the value of {@link class_3468#field_15403}.
	 */
	public final int getKills() { return getStatsProvider().getIntValue(class_3468.field_15403, getSubject()); }

	/**
	 * Returns the value of {@link class_3468#field_15411}.
	 */
	public final int getDeaths() { return getStatsProvider().getIntValue(class_3468.field_15411, getSubject()); }
	// ==================================================
	/**
	 * Obtains a list of all {@link EntityStats}.
	 * @param statsProvider The {@link IStatsProvider} instance.
	 * @param predicate An optional {@link Predicate} for filtering the stats.
	 * @param comparator An optional {@link Comparator} for sorting the list.
	 * @throws NullPointerException If a {@link NotNull} argument is {@code null}.
	 */
	public static final Collection<EntityStats> getEntityStats(
			@NotNull IStatsProvider statsProvider,
			@Nullable Predicate<EntityStats> predicate,
			@Nullable Comparator<EntityStats> comparator) throws NullPointerException
	{
		//not null requirements
		Objects.requireNonNull(statsProvider);
		//initialize and populate the list
		final var result = new ArrayList<EntityStats>((predicate == null) ? field_41177.method_10204() : 0);
		for(final var statSubject : field_41177) {
			final var stat = new EntityStats(statSubject, statsProvider);
			if(predicate != null && !predicate.test(stat)) continue;
			result.add(stat);
		}
		//sort the list based on display names
		if(comparator != null) result.sort(comparator);
		//return the result
		return result;
	}
	// ==================================================
}
