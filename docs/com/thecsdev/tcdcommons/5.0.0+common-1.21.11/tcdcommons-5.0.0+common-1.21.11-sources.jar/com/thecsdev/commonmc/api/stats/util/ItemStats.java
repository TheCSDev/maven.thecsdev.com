package com.thecsdev.commonmc.api.stats.util;

import com.thecsdev.commonmc.api.stats.IStatsProvider;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Predicate;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_3445;
import net.minecraft.class_3468;
import net.minecraft.class_7923;

import static net.minecraft.class_7923.field_41178;

/**
 * {@link SubjectStats} utility implementation for reading statistics
 * about a given {@link class_1792}.
 */
public final class ItemStats extends SubjectStats<class_1792>
{
	// ==================================================
	private BlockStats blockStats;
	// ==================================================
	/**
	 * @throws NullPointerException  If an argument is {@code null}.
	 * @throws IllegalStateException If the subject is not properly registered in the game's registries.
	 */
	public ItemStats(
			@NotNull class_1792 subject,
			@NotNull IStatsProvider statsProvider) throws NullPointerException, IllegalStateException {
		super(class_7923.field_41178, subject, statsProvider);
	}
	// ==================================================
	public final @Override @NotNull class_2561 getSubjectDisplayName() { return getSubject().method_63680(); }
	public final @Override @NotNull LinkedHashMap<class_3445<class_1792>, Integer> getValues() {
		final var subject = getSubject();
		final var map     = new LinkedHashMap<class_3445<class_1792>, Integer>();
		for(final var st : IStatsProvider.getItemStatTypes())
			map.put(st.method_14956(subject), getStatsProvider().getIntValue(st, subject));
		return map;
	}
	// ==================================================
	/**
	 * Returns the {@link BlockStats} of the {@link #getSubject()}'s
	 * corresponding {@link class_2248}.
	 */
	public final @NotNull BlockStats getBlockStats() {
		if(this.blockStats == null)
			this.blockStats = new BlockStats(class_2248.method_9503(getSubject()), getStatsProvider());
		return this.blockStats;
	}
	// ==================================================
	/**
	 * Returns the value of {@link class_3468#field_15383}.
	 */
	public final int getTimesBroken() { return getStatsProvider().getIntValue(class_3468.field_15383, getSubject()); }

	/**
	 * Returns the value of {@link class_3468#field_15370}.
	 */
	public final int getTimesCrafted() { return getStatsProvider().getIntValue(class_3468.field_15370, getSubject()); }

	/**
	 * Returns the value of {@link class_3468#field_15405}.
	 */
	public final int getTimesDropped() { return getStatsProvider().getIntValue(class_3468.field_15405, getSubject()); }

	/**
	 * Returns the value of {@link class_3468#field_15372}.
	 */
	public final int getTimesUsed() { return getStatsProvider().getIntValue(class_3468.field_15372, getSubject()); }

	/**
	 * Returns the value of {@link class_3468#field_15392}.
	 */
	public final int getTimesPickedUp() { return getStatsProvider().getIntValue(class_3468.field_15392, getSubject()); }
	// ==================================================
	/**
	 * Obtains a list of all {@link ItemStats}.
	 * @param statsProvider The {@link IStatsProvider} instance.
	 * @param predicate An optional {@link Predicate} for filtering the stats.
	 * @param comparator An optional {@link Comparator} for sorting the list.
	 * @throws NullPointerException If a {@link NotNull} argument is {@code null}.
	 */
	public static final Collection<ItemStats> getItemStats(
			@NotNull IStatsProvider statsProvider,
			@Nullable Predicate<ItemStats> predicate,
			@Nullable Comparator<ItemStats> comparator) throws NullPointerException
	{
		//not null requirements
		Objects.requireNonNull(statsProvider);
		//initialize and populate the list
		final var result = new ArrayList<ItemStats>((predicate == null) ? field_41178.method_10204() : 0);
		for(final var statSubject : field_41178) {
			final var stat = new ItemStats(statSubject, statsProvider);
			if(predicate != null && !predicate.test(stat)) continue;
			result.add(stat);
		}
		//sort the list based on display names
		if(comparator != null) result.sort(comparator);
		//return the result
		return result;
	}
	// ==================================================
}
