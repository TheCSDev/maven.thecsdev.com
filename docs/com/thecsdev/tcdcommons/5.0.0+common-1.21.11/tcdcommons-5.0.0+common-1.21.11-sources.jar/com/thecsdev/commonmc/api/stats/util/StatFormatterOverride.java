package com.thecsdev.commonmc.api.stats.util;

import net.minecraft.class_3445;
import net.minecraft.class_3446;
import org.jetbrains.annotations.NotNull;

/**
 * A functional interface for overriding the vanilla {@link class_3446} behavior.
 * @see class_3446
 */
@FunctionalInterface
public interface StatFormatterOverride
{
	// ==================================================
	public static final StatFormatterOverride DEFAULT = class_3446::format;
	// ==================================================
	/**
	 * Formats a {@link class_3445}'s value using a custom formatter.
	 * @param vanillaFormatter The default vanilla formatter to use as a fallback or base.
	 * @param value            The statistic value to format.
	 * @return A formatted string representation of the statistic value.
	 */
	public @NotNull String format(@NotNull class_3446 vanillaFormatter, int value);
	// ==================================================
}
