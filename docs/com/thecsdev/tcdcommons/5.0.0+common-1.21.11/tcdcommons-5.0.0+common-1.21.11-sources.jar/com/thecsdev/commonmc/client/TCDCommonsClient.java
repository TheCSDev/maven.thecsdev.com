package com.thecsdev.commonmc.client;

import com.thecsdev.commonmc.TCDCommons;
import com.thecsdev.commonmc.api.client.registry.TClientRegistries;
import com.thecsdev.commonmc.client.mixin.hooks.AccessorLocalPlayer;
import dev.architectury.event.events.client.ClientPlayerEvent;
import java.util.List;
import net.minecraft.class_1124;
import net.minecraft.class_7706;

/**
 * The main "client" entry-point for this mod, that is executed
 * by all loaders (fabric/neoforge).
 */
public class TCDCommonsClient extends TCDCommons
{
	// ==================================================
	public TCDCommonsClient()
	{
		//register features
		TClientRegistries.bootstrap();

		//regroup items into creative mode tabs when joining worlds
		ClientPlayerEvent.CLIENT_PLAYER_JOIN.register(localPlayer ->
		{
			// ----------
			//do not do this if this feature is disabled
			if(!getConfig().updateItemGroupsOnJoin()) return;
			// ----------
			//noinspection resource | huh? this warning makes 0 sense in this context
			final var level  = localPlayer.method_73183();
			final var client = ((AccessorLocalPlayer)localPlayer).getMinecraft();
			// ----------
			//when the client joins a world, update the item group display context
			//right away, to avoid lag spikes when opening inventory later.
			//this is also here so mods can display properly grouped items right away
			// ----------
			//update display context for items
			class_7706.method_47330(
					level.method_45162(),
					client.field_1690.method_47395().method_41753() && localPlayer.method_7338(),
					level.method_30349());

			//update the "Search" item group
			if(localPlayer.field_3944.method_60347() instanceof class_1124 sm) {
				final var list = List.copyOf(class_7706.method_47344().method_47313());
				sm.method_60357(level.method_30349(), list);
				sm.method_60355(list);
			}
			// ----------
		});
	}
	// ==================================================
}
