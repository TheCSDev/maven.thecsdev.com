package com.thecsdev.commonmc.client.mixin.events;

import com.thecsdev.commonmc.api.client.gui.screen.IStatsListener;
import com.thecsdev.commonmc.api.client.gui.screen.TScreenWrapper;
import net.minecraft.class_2602;
import net.minecraft.class_2617;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2617.class)
public abstract class MixinClientboundAwardStatsPacket
{
	// ==================================================
	@Inject(method = "handle*", at = @At("RETURN"), require = 1, remap = true)
	private void onHandle(class_2602 clientPlayPacketListener, CallbackInfo callbackInfo)
	{
		//execute handlers for this packet, but on the client's thread
		final var client = class_310.method_1551();
		client.execute(() ->
		{
			//invoke callback method for screens
			if(client.field_1755 instanceof IStatsListener isl)
				isl.statsReceivedCallback();
			//or invoke callback method for t-screens
			else if(client.field_1755 instanceof TScreenWrapper<?> tsw &&
					tsw.getTargetTScreen() instanceof IStatsListener isl)
				isl.statsReceivedCallback();
		});
	}
	// ==================================================
}
