package com.thecsdev.commonmc.client.mixin.events;

import com.thecsdev.commonmc.api.client.gui.screen.TScreenWrapper;
import com.thecsdev.commonmc.api.client.registry.TClientRegistries;
import com.thecsdev.commonmc.client.mixin.hooks.AccessorScreen;
import net.minecraft.class_128;
import net.minecraft.class_148;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixins for the game's HUD (heads-up display).
 */
@Mixin(class_329.class)
public abstract class MixinGui
{
	// ==================================================
	private @Final @Shadow class_310 minecraft;
	// ==================================================
	@Inject(method = "render", at = @At("HEAD"), cancellable = true)
	private void onPreRender(class_332 pencil, class_9779 tickCounter, CallbackInfo ci)
	{
		//cancel HUD rendering if a currently opened t-screen does not allow this
		if(this.minecraft.field_1755 instanceof TScreenWrapper<?> tsw && !tsw.isAllowingInGameHud())
			ci.cancel();
	}
	// --------------------------------------------------
	@Inject(method = "render", at = @At("RETURN"))
	private void onPostRender(class_332 pencil, class_9779 tickCounter, CallbackInfo ci)
	{
		//render in-game-hud screens
		if(TClientRegistries.HUD_SCREEN.method_10204() > 0)
		{
			//prepare variables for rendering
			final var currentScreen = minecraft.field_1755;
			final var clientWindow  = minecraft.method_22683();
			final var mouse         = minecraft.field_1729;
			final int windowW       = clientWindow.method_4486();
			final int windowH       = clientWindow.method_4502();
			final int mouseX        = (int) mouse.method_68879(clientWindow);
		    final int mouseY        = (int) mouse.method_68883(clientWindow);

			//iterate hud screens and render them
			for(final var hudScreen : TClientRegistries.HUD_SCREEN)
				try {
					//do not render the current screen
					if(hudScreen == currentScreen) continue;
					//(re/)initialize screens whenever necessary
					if(((AccessorScreen)hudScreen).getMinecraft() != this.minecraft ||
							hudScreen.field_22789 != windowW || hudScreen.field_22790 != windowH) {
						hudScreen.method_25423(windowW, windowH);
					}
					//render the screen onto the in-game-hud
					hudScreen.method_25394(pencil, mouseX, mouseY, tickCounter.method_60637(false));
					//note: ticking screens is not done here, to avoid weird visual bugs
				} catch(Exception exc) {
					//hold modded screens accountable for any exceptions they throw
					final var hudScreenId = TClientRegistries.HUD_SCREEN.method_10221(hudScreen);
					final var report = class_128.method_560(exc, "Rendering HUD Screen ID " + hudScreenId);
					throw new class_148(report);
				}
		}
	}
	// ==================================================
}
