package com.thecsdev.commonmc.client.mixin.hooks;

import net.minecraft.class_4185;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_4185.class)
public interface AccessorButton
{
	@Accessor("onPress") class_4185.class_4241 getOnPress();
	@Mutable @Accessor("onPress") void setOnPress(@NotNull class_4185.class_4241 onPress);
}
