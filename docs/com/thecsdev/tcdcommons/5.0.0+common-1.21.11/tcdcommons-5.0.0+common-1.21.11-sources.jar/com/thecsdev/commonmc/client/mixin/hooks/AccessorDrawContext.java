package com.thecsdev.commonmc.client.mixin.hooks;

import net.minecraft.class_310;
import net.minecraft.class_332;
import org.joml.Matrix3x2fStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_332.class)
public interface AccessorDrawContext
{
	public @Accessor("minecraft") class_310 getClient();
	public @Mutable @Accessor("minecraft") void setClient(class_310 client);
	
	public @Accessor("pose") Matrix3x2fStack getMatrices();
	public @Mutable @Accessor("pose") void setMatrices(Matrix3x2fStack matrices);
}