package com.thecsdev.commonmc.client.mixin.hooks;

import net.minecraft.class_11228;
import net.minecraft.class_757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_757.class)
public interface AccessorGameRenderer
{
	public @Accessor("guiRenderer") class_11228 getGuiRenderer();
}