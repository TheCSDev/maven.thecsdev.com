package com.thecsdev.commonmc.client.mixin.hooks;

import net.minecraft.class_11228;
import net.minecraft.class_4597;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_11228.class)
public interface AccessorGuiRenderer
{
	public @Accessor("bufferSource") class_4597.class_4598 getVertexConsumers();
}