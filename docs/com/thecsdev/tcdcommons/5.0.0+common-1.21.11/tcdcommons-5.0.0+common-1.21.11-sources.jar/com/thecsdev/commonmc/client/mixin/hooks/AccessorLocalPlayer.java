package com.thecsdev.commonmc.client.mixin.hooks;

import net.minecraft.class_310;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_746.class)
public interface AccessorLocalPlayer
{
	@Accessor("minecraft") class_310 getMinecraft();
}
