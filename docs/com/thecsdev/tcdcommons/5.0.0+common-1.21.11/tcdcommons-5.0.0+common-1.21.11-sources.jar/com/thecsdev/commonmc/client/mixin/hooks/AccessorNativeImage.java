package com.thecsdev.commonmc.client.mixin.hooks;

import net.minecraft.class_1011;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1011.class)
public interface AccessorNativeImage
{
	public @Accessor("pixels") long getPointer();
	public @Accessor("width")  int  getWidth();
	public @Accessor("height") int  getHeight();
}