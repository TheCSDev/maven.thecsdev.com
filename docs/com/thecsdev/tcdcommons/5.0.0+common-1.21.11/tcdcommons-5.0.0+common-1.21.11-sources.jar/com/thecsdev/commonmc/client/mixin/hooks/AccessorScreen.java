package com.thecsdev.commonmc.client.mixin.hooks;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_437.class)
public interface AccessorScreen
{
	public @Accessor("minecraft") class_310 getMinecraft();
	public @Mutable @Accessor("title") void setTitle(class_2561 title);
}
