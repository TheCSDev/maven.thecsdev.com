package com.thecsdev.commonmc.mixin.hooks;

import net.minecraft.class_3445;
import net.minecraft.class_3446;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_3445.class)
public interface AccessorStat
{
	public @Accessor("formatter") class_3446 getFormatter();
}
