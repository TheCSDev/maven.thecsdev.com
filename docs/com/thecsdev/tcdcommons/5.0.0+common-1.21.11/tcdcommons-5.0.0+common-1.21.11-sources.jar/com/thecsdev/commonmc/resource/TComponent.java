package com.thecsdev.commonmc.resource;

import org.jetbrains.annotations.NotNull;

import java.util.UUID;
import net.minecraft.class_1060;
import net.minecraft.class_10725;
import net.minecraft.class_11723;
import net.minecraft.class_11724;
import net.minecraft.class_11885;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5250;
import net.minecraft.class_9296;

import static com.thecsdev.commonmc.TCDCommons.MOD_ID;
import static net.minecraft.class_2561.method_43470;
import static net.minecraft.class_2561.method_74062;

/**
 * Utility methods for creating {@link class_2561} instances, primarily for
 * {@link class_2561#method_74062(class_11724)}.
 */
public final class TComponent
{
	// ==================================================
	private TComponent() {}
	// ==================================================
	public static final class_5250 air() { return method_43470("").method_10852(method_74062(new class_11723(class_10725.field_56385, class_2960.method_60655(MOD_ID, "air")))); }
	public static final class_5250 missingNo() { return method_43470("").method_10852(method_74062(new class_11723(class_11723.field_61976, class_1060.field_5285))); }
	// --------------------------------------------------
	public static final class_5250 block(@NotNull String texId) { return method_43470("").method_10852(method_74062(new class_11723(class_10725.field_56382, class_2960.method_60654(texId)))); }
	public static final class_5250 block(@NotNull class_2960 texId) { return method_43470("").method_10852(method_74062(new class_11723(class_10725.field_56382, texId))); }
	// --------------------------------------------------
	public static final class_5250 item(@NotNull String texId) { return method_43470("").method_10852(method_74062(new class_11723(class_10725.field_64477, class_2960.method_60654(texId)))); }
	public static final class_5250 item(@NotNull class_2960 texId) { return method_43470("").method_10852(method_74062(new class_11723(class_10725.field_64477, texId))); }
	// --------------------------------------------------
	public static final class_5250 painting(@NotNull String texId) { return method_43470("").method_10852(method_74062(new class_11723(class_10725.field_56388, class_2960.method_60654(texId)))); }
	public static final class_5250 painting(@NotNull class_2960 texId) { return method_43470("").method_10852(method_74062(new class_11723(class_10725.field_56388, texId))); }
	// --------------------------------------------------
	public static final class_5250 particle(@NotNull String texId) { return method_43470("").method_10852(method_74062(new class_11723(class_10725.field_56389, class_2960.method_60654(texId)))); }
	public static final class_5250 particle(@NotNull class_2960 texId) { return method_43470("").method_10852(method_74062(new class_11723(class_10725.field_56389, texId))); }
	// --------------------------------------------------
	public static final class_5250 gui(@NotNull String texId) { return method_43470("").method_10852(method_74062(new class_11723(class_10725.field_56385, class_2960.method_60654(texId)))); }
	public static final class_5250 gui(@NotNull class_2960 texId) { return method_43470("").method_10852(method_74062(new class_11723(class_10725.field_56385, texId))); }
	// --------------------------------------------------
	public static final class_5250 sign(@NotNull String texId) { return method_43470("").method_10852(method_74062(new class_11723(class_10725.field_56392, class_2960.method_60654(texId)))); }
	public static final class_5250 sign(@NotNull class_2960 texId) { return method_43470("").method_10852(method_74062(new class_11723(class_10725.field_56392, texId))); }
	// --------------------------------------------------
	public static final class_5250 head(@NotNull UUID uuid) { return method_43470("").method_10852(method_74062(new class_11885(class_9296.method_73312(uuid), true))); }
	public static final class_5250 head(@NotNull String username) { return method_43470("").method_10852(method_74062(new class_11885(class_9296.method_74889(username), true))); }
	// ==================================================
}
