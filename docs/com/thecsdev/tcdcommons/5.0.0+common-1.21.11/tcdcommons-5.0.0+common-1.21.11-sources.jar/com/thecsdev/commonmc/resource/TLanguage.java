package com.thecsdev.commonmc.resource;

import com.thecsdev.common.util.annotations.Reflected;
import net.minecraft.class_5250;

import static net.minecraft.class_2561.method_43469;

/**
 * Language texts for {@link com.thecsdev.commonmc.TCDCommons}.
 */
public final class TLanguage
{
	// ==================================================
	private TLanguage() {}
	// ==================================================
	public static final class_5250 mmName_tcdcommons() { return method_43471("modmenu.nameTranslation.tcdcommons"); }
	public static final class_5250 mmSummary_tcdcommons() { return method_43471("modmenu.summaryTranslation.tcdcommons"); }
	// --------------------------------------------------
	public static final @Reflected class_5250 config_propertyValue() { return method_43471("tcdcommons.config.property_value"); }
	public static final @Reflected class_5250 config_common() { return method_43471("tcdcommons.config.common"); }
	public static final @Reflected class_5250 config_client() { return method_43471("tcdcommons.config.client"); }
	public static final @Reflected class_5250 config_client_updateItemGroupsOnJoin() { return method_43471("tcdcommons.config.client.update_item_groups_on_join"); }
	public static final @Reflected class_5250 config_client_updateItemGroupsOnJoin_tooltip() { return method_43471("tcdcommons.config.client.update_item_groups_on_join.tooltip"); }
	public static final @Reflected class_5250 config_server() { return method_43471("tcdcommons.config.server"); }
	// --------------------------------------------------
	public static final            class_5250 gui_screen_textDialog_defaultTitle() { return method_43471("tcdcommons.gui.screen.text_dialog.default_title"); }
	public static final @Reflected class_5250 gui_screen_textDialog_errorTitle() { return method_43471("tcdcommons.gui.screen.text_dialog.error_title"); }
	// --------------------------------------------------
	public static final class_5250 gui_dropdown_defaultLabel() { return method_43471("tcdcommons.gui.dropdown.default_label"); }
	// --------------------------------------------------
	public static final class_5250 gui_fileChooser_mode_explore() { return method_43471("tcdcommons.gui.filechooser.mode.explore"); }
	public static final class_5250 gui_fileChooser_mode_chooseFile() { return method_43471("tcdcommons.gui.filechooser.mode.choose_file"); }
	public static final class_5250 gui_fileChooser_mode_createFile() { return method_43471("tcdcommons.gui.filechooser.mode.create_file"); }
	public static final class_5250 gui_fileChooser_quickAccess() { return method_43471("tcdcommons.gui.filechooser.quick_access"); }
	public static final class_5250 gui_fileChooser_quickAccess_mountPoints() { return method_43471("tcdcommons.gui.filechooser.quick_access.mount_points"); }
	public static final class_5250 gui_fileChooser_ctxmenu_select() { return method_43471("tcdcommons.gui.filechooser.ctxmenu.select"); }
	public static final class_5250 gui_fileChooser_ctxmenu_open() { return method_43471("tcdcommons.gui.filechooser.ctxmenu.open"); }
	public static final class_5250 gui_fileChooser_ctxmenu_openWith() { return method_43471("tcdcommons.gui.filechooser.ctxmenu.open_with"); }
	public static final class_5250 gui_fileChooser_ctxmenu_openWith_assocApp() { return method_43471("tcdcommons.gui.filechooser.ctxmenu.open_with.assoc_app"); }
	public static final class_5250 gui_fileChooser_action_fileName() { return method_43471("tcdcommons.gui.filechooser.action.file_name"); }
	public static final class_5250 gui_fileChooser_action_fileType() { return method_43471("tcdcommons.gui.filechooser.action.file_type"); }
	// --------------------------------------------------
	public static final @Reflected class_5250 misc_loading() { return method_43471("tcdcommons.misc.loading"); }
	public static final @Reflected class_5250 misc_somethingWentWrong() { return method_43471("tcdcommons.misc.something_went_wrong"); }
	public static final @Reflected class_5250 misc_comingSoon() { return method_43471("tcdcommons.misc.coming_soon"); }
	// ==================================================
}
