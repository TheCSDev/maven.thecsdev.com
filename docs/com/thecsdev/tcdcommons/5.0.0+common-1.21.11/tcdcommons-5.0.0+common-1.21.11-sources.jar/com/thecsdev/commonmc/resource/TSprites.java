package com.thecsdev.commonmc.resource;

import com.thecsdev.common.util.annotations.Reflected;
import com.thecsdev.commonmc.TCDCommons;
import com.thecsdev.commonmc.api.client.gui.misc.TTextureElement;
import net.minecraft.class_1058;
import net.minecraft.class_10725;
import net.minecraft.class_2960;

import static com.thecsdev.commonmc.TCDCommons.MOD_ID;
import static net.minecraft.class_2960.method_60655;


/**
 * {@link TCDCommons}'s {@link class_2960}s for {@link class_1058}s.
 * @see class_10725
 * @see class_1058
 * @see TTextureElement.Mode#GUI_SPRITE
 */
public class TSprites
{
	// ==================================================
	private TSprites() {}
	// ==================================================
	public static final class_2960 gui_widget_dropdownCollapsed() { return method_60655(MOD_ID, "widget/dropdown_collapsed"); }
	public static final class_2960 gui_widget_dropdownExpanded() { return method_60655(MOD_ID, "widget/dropdown_expanded"); }
	// --------------------------------------------------
	public static final class_2960 gui_popup_ctxmenu() { return method_60655(MOD_ID, "popup/ctxmenu"); }
	public static final class_2960 gui_popup_ctxmenuHighlighted() { return method_60655(MOD_ID, "popup/ctxmenu_highlighted"); }
	public static final class_2960 gui_popup_shadow() { return method_60655(MOD_ID, "popup/shadow"); }
	// --------------------------------------------------
	public static final class_2960 gui_icon_clipboard() { return method_60655(MOD_ID, "icon/clipboard"); }
	// --------------------------------------------------
	public static final            class_2960 gui_icon_fsFile() { return method_60655(MOD_ID, "icon/fs_file"); }
	public static final            class_2960 gui_icon_fsFileImage() { return method_60655(MOD_ID, "icon/fs_file_image"); }
	public static final            class_2960 gui_icon_fsFileTxt() { return method_60655(MOD_ID, "icon/fs_file_txt"); }
	public static final            class_2960 gui_icon_fsFileJson() { return method_60655(MOD_ID, "icon/fs_file_json"); }
	public static final @Reflected class_2960 gui_icon_fsFolder() { return method_60655(MOD_ID, "icon/fs_folder"); }
	public static final            class_2960 gui_icon_fsFolderGray() { return method_60655(MOD_ID, "icon/fs_folder_gray"); }
	// ==================================================
}
