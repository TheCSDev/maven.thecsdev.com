package com.thecsdev.commonmc.resource;

import com.thecsdev.commonmc.TCDCommons;
import com.thecsdev.commonmc.api.client.gui.misc.TTextureElement;
import net.minecraft.class_2960;

import static com.thecsdev.commonmc.TCDCommons.MOD_ID;
import static net.minecraft.class_2960.method_60655;

/**
 * {@link TCDCommons}'s {@link class_2960}s for textures.
 * @see TTextureElement.Mode#TEXTURE
 */
public final class TTextures
{
	// ==================================================
	private TTextures() {}
	// ==================================================
	public static final class_2960 gui_ctxmenu() { return method_60655(MOD_ID, "textures/gui/sprites/popup/ctxmenu.png"); }
	// ==================================================
}
