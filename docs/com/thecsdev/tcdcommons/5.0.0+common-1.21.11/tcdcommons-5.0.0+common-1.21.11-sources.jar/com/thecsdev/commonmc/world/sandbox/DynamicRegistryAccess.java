package com.thecsdev.commonmc.world.sandbox;

import com.mojang.serialization.Lifecycle;
import net.minecraft.class_10588;
import net.minecraft.class_10686;
import net.minecraft.class_10689;
import net.minecraft.class_10733;
import net.minecraft.class_10758;
import net.minecraft.class_10824;
import net.minecraft.class_12321;
import net.minecraft.class_1937;
import net.minecraft.class_2370;
import net.minecraft.class_2378;
import net.minecraft.class_2385;
import net.minecraft.class_3852;
import net.minecraft.class_3854;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_5504;
import net.minecraft.class_6880;
import net.minecraft.class_7408;
import net.minecraft.class_7509;
import net.minecraft.class_7871;
import net.minecraft.class_7891;
import net.minecraft.class_7924;
import net.minecraft.class_8111;
import net.minecraft.class_9347;
import net.minecraft.core.*;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jspecify.annotations.NonNull;

import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

/**
 * {@link class_5455} implementation that dynamically resolves
 * {@link #method_46759(class_5321)} and {@link #method_40311()}.
 */
@ApiStatus.Internal
public final class DynamicRegistryAccess implements class_5455
{
	// ================================================== ==================================================
	//                              DynamicRegistryAccess IMPLEMENTATION
	// ================================================== ==================================================
	/**
	 * Static {@link DynamicRegistryAccess} instance that was bootstrapped using
	 * {@link #bootstrapLevel()}. Used for creating {@link class_1937} instances.
	 */
	public static final DynamicRegistryAccess LEVEL = new DynamicRegistryAccess().bootstrapLevel();
	// ==================================================
	private final class_2385<class_2385<?>> registries = new class_2370<>(class_5321.method_29180(class_7924.field_47497), Lifecycle.stable());
	// ==================================================
	public DynamicRegistryAccess() {
		//the root needs to be registered to itself
		class_2378.method_10230(this.registries, class_7924.field_47497, this.registries);
	}
	// ==================================================
	@SuppressWarnings("unchecked")
	public final @NotNull <E> Optional<class_2385<E>> lookupM(@NotNull class_5321<? extends class_2378<? extends E>> resourceKey) {
		if(!this.registries.method_10250(resourceKey.method_29177()))
			class_2378.method_10230(this.registries, resourceKey.method_29177(), new class_2370<>((class_5321<? extends class_2378<E>>) resourceKey, Lifecycle.stable()));
		return Optional.of((class_2385<E>) this.registries.method_63535(resourceKey.method_29177()));
	}

	@SuppressWarnings("unchecked")
	public final @Override @NotNull <E> Optional<class_2378<E>> method_46759(@NonNull class_5321<? extends class_2378<? extends E>> resourceKey) {
		return (Optional<class_2378<E>>) (Object) lookupM(resourceKey);
	}

	public final @Override @NotNull Stream<class_6892<?>> method_40311() {
		return Stream.empty(); //TODO - Implement
	}
	// ==================================================
	/**
	 * Bootstraps registries necessary for a <b>vanilla</b> {@link class_1937} instance.
	 */
	public DynamicRegistryAccess bootstrapLevel()
	{
		class_8111           .method_48839(new GenericBootstrapContext<>(lookupM(class_7924.field_42534).orElseThrow()));
		class_7509          .method_44207(lookupM(class_7924.field_41253).orElseThrow());
		class_5504             .method_40363(new GenericBootstrapContext<>(lookupM(class_7924.field_41236).orElseThrow()));
		class_10686           .method_67131(new GenericBootstrapContext<>(lookupM(class_7924.field_41259).orElseThrow()));
		class_10588           .method_66318(new GenericBootstrapContext<>(lookupM(class_7924.field_55883).orElseThrow()));
		class_10758       .method_67528(new GenericBootstrapContext<>(lookupM(class_7924.field_56596).orElseThrow()));
		class_10733           .method_67355(new GenericBootstrapContext<>(lookupM(class_7924.field_56510).orElseThrow()));
		class_10689          .method_67145(new GenericBootstrapContext<>(lookupM(class_7924.field_41272).orElseThrow()));
		class_7408      .method_43406(new GenericBootstrapContext<>(lookupM(class_7924.field_41209).orElseThrow()));
		class_9347          .method_58068(new GenericBootstrapContext<>(lookupM(class_7924.field_49772).orElseThrow()));
		class_10824     .method_68137(new GenericBootstrapContext<>(lookupM(class_7924.field_57110).orElseThrow()));
		class_3854          .method_66694(lookupM(class_7924.field_41235).orElseThrow());
		class_3852    .method_66692(lookupM(class_7924.field_41234).orElseThrow());
		class_12321.method_76449(new GenericBootstrapContext<>(lookupM(class_7924.field_64475).orElseThrow()));
		return this;
	}
	// ================================================== ==================================================
	//                            GenericBootstrapContext IMPLEMENTATION
	// ================================================== ==================================================
	/**
	 * Generic {@link class_7891} implementation that works with any {@link class_2370}.
	 */
	@ApiStatus.Internal
	public static final class GenericBootstrapContext<T> implements class_7891<T>
	{
		// ==================================================
		private final @NotNull class_2385<T> registry;
		// ==================================================
		public GenericBootstrapContext(@NotNull class_2385<T> registry) {
			this.registry = Objects.requireNonNull(registry);
		}
		// ==================================================
		@SuppressWarnings("unchecked")
		public @Override @NotNull <S> class_7871<S> method_46799(@NonNull class_5321<? extends class_2378<? extends S>> resourceKey) {
			return (class_7871<S>) this.registry.method_46769();
		}
		// --------------------------------------------------
		public @Override @NotNull class_6880.class_6883<T> method_46800(@NonNull class_5321<T> key, T value, @NonNull Lifecycle lifecycle) {
			class_2378.method_39197(this.registry, key, value);
			return class_6880.class_6883.method_40234(this.registry, key);
		}
		// ==================================================
	}
	// ================================================== ==================================================
}
