package com.thecsdev.commonmc.world.sandbox;

import com.thecsdev.common.util.annotations.Virtual;
import net.minecraft.class_10286;
import net.minecraft.class_11749;
import net.minecraft.class_12199;
import net.minecraft.class_12205;
import net.minecraft.class_1282;
import net.minecraft.class_1297;
import net.minecraft.class_1508;
import net.minecraft.class_1657;
import net.minecraft.class_1845;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_1972;
import net.minecraft.class_22;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_269;
import net.minecraft.class_2784;
import net.minecraft.class_2802;
import net.minecraft.class_2874;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import net.minecraft.class_3481;
import net.minecraft.class_3611;
import net.minecraft.class_5217;
import net.minecraft.class_5269;
import net.minecraft.class_5321;
import net.minecraft.class_5362;
import net.minecraft.class_5455;
import net.minecraft.class_5576;
import net.minecraft.class_5577;
import net.minecraft.class_5582;
import net.minecraft.class_5712;
import net.minecraft.class_6012;
import net.minecraft.class_6019;
import net.minecraft.class_6754;
import net.minecraft.class_6756;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_7699;
import net.minecraft.class_7701;
import net.minecraft.class_7924;
import net.minecraft.class_8921;
import net.minecraft.class_9209;
import net.minecraft.class_9895;
import net.minecraft.core.*;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Barebones minimal {@link class_1937} implementation.
 */
@ApiStatus.Internal
@SuppressWarnings("NullableProblems")
public @Virtual class SandboxLevel extends class_1937
{
	// ==================================================
	private static final class_7699             FEATURES       = class_7699.method_45398(class_7701.field_40177);
	private static final class_12205 ENV_ATTR_SYS   = class_12205.method_76394().method_76410();
	private static final class_2874              DIMENSION_TYPE = new class_2874(
			true, true, false, 1D, 0, 32, 32, class_3481.field_25588, 1f,
			new class_2874.class_7512(class_6019.method_35017(0, 7), 0),
			class_2874.class_12326.field_64386, class_2874.class_12325.field_64380,
			class_12199.field_63724, class_6885.method_58563()
	);
	// --------------------------------------------------
	protected @NotNull class_5582<class_1297> entityManager   = new class_5582<>(class_1297.class, new class_5576<>() {
		public void onCreated(class_1297 object) {}
		public void onDestroyed(class_1297 object) {}
		public void onTickingStart(class_1297 object) {}
		public void onTickingEnd(class_1297 object) {}
		public void onTrackingStart(class_1297 object) {}
		public void onTrackingEnd(class_1297 object) {}
		public void onSectionChange(class_1297 object) {}
	});
	protected @NotNull List<class_1508>                 dragonParts     = new ArrayList<>();
	protected @NotNull class_8921                       tickRateManager = new class_8921();
	protected @NotNull class_269                            scoreboard      = new class_269();
	protected @NotNull class_10286                          recipeAccess    = new SandboxLevelRecipes();
	protected @NotNull class_1845                         potionBrewing   = new class_1845.class_9665(FEATURES).method_59701();
	protected @NotNull class_9895                            fuelValues      = new class_9895.class_9896(method_30349(), FEATURES).method_61756();
	protected @NotNull class_2802                           chunkSource     = new SandboxLevelChunks(this);
	protected @NotNull List<class_1657>                          players         = new ArrayList<>();
	protected @NotNull class_2784                           worldBorder     = new class_2784();
	// ==================================================
	/**
	 * Primary {@link SandboxLevel} instance that is used {@link ApiStatus.Internal}ly.
	 */
	public static final SandboxLevel INSTANCE = new SandboxLevel();
	// ==================================================
	public SandboxLevel() {
		this(new SandboxLevelData(), class_1937.field_25179, DynamicRegistryAccess.LEVEL, new class_6880.class_6881<>(DIMENSION_TYPE), true, true, 0, 1);
	}
	public SandboxLevel(class_5269 properties, class_5321<class_1937> registryRef, class_5455 registryManager, class_6880<class_2874> dimensionEntry, boolean isClient, boolean debugWorld, long seed, int maxChainedNeighborUpdates) {
		super(properties, registryRef, registryManager, dimensionEntry, isClient, debugWorld, seed, maxChainedNeighborUpdates);
	}
	// ==================================================
	public @Virtual @Override void method_8413(class_2338 position, class_2680 oldState, class_2680 newState, int flags) {}
	public @Virtual @Override void method_8465(@Nullable class_1297 source, double x, double y, double z, class_6880<class_3414> sound, class_3419 category, float volume, float pitch, long speed) {}
	public @Virtual @Override void method_8449(@Nullable class_1297 source, class_1297 entity, class_6880<class_3414> sound, class_3419 category, float volume, float pitch, long speed) {}
	public @Virtual @Override void method_8454(@Nullable class_1297 entity, @Nullable class_1282 damageSource, @Nullable class_5362 behavior, double x, double y, double z, float power, boolean createFire, class_7867 explosionSourceType, class_2394 smallParticle, class_2394 largeParticle, class_6012<class_11749> blockParticles, class_6880<class_3414> soundEvent) {}
	public @Virtual @Override String method_31419() {
        return "Chunks[C] W: " + method_8398().method_12122() + " E: " + this.entityManager.method_31879();
	}
	public @Virtual @Override void method_27873(class_5217.class_12064 spawnPoint) {}
	public @Virtual @Override class_5217.class_12064 method_74854() { return method_8401().method_74893(); }
	public @Virtual @Override @Nullable class_1297 method_8469(int entityId) { return method_31592().method_31804(entityId); }
	public @Virtual @Override Collection<class_1508> method_65097() { return this.dragonParts; }
	public @Virtual @Override class_8921 method_54719() { return this.tickRateManager; }
	public @Virtual @Override @Nullable class_22 method_17891(class_9209 mapId) { return null; }
	public @Virtual @Override void method_8517(int entityId, class_2338 position, int progress) {}
	public @Virtual @Override class_269 method_8428() { return this.scoreboard; }
	public @Virtual @Override class_10286 method_8433() { return this.recipeAccess; }
	protected @Virtual @Override class_5577<class_1297> method_31592() { return this.entityManager.method_31866(); }
	public @Virtual @Override class_12205 method_75598() { return ENV_ATTR_SYS; }
	public @Virtual @Override class_1845 method_59547() { return this.potionBrewing; }
	public @Virtual @Override class_9895 method_61269() { return this.fuelValues; }
	public @Virtual @Override class_2802 method_8398() { return this.chunkSource; }
	public @Virtual @Override void method_8444(@Nullable class_1297 source, int eventId, class_2338 position, int data) {}
	public @Virtual @Override void method_32888(class_6880<class_5712> event, class_243 emitterPosition, class_5712.class_7397 emitter) {}
	public @Virtual @Override List<? extends class_1657> method_18456() { return this.players; }
	public @Virtual @Override class_6880<class_1959> method_22387(int biomeX, int biomeY, int biomeZ) { return method_30349().method_30530(class_7924.field_41236).method_46747(class_1972.field_9451); }
	public @Virtual @Override int method_8615() { return 0; }
	public @Virtual @Override class_7699 method_45162() { return FEATURES; }
	public @Virtual @Override float method_24852(class_2350 direction, boolean shaded) { return 0; }
	public @Virtual @Override class_2784 method_8621() { return this.worldBorder; }
	public @Virtual @Override class_6756<class_2248> method_8397() { return class_6754.method_39362(); }
	public @Virtual @Override class_6756<class_3611> method_8405() { return class_6754.method_39362(); }
	// ==================================================
}
