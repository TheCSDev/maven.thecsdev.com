package com.thecsdev.commonmc.world.sandbox;

import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.function.BooleanSupplier;
import net.minecraft.class_1922;
import net.minecraft.class_1923;
import net.minecraft.class_1972;
import net.minecraft.class_2791;
import net.minecraft.class_2802;
import net.minecraft.class_2806;
import net.minecraft.class_2812;
import net.minecraft.class_3568;
import net.minecraft.class_7924;

/**
 * Barebones {@link class_2802} implementation for {@link SandboxLevel}.
 */
@ApiStatus.Internal
final class SandboxLevelChunks extends class_2802
{
	// ==================================================
	private final @NotNull SandboxLevel level;
	private final @NotNull class_3568 lightEngine;
	// --------------------------------------------------
	private final class_2791 chunk_0_0;
	// ==================================================
	public SandboxLevelChunks(@NotNull SandboxLevel level) {
		this.level       = Objects.requireNonNull(level);
		this.lightEngine = new class_3568(this, true, level.method_8597().comp_642());
		this.chunk_0_0   = new class_2812(
				level, class_1923.field_35107, level.method_30349()
						.method_66874(class_7924.field_41236).comp_349()
						.method_46747(class_1972.field_9451));
	}
	// ==================================================
	public final @Override @Nullable class_2791 method_12121(int i, int j, class_2806 chunkStatus, boolean bl) { return this.chunk_0_0; }
	public final @Override void method_12127(BooleanSupplier booleanSupplier, boolean bl) {}
	public final @Override @NotNull String method_12122() { return "0, 0"; }
	public final @Override int method_14151() { return 0; }
	public final @Override @NotNull class_3568 method_12130() { return this.lightEngine; }
	public final @Override @NotNull class_1922 method_16399() { return this.level; }
	// ==================================================
}
