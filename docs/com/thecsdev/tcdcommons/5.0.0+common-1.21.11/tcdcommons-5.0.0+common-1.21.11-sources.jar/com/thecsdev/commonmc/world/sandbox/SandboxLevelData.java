package com.thecsdev.commonmc.world.sandbox;

import net.minecraft.class_1267;
import net.minecraft.class_5269;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

/**
 * {@link class_5269} implementation for the {@link SandboxLevel}.
 */
@ApiStatus.Internal
final class SandboxLevelData implements class_5269
{
	// ==================================================
	private @NotNull class_12064 spawnPoint = class_12064.field_63048;
	private          boolean     isRaining  = false;
	// ==================================================
	public final @Override @NotNull class_12064 method_74893() { return this.spawnPoint; }
	public final @Override void method_187(class_12064 respawnData) {
		this.spawnPoint = (respawnData != null) ? respawnData : class_12064.field_63048;
	}
	public final @Override long method_188() { return 0; }
	public final @Override long method_217() { return 0; }
	public final @Override boolean method_203() { return false; }
	public final @Override boolean method_156() { return this.isRaining; }
	public final @Override void method_157(boolean raining) { this.isRaining = raining; }
	public final @Override boolean method_152() { return false; }
	public final @Override @NotNull class_1267 method_207() { return class_1267.field_5807; }
	public final @Override boolean method_197() { return true; }
	// ==================================================
}
