package com.thecsdev.commonmc.world.sandbox;

import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import net.minecraft.class_10286;
import net.minecraft.class_10290;
import net.minecraft.class_10291;
import net.minecraft.class_3975;
import net.minecraft.class_5321;

/**
 * Barebones {@link class_10286} implementation for a {@link SandboxLevel}.
 */
@ApiStatus.Internal
final class SandboxLevelRecipes implements class_10286
{
	// ==================================================
    public final Map<class_5321<class_10290>, class_10290> itemSets           = new HashMap<>();
    public final class_10291.class_10293<class_3975>     stonecutterRecipes = new class_10291.class_10293<>(new LinkedList<>());
	// ==================================================
    public @NotNull class_10290 method_64678(class_5321<class_10290> resourceKey) {
        return (class_10290)this.itemSets.getOrDefault(resourceKey, class_10290.field_54655);
    }
    public class_10291.@NotNull class_10293<class_3975> method_64677() {
        return this.stonecutterRecipes;
    }
	// ==================================================
}
