package com.thecsdev.commonmc.api.client.events;

import com.thecsdev.common.event.Event;
import com.thecsdev.common.event.Events;
import com.thecsdev.commonmc.client.mixin.hooks.AccessorScreen;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_2678;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_5321;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_761;
import org.jetbrains.annotations.NotNull;

/**
 * {@link Event}s related to the {@link class_310} client and {@link class_746}.
 */
@Environment(EnvType.CLIENT)
public interface ClientEvent
{
	// ==================================================
	/**
	 * <b>Trigger:</b> Whenever a {@link class_746} joins a level.<br>
	 * <b>Thread:</b> Main (client) &lt;- Scheduled from network thread
	 * @see class_634#method_11120(class_2678)
	 */
	Event<LocalPlayerJoin> PLAYER_JOIN = Events.createLoop();

	/**
	 * <b>Trigger:</b> Whenever a {@link class_746} leaves a level.<br>
	 * <b>Thread:</b> Main (client)
	 * @see class_310#method_52703(class_437)
	 */
	Event<LocalPlayerQuit> PLAYER_QUIT = Events.createLoop();
	// --------------------------------------------------
	/**
	 * <b>Trigger:</b> Whenever a {@link class_638} is initialized.<br>
	 * <b>Thread:</b> Main (client)
	 * @see class_638#class_638(class_634, class_638.class_5271, class_5321, class_6880, int, int, class_761, boolean, long, int)
	 */
	Event<LevelInit> LEVEL_INIT = Events.createLoop();
	// --------------------------------------------------
	/**
	 * <b>Trigger:</b> Whenever a {@link class_437} is initialized.<br>
	 * <b>Thread:</b> Render (client)
	 * @see class_437#method_25423(int, int)
	 */
	Event<ScreenInit> SCREEN_INIT = Events.createLoop();
	// ==================================================
	/**
	 * {@link Event} handler type for {@link #PLAYER_JOIN}.
	 */
	interface LocalPlayerJoin { void invoke(@NotNull class_746 localPlayer); }

	/**
	 * {@link Event} handler type for {@link #PLAYER_QUIT}.
	 */
	interface LocalPlayerQuit { void invoke(@NotNull class_746 localPlayer); }
	// --------------------------------------------------
	/**
	 * {@link Event} handler type for {@link #LEVEL_INIT}.
	 */
	interface LevelInit { void invoke(@NotNull class_638 clientLevel); }
	// --------------------------------------------------
	/**
	 * {@link Event} handler type for {@link #SCREEN_INIT}.
	 */
	interface ScreenInit { void invoke(@NotNull class_437 screen, @NotNull AccessorScreen accessor); }
	// ==================================================
}
