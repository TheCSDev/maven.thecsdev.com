package com.thecsdev.commonmc.api.client.gui.misc;

import com.thecsdev.common.properties.BooleanProperty;
import com.thecsdev.common.properties.DoubleProperty;
import com.thecsdev.common.properties.NotNullProperty;
import com.thecsdev.common.util.annotations.Virtual;
import com.thecsdev.commonmc.TCDCommonsConfig;
import com.thecsdev.commonmc.api.client.events.ClientEvent;
import com.thecsdev.commonmc.api.client.gui.TElement;
import com.thecsdev.commonmc.api.client.gui.render.TGuiGraphics;
import com.thecsdev.commonmc.world.sandbox.SandboxLevel;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.thecsdev.commonmc.TCDCommons.LOGGER;
import static net.minecraft.class_3730.field_16471;

/**
 * {@link TElement} that renders an entity on the screen.
 */
@Environment(EnvType.CLIENT)
public @Virtual class TEntityElement extends TElement
{
	// ================================================== ==================================================
	//                                     TEntityElement IMPLEMENTATION
	// ================================================== ==================================================
	private final NotNullProperty<class_1299<?>> entityType    = new NotNullProperty<>(class_1299.field_33456);
	private final BooleanProperty                followsCursor = new BooleanProperty(true);
	private final DoubleProperty                 entityScale   = new DoubleProperty(1d);
	// --------------------------------------------------
	private @Nullable class_1297 displayEntity; //used for rendering. 'null' = 'something went wrong'.
	private @Nullable Throwable displayError; //used for debugging
	// ==================================================
	public TEntityElement(@NotNull class_1299<?> entityType) {
		this();
		this.entityType.set(entityType, TEntityElement.class);
	}
	public TEntityElement() {
		//this element should not be focusable or hoverable
		focusableProperty().set(false, TEntityElement.class);
		hoverableProperty().set(false, TEntityElement.class);
		//automatic display data refreshing when relevant properties update
		boundsProperty().addChangeListener((p, o, n) -> { if(!o.hasSameSize(n)) refresh(); });
		this.entityType.addChangeListener((p, o, n) -> refresh());
		//the initial display data refresh
		refresh();
	}
	// --------------------------------------------------
	/**
	 * Refreshes the {@link #displayEntity} value. Called automatically
	 * whenever {@link #entityTypeProperty()} value changes.
	 */
	private final @ApiStatus.Internal void refresh()
	{
		try {
			this.displayError  = null;
			this.displayEntity = EntityProvider.getOrCreate(this.entityType.get());
		} catch(Exception e) {
			this.displayError  = e;
			this.displayEntity = null;
			if(TCDCommonsConfig.FLAG_DEV_ENV)
				LOGGER.error("Failed to create GUI entity instance for {}", this.entityType.get(), e);
		}
	}
	// ==================================================
	/**
	 * Returns the {@link NotNullProperty} holding the {@link class_1299}
	 * that is to be rendered by this {@link TEntityElement}.
	 */
	public final NotNullProperty<class_1299<?>> entityTypeProperty() { return this.entityType; }

	/**
	 * Returns the {@link BooleanProperty} that determines whether
	 * this the rendered {@link class_1297}'s on-screen rotation follows
	 * the cursor location.
	 */
	public final BooleanProperty followsCursorProperty() { return this.followsCursor; }

	/**
	 * Returns the {@link DoubleProperty} that determines the scale
	 * at which the rendered {@link class_1297} is drawn.
	 */
	public final DoubleProperty entityScaleProperty() { return this.entityScale; }
	// ==================================================
	/**
	 * Returns the {@link Throwable} that was thrown during the last attempt
	 * to create and/or render the display {@link class_1297}, if any.
	 * <p>
	 * This is usually used for debugging purposes, as some modded entities
	 * do not support being rendered on-screen, and will throw when attempts
	 * are made to create and/or render them. In such cases, this method can
	 * be used to retrieve the exception that was thrown.
	 */
	public final @Nullable Throwable getDisplayError() { return this.displayError; }
	// --------------------------------------------------
	/**
	 * Cached {@link class_1297} instance used by this {@link TEntityElement} for
	 * rendering said {@link class_1297} on the GUI screen.
	 * <p>
	 * This value is assigned automatically. You should avoid trying to set
	 * this value, instead only read it in case you are overriding
	 * {@link #renderCallback(TGuiGraphics)}.
	 * <p>
	 * In addition, this value is {@code null} whenever something goes wrong
	 * when attempting to create and/or render the {@link class_1297} instance.
	 * This is usually due to {@link Exception}s being raised during attempts
	 * to render the display {@link class_1297}.
	 *
	 * @see #renderCallback(TGuiGraphics)
	 * @see EntityProvider
	 */
	public final @Nullable class_1297 getDisplayEntity() { return this.displayEntity; }
	// ==================================================
	public @Virtual @Override void renderCallback(@NotNull TGuiGraphics pencil)
	{
		final var bb = this.getBounds();
		if(this.displayEntity != null)
		{
			pencil.pushScissors(bb.x, bb.y, bb.width, bb.height);
			try {
				//attempt to render the entity (some modded ones can and do throw)
				pencil.renderEntity(
						this.displayEntity, bb.x, bb.y, bb.width, bb.height,
						this.entityScale.getD(), this.followsCursor.getZ());
			} catch(Exception e) {
				//kill the rendering if something goes wrong, as some modded entities
				//do not support being drawn on-screen. that is unfortunate
				if(TCDCommonsConfig.FLAG_DEV_ENV)
					LOGGER.error("Failed to render GUI Entity {}", this.displayEntity, e);
				this.displayError  = e;
				this.displayEntity = null;
			}
			pencil.popScissors();
		} else {
			pencil.drawMissingNo(bb.x, bb.y, bb.width, bb.height, -1);
		}
	}
	// ================================================== ==================================================
	//                                     EntityProvider IMPLEMENTATION
	// ================================================== ==================================================
	/**
	 * Utility class for providing {@link class_1297} instances for rendering in GUIs.
	 * These entities do not exist in a "real" {@link class_1937}. Instead, this uses a
	 * sandbox {@link class_1937} to create entities in.
	 */
	public static final @ApiStatus.Internal class EntityProvider
	{
		// ==================================================
		private static final Map<class_1299<?>, Object> CACHE = new HashMap<>();
		// ==================================================
		private EntityProvider() {}
		static {
			//clear cache when world-related events happen
			ClientEvent.PLAYER_JOIN.addListener(__ -> CACHE.clear());
			ClientEvent.PLAYER_QUIT.addListener(__ -> CACHE.clear());
			ClientEvent.LEVEL_INIT.addListener(__ -> CACHE.clear());
		}
		// ==================================================
		/**
		 * Returns an instance of the given {@link class_1299}.
		 * @param entityType The {@link class_1299} to create an instance of.
		 * @param <E> The type of the {@link class_1297}.
		 * @return An instance of the given {@link class_1299}.
		 * @throws NullPointerException If the argument is {@code null}.
		 * @throws RuntimeException If an error occurs during {@link class_1297} instance creation.
		 */
		@SuppressWarnings("unchecked")
		public static final @NotNull <E extends class_1297> E getOrCreate(@NotNull class_1299<E> entityType)
				throws NullPointerException, RuntimeException
		{
			//not null enforcement
			Objects.requireNonNull(entityType);

			//if a value is cached, use that (depending on what it is)
			final @Nullable var cached = CACHE.get(entityType);
			if(cached instanceof class_1297)
				return (E) cached;
			else if(cached instanceof RuntimeException error)
				throw error; //yes, reusing exceptions because creating them is **VERY** expensive

			//create the entity if not done so before
			final var client = class_310.method_1551();

			if(entityType == class_1299.field_6097) try {
				final var player = Objects.requireNonNull(client.field_1724, "Missing 'Minecraft#player' instance");
				CACHE.put(entityType, player);
				return (E) player;
			} catch (Exception e) {
				final var error = new RuntimeException("Cannot render 'EntityType.PLAYER' without the 'Minecraft#player' instance", e);
				CACHE.put(entityType, error);
				throw error;
			}

			try {
				class_1937 level = client.field_1687;
				if(level == null) level = SandboxLevel.INSTANCE;

				final var entity = entityType.method_5883(level, field_16471);
				CACHE.put(entityType, Objects.requireNonNull(entity, "'EntityType#create(...)' returned 'null' for " + entityType));
				return entity;
			} catch (Exception e) {
				final var error = new RuntimeException("Failed to create 'Entity' instance of type " + entityType, e);
				CACHE.put(entityType, error);
				throw error;
			}
		}
		// ==================================================
	}
	// ================================================== ==================================================
}
