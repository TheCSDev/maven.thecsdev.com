package com.thecsdev.commonmc.api.events;

import com.mojang.brigadier.CommandDispatcher;
import com.thecsdev.common.event.Event;
import com.thecsdev.common.event.Events;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_7157;
import org.jetbrains.annotations.NotNull;

/**
 * {@link Event}s related to commands.
 */
public interface CommandEvent
{
	// ==================================================
	/**
	 * <b>Trigger:</b> Initialization of {@link class_2170}.<br>
	 * <b>Thread:</b> Unknown | Main (server) (likely)
	 * @see class_2170#class_2170(class_2170.class_5364, class_7157)
	 */
	Event<InitCommands> INIT_COMMANDS = Events.createLoop();
	// ==================================================
	/**
	 * {@link Event} handler type for {@link #INIT_COMMANDS}.
	 */
	interface InitCommands {
		void invoke(@NotNull CommandDispatcher<class_2168> dispatcher,
					@NotNull class_7157 buildContext,
		            @NotNull class_2170.class_5364 commandSelection);
	}
	// ==================================================
}
