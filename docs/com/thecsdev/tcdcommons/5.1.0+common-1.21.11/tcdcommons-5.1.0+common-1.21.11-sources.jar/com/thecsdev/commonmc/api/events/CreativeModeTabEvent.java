package com.thecsdev.commonmc.api.events;

import com.thecsdev.common.event.Event;
import com.thecsdev.common.event.Events;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_7225;
import net.minecraft.class_7699;
import net.minecraft.class_7706;
import org.jetbrains.annotations.NotNull;

/**
 * {@link Event}s related to {@link class_1761} / {@link class_7706}.
 */
public interface CreativeModeTabEvent
{
	// ==================================================
	/**
	 * <b>Trigger:</b> Whenever {@link class_1792}s are reorganized into {@link class_1761}s.<br>
	 * <b>Thread:</b> Main (client) | Unknown if there are more
	 * @see class_7706#method_47330(class_7699, boolean, class_7225.class_7874)
	 * @see RebuildContents#invoke(class_7699, boolean, class_7225.class_7874)
	 */
	Event<RebuildContents> REBUILD_CONTENTS = Events.createLoop();
	// ==================================================
	/**
	 * {@link Event} handler type for {@link #REBUILD_CONTENTS}.
	 */
	interface RebuildContents {
		/**
		 * See {@link CreativeModeTabEvent#REBUILD_CONTENTS}.
		 * @param enabledFeatures The <a href="https://www.minecraft.net/en-us/article/testing-new-minecraft-features/feature-toggles-java-edition">currently enabled feature flags</a>.
		 * @param operatorEnabled Whether the "Operator items" {@link class_1761} is enabled.
		 * @param lookup <i>Dev note: I have no idea what this is. May be useful though.</i>
		 */
		void invoke(@NotNull class_7699 enabledFeatures,
		            boolean operatorEnabled,
		            @NotNull class_7225.class_7874 lookup);
	}
	// ==================================================
}
