package com.thecsdev.commonmc.api.world.item;

import com.thecsdev.commonmc.api.events.CreativeModeTabEvent;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Objects;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_7706;

/**
 * Utility methods related to {@link class_1792}s.
 */
public final class TItemUtils
{
	// ==================================================
	private static final HashMap<class_1792, class_1761> I2T = new HashMap<>();
	// ==================================================
	private TItemUtils() {}
	// ==================================================
	/**
	 * {@link ApiStatus.Internal} method that keeps track of {@link class_1792}s and their
	 * corresponding {@link class_1761}s.
	 * <p>
	 * Automatically called by {@link CreativeModeTabEvent#REBUILD_CONTENTS}.
	 * <p>
	 * <b>Do not call this yourself!
	 */
	public static final @ApiStatus.Internal void rebuildI2TMap()
	{
		//start off by clearing the map
		I2T.clear();
		//then iterate all tabs and remap the items
		final var searchTab = class_7706.method_47344();
		final var air       = class_1802.field_8162;
		for(final var tab : class_7706.method_47341())
		{
			//ignore the search group, as it is used for the
			//creative menu item search tab
			if(tab == searchTab) continue;

			//add group's items to the map
			tab.method_47313().forEach(stack ->
			{
				//obtain the stack's item, and ensure an item is present
				//(in Minecraft's "language", AIR usually refers to "null")
				final var item = Objects.requireNonNull(stack.method_7909());
				if(item == air) return;

				//put the item and its group to the map
				I2T.put(item, tab);
			});
		}
	}
	// ==================================================
	/**
	 * Returns the {@link class_1761} a given {@link class_1792} likely belongs to.
	 * @param item The target {@link class_1792}.
	 */
	public static final @Nullable class_1761 getCreativeModeTab(@NotNull class_1792 item) { return I2T.get(item); }
	// ==================================================
}
