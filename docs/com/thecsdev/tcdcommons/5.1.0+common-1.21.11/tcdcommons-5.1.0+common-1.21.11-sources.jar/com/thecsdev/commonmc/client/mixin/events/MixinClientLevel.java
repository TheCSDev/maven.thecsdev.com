package com.thecsdev.commonmc.client.mixin.events;

import com.thecsdev.commonmc.api.client.events.ClientEvent;
import net.minecraft.class_310;
import net.minecraft.class_5321;
import net.minecraft.class_634;
import net.minecraft.class_638;
import net.minecraft.class_6880;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_638.class)
public abstract class MixinClientLevel
{
	// ==================================================
	@SuppressWarnings("rawtypes")
	@Inject(method = "<init>", at = @At("RETURN"))
	private void onInit(
			class_634 clientPacketListener,
			class_638.class_5271 clientLevelData,
			class_5321 resourceKey,
			class_6880 holder,
			int i, int j,
			class_761 levelRenderer,
			boolean bl, long l, int k,
			CallbackInfo ci)
	{
		class_310.method_1551().execute(() ->
				ClientEvent.LEVEL_INIT.invoker().invoke((class_638)(Object)this));
	}
	// ==================================================
}
