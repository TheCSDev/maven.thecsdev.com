package com.thecsdev.commonmc.client.mixin.events;

import com.thecsdev.commonmc.api.client.events.ClientEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;
import net.minecraft.class_2535;
import net.minecraft.class_2678;
import net.minecraft.class_310;
import net.minecraft.class_634;
import net.minecraft.class_8673;
import net.minecraft.class_8675;

@Mixin(class_634.class)
public abstract class MixinClientPacketListener extends class_8673
{
	// ==================================================
	protected MixinClientPacketListener(class_310 minecraft, class_2535 connection, class_8675 commonListenerCookie) {
		super(minecraft, connection, commonListenerCookie);
	}
	// ==================================================
	@Inject(method = "handleLogin", at = @At(value = "INVOKE", shift = At.Shift.AFTER, target = "Lnet/minecraft/client/Options;setServerRenderDistance(I)V"))
	private void onHandleLogin(class_2678 packet, CallbackInfo ci) {
		final var lp = Objects.requireNonNull(field_45588.field_1724, "Missing 'LocalPlayer' instance");
		field_45588.execute(() -> ClientEvent.PLAYER_JOIN.invoker().invoke(lp));
	}
	// ==================================================
}
