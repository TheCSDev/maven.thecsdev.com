package com.thecsdev.commonmc.client.mixin.events;

import com.thecsdev.commonmc.api.client.events.ClientEvent;
import org.jspecify.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Objects;
import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_746;

@Mixin(class_310.class)
public abstract class MixinMinecraft
{
	// ==================================================
	public @Shadow @Nullable class_746 player;
	// ==================================================
	@Inject(method = "clearClientLevel", at = @At(value = "INVOKE", shift = At.Shift.AFTER, target = "Lnet/minecraft/client/gui/Gui;onDisconnected()V"))
	private final void onLocalPlayerQuit(class_437 screen, CallbackInfo ci) {
		final var lp = Objects.requireNonNull(player, "Missing 'LocalPlayer' instance");
		((class_310)(Object)this).execute(() -> ClientEvent.PLAYER_QUIT.invoker().invoke(lp));
	}
	// ==================================================
}
