package com.thecsdev.commonmc.client.mixin.hooks;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_6379;

@Mixin(class_437.class)
public interface AccessorScreen
{
	public @Accessor("minecraft") class_310 getMinecraft();
	public @Mutable @Accessor("title") void setTitle(class_2561 title);
	public @Accessor("renderables") List<class_4068> getRenderables();
	public @Accessor("children") List<class_364> getChildren();
	public @Accessor("narratables") List<class_6379> getNarratables();
}
