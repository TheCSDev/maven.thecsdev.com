package com.thecsdev.commonmc.mixin.events;

import com.mojang.brigadier.CommandDispatcher;
import com.thecsdev.commonmc.api.events.CommandEvent;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_7157;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2170.class)
public abstract class MixinCommands
{
	// ==================================================
	private @Final @Shadow CommandDispatcher<class_2168> dispatcher;
	// ==================================================
	@Inject(method = "<init>", at = @At(value = "INVOKE", target = "Lcom/mojang/brigadier/CommandDispatcher;setConsumer(Lcom/mojang/brigadier/ResultConsumer;)V"))
	private void onInit(class_2170.class_5364 sel, class_7157 ctx, CallbackInfo ci) {
		CommandEvent.INIT_COMMANDS.invoker().invoke(dispatcher, ctx, sel);
	}
	// ==================================================
}
