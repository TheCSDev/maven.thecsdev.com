package com.thecsdev.commonmc.mixin.events;

import com.thecsdev.commonmc.api.events.CreativeModeTabEvent;
import com.thecsdev.commonmc.api.world.item.TItemUtils;
import net.minecraft.class_7225;
import net.minecraft.class_7699;
import net.minecraft.class_7706;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = class_7706.class, priority = 9001)
public abstract class MixinCreativeModeTabs
{
	@Inject(method = "tryRebuildTabContents", at = @At("RETURN"))
	private static void onRebuildTabContents(
			class_7699 enabledFeatures,
			boolean operatorEnabled,
			class_7225.class_7874 lookup,
			CallbackInfoReturnable<Boolean> callback)
	{
		//do nothing if the update does not take place
		if(!callback.getReturnValueZ()) return;

		//rebuild the internal map and invoke the event
		TItemUtils.rebuildI2TMap();
		CreativeModeTabEvent.REBUILD_CONTENTS.invoker().invoke(enabledFeatures, operatorEnabled, lookup);
	}
}
