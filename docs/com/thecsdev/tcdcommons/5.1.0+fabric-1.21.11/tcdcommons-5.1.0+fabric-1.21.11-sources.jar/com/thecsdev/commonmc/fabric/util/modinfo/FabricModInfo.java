package com.thecsdev.commonmc.fabric.util.modinfo;

import com.thecsdev.commonmc.api.util.modinfo.ModInfo;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2477;
import net.minecraft.class_2561;
import org.jetbrains.annotations.NotNull;

import java.util.NoSuchElementException;

import static net.minecraft.class_2561.method_43470;
import static net.minecraft.class_2561.method_43469;

/**
 * Represents basic information about a currently installed mod
 * on the Fabric mod loader platform.
 */
public final class FabricModInfo extends ModInfo
{
	// ==================================================
	private final @NotNull class_2561 name;
	private final @NotNull String    version;
	// ==================================================
	public FabricModInfo(@NotNull String modid) throws NullPointerException, NoSuchElementException
	{
		super(modid);
		final var info = FabricLoader.getInstance().getModContainer(modid).orElseThrow();
		final var meta = info.getMetadata();
		final var lang = class_2477.method_10517();
		this.name      = lang.method_4678(modid) ? method_43471(modid) : method_43470(meta.getName());
		this.version   = meta.getVersion().getFriendlyString();
	}
	// ==================================================
	public final @Override @NotNull class_2561 getName() { return this.name; }
	public final @Override @NotNull String getVersion() { return this.version; }
	// ==================================================
}
