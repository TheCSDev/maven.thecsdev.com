package com.thecsdev.commonmc.api.client.gui.misc;

import com.thecsdev.common.properties.BooleanProperty;
import com.thecsdev.common.properties.DoubleProperty;
import com.thecsdev.common.properties.NotNullProperty;
import com.thecsdev.common.util.annotations.Virtual;
import com.thecsdev.commonmc.TCDCommonsConfig;
import com.thecsdev.commonmc.api.client.events.ClientEvent;
import com.thecsdev.commonmc.api.client.gui.TElement;
import com.thecsdev.commonmc.api.client.gui.render.TGuiGraphics;
import com.thecsdev.commonmc.world.sandbox.SandboxLevel;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import static com.thecsdev.commonmc.TCDCommons.LOGGER;
import static net.minecraft.world.entity.EntitySpawnReason.MOB_SUMMONED;

/**
 * {@link TElement} that renders an entity on the screen.
 */
@Environment(EnvType.CLIENT)
public @Virtual class TEntityElement extends TElement
{
	// ================================================== ==================================================
	//                                     TEntityElement IMPLEMENTATION
	// ================================================== ==================================================
	private final NotNullProperty<EntityType<?>> entityType    = new NotNullProperty<>(EntityType.MARKER);
	private final BooleanProperty                followsCursor = new BooleanProperty(true);
	private final DoubleProperty                 entityScale   = new DoubleProperty(1d);
	// --------------------------------------------------
	private @Nullable Entity displayEntity; //used for rendering. 'null' = 'something went wrong'.
	private @Nullable Throwable displayError; //used for debugging
	// ==================================================
	public TEntityElement(@NotNull EntityType<?> entityType) {
		this();
		this.entityType.set(entityType, TEntityElement.class);
	}
	public TEntityElement() {
		//this element should not be focusable or hoverable
		focusableProperty().set(false, TEntityElement.class);
		hoverableProperty().set(false, TEntityElement.class);
		//automatic display data refreshing when relevant properties update
		boundsProperty().addChangeListener((_, o, n) -> { if(!o.hasSameSize(n)) refresh(); });
		this.entityType.addChangeListener((_, _, _) -> refresh());
		//the initial display data refresh
		refresh();
	}
	// --------------------------------------------------
	/**
	 * Refreshes the {@link #displayEntity} value. Called automatically
	 * whenever {@link #entityTypeProperty()} value changes.
	 */
	private final @ApiStatus.Internal void refresh()
	{
		try {
			this.displayError  = null;
			this.displayEntity = EntityProvider.getOrCreate(this.entityType.get());
		} catch(Exception e) {
			this.displayError  = e;
			this.displayEntity = null;
			if(TCDCommonsConfig.FLAG_DEV_ENV)
				LOGGER.error("Failed to create GUI entity instance for {}", this.entityType.get(), e);
		}
	}
	// ==================================================
	/**
	 * Returns the {@link NotNullProperty} holding the {@link EntityType}
	 * that is to be rendered by this {@link TEntityElement}.
	 */
	public final NotNullProperty<EntityType<?>> entityTypeProperty() { return this.entityType; }

	/**
	 * Returns the {@link BooleanProperty} that determines whether
	 * this the rendered {@link Entity}'s on-screen rotation follows
	 * the cursor location.
	 */
	public final BooleanProperty followsCursorProperty() { return this.followsCursor; }

	/**
	 * Returns the {@link DoubleProperty} that determines the scale
	 * at which the rendered {@link Entity} is drawn.
	 */
	public final DoubleProperty entityScaleProperty() { return this.entityScale; }
	// ==================================================
	/**
	 * Returns the {@link Throwable} that was thrown during the last attempt
	 * to create and/or render the display {@link Entity}, if any.
	 * <p>
	 * This is usually used for debugging purposes, as some modded entities
	 * do not support being rendered on-screen, and will throw when attempts
	 * are made to create and/or render them. In such cases, this method can
	 * be used to retrieve the exception that was thrown.
	 */
	public final @Nullable Throwable getDisplayError() { return this.displayError; }
	// --------------------------------------------------
	/**
	 * Cached {@link Entity} instance used by this {@link TEntityElement} for
	 * rendering said {@link Entity} on the GUI screen.
	 * <p>
	 * This value is assigned automatically. You should avoid trying to set
	 * this value, instead only read it in case you are overriding
	 * {@link #renderCallback(TGuiGraphics)}.
	 * <p>
	 * In addition, this value is {@code null} whenever something goes wrong
	 * when attempting to create and/or render the {@link Entity} instance.
	 * This is usually due to {@link Exception}s being raised during attempts
	 * to render the display {@link Entity}.
	 *
	 * @see #renderCallback(TGuiGraphics)
	 * @see EntityProvider
	 */
	public final @Nullable Entity getDisplayEntity() { return this.displayEntity; }
	// ==================================================
	public @Virtual @Override void renderCallback(@NotNull TGuiGraphics pencil)
	{
		final var bb = this.getBounds();
		if(this.displayEntity != null)
		{
			pencil.pushScissors(bb.x, bb.y, bb.width, bb.height);
			try {
				//attempt to render the entity (some modded ones can and do throw)
				pencil.renderEntity(
						this.displayEntity, bb.x, bb.y, bb.width, bb.height,
						this.entityScale.getD(), this.followsCursor.getZ());
			} catch(Exception e) {
				//kill the rendering if something goes wrong, as some modded entities
				//do not support being drawn on-screen. that is unfortunate
				if(TCDCommonsConfig.FLAG_DEV_ENV)
					LOGGER.error("Failed to render GUI Entity {}", this.displayEntity, e);
				this.displayError  = e;
				this.displayEntity = null;
			}
			pencil.popScissors();
		} else {
			pencil.drawMissingNo(bb.x, bb.y, bb.width, bb.height, -1);
		}
	}
	// ================================================== ==================================================
	//                                     EntityProvider IMPLEMENTATION
	// ================================================== ==================================================
	/**
	 * Utility class for providing {@link Entity} instances for rendering in GUIs.
	 * These entities do not exist in a "real" {@link Level}. Instead, this uses a
	 * sandbox {@link Level} to create entities in.
	 */
	public static final @ApiStatus.Internal class EntityProvider
	{
		// ==================================================
		private static int NEXT_ID = 1048576;
		// --------------------------------------------------
		private static final Map<EntityType<?>, Object> CACHE = new HashMap<>();
		// ==================================================
		private EntityProvider() {}
		static {
			//clear cache when world-related events happen
			ClientEvent.PLAYER_JOIN.addListener(_ -> CACHE.clear());
			ClientEvent.PLAYER_QUIT.addListener(_ -> CACHE.clear());
			ClientEvent.LEVEL_INIT.addListener(_ -> CACHE.clear());
		}
		// ==================================================
		/**
		 * Returns an instance of the given {@link EntityType}.
		 * @param entityType The {@link EntityType} to create an instance of.
		 * @param <E> The type of the {@link Entity}.
		 * @return An instance of the given {@link EntityType}.
		 * @throws NullPointerException If the argument is {@code null}.
		 * @throws RuntimeException If an error occurs during {@link Entity} instance creation.
		 */
		@SuppressWarnings("unchecked")
		public static final @NotNull <E extends Entity> E getOrCreate(@NotNull EntityType<E> entityType)
				throws NullPointerException, RuntimeException
		{
			//not null enforcement
			Objects.requireNonNull(entityType);

			//if a value is cached, use that (depending on what it is)
			final @Nullable var cached = CACHE.get(entityType);
			if(cached instanceof Entity)
				return (E) cached;
			else if(cached instanceof RuntimeException error)
				throw error; //yes, reusing exceptions because creating them is **VERY** expensive

			//create the entity if not done so before
			final var client = Minecraft.getInstance();

			if(entityType == EntityType.PLAYER) try {
				final var player = Objects.requireNonNull(client.player, "Missing 'Minecraft#player' instance");
				CACHE.put(entityType, player);
				return (E) player;
			} catch (Exception e) {
				final var error = new RuntimeException("Cannot render 'EntityType.PLAYER' without the 'Minecraft#player' instance", e);
				CACHE.put(entityType, error);
				throw error;
			}

			try {
				Level level = client.level;
				if(level == null) level = SandboxLevel.INSTANCE;

				final var entity = Objects.requireNonNull(
						entityType.create(level, MOB_SUMMONED),
						"'EntityType#create(...)' returned 'null' for " + entityType);
				entity.setId(nextEntityId());
				CACHE.put(entityType, entity);
				return entity;
			} catch (Exception e) {
				final var error = new RuntimeException("Failed to create 'Entity' instance of type " + entityType, e);
				CACHE.put(entityType, error);
				throw error;
			}
		}
		// --------------------------------------------------
		/**
		 * Generate next ID integer for a created {@link Entity} instance.
		 * @see Entity#setId(int)
		 */
		private static final int nextEntityId() {
			NEXT_ID++;                               //increment next id
			if(NEXT_ID < 1048576) NEXT_ID = 1048576; //counteract overflows (values '< 1' are prohibited)
			return NEXT_ID;                          //return next id
		}
		// ==================================================
	}
	// ================================================== ==================================================
}
