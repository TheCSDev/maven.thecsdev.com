package com.thecsdev.commonmc.resource;

import com.thecsdev.common.util.annotations.Reflected;
import net.minecraft.network.chat.MutableComponent;

import static net.minecraft.network.chat.Component.translatable;

/**
 * Language texts for {@link com.thecsdev.commonmc.TCDCommons}.
 */
public final class TLanguage
{
	// ==================================================
	private TLanguage() {}
	// ==================================================
	public static final MutableComponent mmName_tcdcommons() { return translatable("modmenu.nameTranslation.tcdcommons"); }
	public static final MutableComponent mmSummary_tcdcommons() { return translatable("modmenu.summaryTranslation.tcdcommons"); }
	// --------------------------------------------------
	public static final @Reflected MutableComponent config_propertyValue() { return translatable("tcdcommons.config.property_value"); }
	public static final @Reflected MutableComponent config_common() { return translatable("tcdcommons.config.common"); }
	public static final @Reflected MutableComponent config_client() { return translatable("tcdcommons.config.client"); }
	public static final @Reflected MutableComponent config_client_updateItemGroupsOnJoin() { return translatable("tcdcommons.config.client.update_item_groups_on_join"); }
	public static final @Reflected MutableComponent config_client_updateItemGroupsOnJoin_tooltip() { return translatable("tcdcommons.config.client.update_item_groups_on_join.tooltip"); }
	public static final @Reflected MutableComponent config_server() { return translatable("tcdcommons.config.server"); }
	// --------------------------------------------------
	public static final            MutableComponent gui_screen_textDialog_defaultTitle() { return translatable("tcdcommons.gui.screen.text_dialog.default_title"); }
	public static final @Reflected MutableComponent gui_screen_textDialog_errorTitle() { return translatable("tcdcommons.gui.screen.text_dialog.error_title"); }
	// --------------------------------------------------
	public static final MutableComponent gui_dropdown_defaultLabel() { return translatable("tcdcommons.gui.dropdown.default_label"); }
	// --------------------------------------------------
	public static final MutableComponent gui_fileChooser_mode_explore() { return translatable("tcdcommons.gui.filechooser.mode.explore"); }
	public static final MutableComponent gui_fileChooser_mode_chooseFile() { return translatable("tcdcommons.gui.filechooser.mode.choose_file"); }
	public static final MutableComponent gui_fileChooser_mode_createFile() { return translatable("tcdcommons.gui.filechooser.mode.create_file"); }
	public static final MutableComponent gui_fileChooser_quickAccess() { return translatable("tcdcommons.gui.filechooser.quick_access"); }
	public static final MutableComponent gui_fileChooser_quickAccess_mountPoints() { return translatable("tcdcommons.gui.filechooser.quick_access.mount_points"); }
	public static final MutableComponent gui_fileChooser_ctxmenu_select() { return translatable("tcdcommons.gui.filechooser.ctxmenu.select"); }
	public static final MutableComponent gui_fileChooser_ctxmenu_open() { return translatable("tcdcommons.gui.filechooser.ctxmenu.open"); }
	public static final MutableComponent gui_fileChooser_ctxmenu_openWith() { return translatable("tcdcommons.gui.filechooser.ctxmenu.open_with"); }
	public static final MutableComponent gui_fileChooser_ctxmenu_openWith_assocApp() { return translatable("tcdcommons.gui.filechooser.ctxmenu.open_with.assoc_app"); }
	public static final MutableComponent gui_fileChooser_action_fileName() { return translatable("tcdcommons.gui.filechooser.action.file_name"); }
	public static final MutableComponent gui_fileChooser_action_fileType() { return translatable("tcdcommons.gui.filechooser.action.file_type"); }
	// --------------------------------------------------
	public static final @Reflected MutableComponent misc_loading() { return translatable("tcdcommons.misc.loading"); }
	public static final @Reflected MutableComponent misc_somethingWentWrong() { return translatable("tcdcommons.misc.something_went_wrong"); }
	public static final @Reflected MutableComponent misc_comingSoon() { return translatable("tcdcommons.misc.coming_soon"); }
	public static final @Reflected MutableComponent misc_preview() { return translatable("tcdcommons.misc.preview"); }
	public static final @Reflected MutableComponent misc_from() { return translatable("tcdcommons.misc.from"); }
	public static final @Reflected MutableComponent misc_to() { return translatable("tcdcommons.misc.to"); }
	// ==================================================
}
