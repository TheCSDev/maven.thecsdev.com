package com.thecsdev.commonmc.resource;

import com.thecsdev.common.util.annotations.Reflected;
import com.thecsdev.commonmc.TCDCommons;
import com.thecsdev.commonmc.api.client.gui.misc.TTextureElement;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.data.AtlasIds;
import net.minecraft.resources.Identifier;

import static com.thecsdev.commonmc.TCDCommons.MOD_ID;
import static net.minecraft.resources.Identifier.fromNamespaceAndPath;


/**
 * {@link TCDCommons}'s {@link Identifier}s for {@link TextureAtlasSprite}s.
 * @see AtlasIds
 * @see TextureAtlasSprite
 * @see TTextureElement.Mode#GUI_SPRITE
 */
public class TSprites
{
	// ==================================================
	private TSprites() {}
	// ==================================================
	public static final Identifier gui_widget_dropdownCollapsed() { return fromNamespaceAndPath(MOD_ID, "widget/dropdown_collapsed"); }
	public static final Identifier gui_widget_dropdownExpanded() { return fromNamespaceAndPath(MOD_ID, "widget/dropdown_expanded"); }
	// --------------------------------------------------
	public static final Identifier gui_widget_togglebtn() { return fromNamespaceAndPath(MOD_ID, "widget/togglebtn"); }
	public static final Identifier gui_widget_togglebtnDisabled() { return fromNamespaceAndPath(MOD_ID, "widget/togglebtn_disabled"); }
	public static final Identifier gui_widget_togglebtnHighlighted() { return fromNamespaceAndPath(MOD_ID, "widget/togglebtn_highlighted"); }
	public static final Identifier gui_widget_togglebtnToggled() { return fromNamespaceAndPath(MOD_ID, "widget/togglebtn_toggled"); }
	public static final Identifier gui_widget_togglebtnToggledDisabled() { return fromNamespaceAndPath(MOD_ID, "widget/togglebtn_toggled_disabled"); }
	public static final Identifier gui_widget_togglebtnToggledHighlighted() { return fromNamespaceAndPath(MOD_ID, "widget/togglebtn_toggled_highlighted"); }
	// --------------------------------------------------
	public static final Identifier gui_popup_ctxmenu() { return fromNamespaceAndPath(MOD_ID, "popup/ctxmenu"); }
	public static final Identifier gui_popup_ctxmenuHighlighted() { return fromNamespaceAndPath(MOD_ID, "popup/ctxmenu_highlighted"); }
	public static final Identifier gui_popup_shadow() { return fromNamespaceAndPath(MOD_ID, "popup/shadow"); }
	// --------------------------------------------------
	public static final Identifier gui_icon_clipboard() { return fromNamespaceAndPath(MOD_ID, "icon/clipboard"); }
	// --------------------------------------------------
	public static final            Identifier gui_icon_fsFile() { return fromNamespaceAndPath(MOD_ID, "icon/fs_file"); }
	public static final            Identifier gui_icon_fsFileImage() { return fromNamespaceAndPath(MOD_ID, "icon/fs_file_image"); }
	public static final            Identifier gui_icon_fsFileTxt() { return fromNamespaceAndPath(MOD_ID, "icon/fs_file_txt"); }
	public static final            Identifier gui_icon_fsFileJson() { return fromNamespaceAndPath(MOD_ID, "icon/fs_file_json"); }
	public static final @Reflected Identifier gui_icon_fsFolder() { return fromNamespaceAndPath(MOD_ID, "icon/fs_folder"); }
	public static final            Identifier gui_icon_fsFolderGray() { return fromNamespaceAndPath(MOD_ID, "icon/fs_folder_gray"); }
	// ==================================================
}
