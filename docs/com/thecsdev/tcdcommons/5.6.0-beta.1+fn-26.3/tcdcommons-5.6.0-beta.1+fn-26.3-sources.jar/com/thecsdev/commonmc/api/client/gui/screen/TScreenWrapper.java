package com.thecsdev.commonmc.api.client.gui.screen;

import com.thecsdev.common.math.Bounds2i;
import com.thecsdev.common.util.annotations.Virtual;
import com.thecsdev.commonmc.api.client.gui.TElement;
import com.thecsdev.commonmc.api.client.gui.render.TGuiGraphics;
import com.thecsdev.commonmc.api.client.gui.util.TGuiUtils;
import com.thecsdev.commonmc.api.client.gui.util.TInputContext;
import com.thecsdev.commonmc.client.mixin.hooks.AccessorTElement;
import io.netty.util.internal.UnstableApi;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;
import java.util.Optional;

import static com.thecsdev.commonmc.TCDCommons.LOGGER;
import static com.thecsdev.commonmc.TCDCommonsConfig.FLAG_DEV_ENV;
import static com.thecsdev.commonmc.api.client.gui.util.TGuiUtils.*;
import static java.lang.System.nanoTime;
import static org.lwjgl.sdl.SDLMouse.SDL_BUTTON_RIGHT;
import static org.lwjgl.sdl.SDLScancode.*;

/**
 * The {@link TScreenWrapper} serves as an adapter for the {@link TScreen}
 * class. This class extends the game's {@link Screen} class and translates
 * calls from the game's engine into calls on the {@link TScreen} instances.
 *
 * <p>The purpose of this class is to isolate {@link TScreen} from Minecraft's
 * GUI code, making the mod more resilient to changes in the game's code. This
 * isolation makes {@link TScreen} act like a {@link Screen}, but in a more controlled
 * and independent way, similar to how custom rendering engines interact with rendering APIs.
 *
 * <p>This class should remain thin, serving only as a pass-through layer to
 * {@link TScreen}. All interactions with the {@link Screen} class that the mod
 * needs should be encapsulated within this class, keeping {@link TScreen}
 * unaware of the game's GUI code.
 *
 * @apiNote {@link UnstableApi}. Changes to the game's code, as well as the
 * default {@link TScreenWrapper} implementation, may cause disruptions.
 */
@UnstableApi
@Environment(EnvType.CLIENT)
public @Virtual class TScreenWrapper<T extends TScreen> extends Screen
{
	// ==================================================
	private final @NotNull T target;
	// ==================================================
	protected TScreenWrapper(@NotNull T target) {
		super(Component.empty());
		this.target = Objects.requireNonNull(target);
	}
	// --------------------------------------------------
	public @Override String toString() {
		final var bb = this.target.getBounds();
		return String.format("%s[x=%d,y=%d,width=%d,height=%d]",
				super.toString(), bb.x, bb.y, bb.width, bb.height);
	}
	// ==================================================
	/**
	 * Returns the {@link #target} {@link TScreen} for this {@link TScreenWrapper}.
	 */
	public final @NotNull T getTargetTScreen() { return this.target; }

	/**
	 * Returns the {@link Minecraft} client instance that last opened
	 * this {@link Screen}, if any.
	 */
	public final @NotNull Minecraft getClient() { return this.minecraft; }
	// ==================================================
	/** @see TScreen#isAllowingInGameHud() */
	public final boolean isAllowingInGameHud() { return this.target.isAllowingInGameHud(); }
	// ==================================================
	//escape is handled independently in this framework
	public final @Override boolean shouldCloseOnEsc() { return false; }
	public final @Override boolean isPauseScreen() { return this.target.isPauseScreen(); }
	// --------------------------------------------------
	//note: the game should rename this method to #close(). current name "onClose" is confusing
	//      because it implies the screen had been closed by now when that's not the case.
	public final @Override void onClose() { //(intentionally overrides 'super')
		if(this.target.isOpen()) this.target.close();
	}
	// ==================================================
	public final @Override void added() {
		this.minecraft.schedule(() -> {
			if(this.minecraft.gui.screen() == this) this.target.openCallback();
		});
	}
	// --------------------------------------------------
	protected final @Override void init() {
		this.minecraft.schedule(() -> {
			//if(this.minecraft.gui.screen() != this) return; -- line dropped; breaks hud-screens
			//begin measuring initialization time
			final var ns = nanoTime();
			//trigger (re/)initialization by updating the bounds
			this.target.boundsProperty().getHandle().set(Bounds2i.ZERO); //so next call triggers change listeners
			this.target.setBounds(0, 0, this.width, this.height);        //<- this now triggers change listeners
			//initialize super
			super.init();
			//log initialization time
			if(FLAG_DEV_ENV)
				LOGGER.info("Initialized '{}' in {}ns.", this.target.getClass(), nanoTime() - ns);
		});
	}
	// --------------------------------------------------
	public final @Override void removed() {
		this.minecraft.schedule(() -> {
			//do nothing in case something reopened this screen by the time this method got called
			if(this.minecraft.gui.screen() == this) return;

			//invoke the corresponding callback method
			this.target.closeCallback();

			//FIXME - Hacky workaround for allowing "last/previous screens" to be rendered in the background.
			//        Problem is that this workaround enables a route thru which #clear() is never called.
			//if this screen is not the "last/previous screen" of another currently opened screen,
			//clear all children to trigger any cleanup logic they may hold
			final @Nullable var lsp = ILastScreenProvider.getCurrent(this.minecraft);
			if(lsp == null || lsp.getLastScreen() != this)
				this.target.clear(); //trigger any cleanup tasks - has chance to not be called
		});
	}
	// ==================================================
	public final @Override void tick() {
		((AccessorTElement)(Object)this.target)._tick();
		super.tick();
	}
	public final @Override void extractRenderState(@NotNull GuiGraphicsExtractor context, int mouseX, int mouseY, float deltaTicks) {
		final var tgg = TGuiGraphics.createInstance(context, mouseX, mouseY, deltaTicks);
		tgg.renderTScreen(this.target);
		super.extractRenderState(context, mouseX, mouseY, deltaTicks);
	}
	// ==================================================
	public final @Override boolean keyPressed(@NotNull KeyEvent e) {
		if(super.keyPressed(e)) return true;
		else if(sendInput(TInputContext.ofKeyPress(e.keycode(), e.input(), e.modifiers()))) return true;
		else {
			//FIXME - REPLACE THIS BAND-AID CODE WITH PROPER SDL 'TYPING' HANDLING
			final var typedChar = getCharFromSdlScancode(e.input(), isShiftDown(), isCapsLockOn(), isNumLockOn());
			return typedChar != 0 && sendInput(TInputContext.ofCharType(typedChar, 0));
		}
	}
	public final @Override boolean keyReleased(@NotNull KeyEvent e) {
		if(super.keyReleased(e)) return true;
		else return sendInput(TInputContext.ofKeyRelease(e.keycode(), e.input(), e.modifiers()));
	}
	/*public final @Override boolean charTyped(@NotNull CharacterEvent e) { -- they changed something here
		if(super.charTyped(e)) return true;
		else return sendInput(TInputContext.ofCharType((char) e.codepoint(), 0));
	}*/
	// --------------------------------------------------
	public final @Override boolean mouseClicked(@NotNull MouseButtonEvent e, boolean doubled) {
		if(super.mouseClicked(e, doubled)) return true;
		else return sendInput(TInputContext.ofMousePress(e.x(), e.y(), e.button(), e.modifiers()));
	}
	public final @Override boolean mouseReleased(@NotNull MouseButtonEvent e) {
		if(super.mouseReleased(e)) return true;
		else return sendInput(TInputContext.ofMouseRelease(e.x(), e.y(), e.button(), e.modifiers()));
	}
	public final @Override void mouseMoved(double mouseX, double mouseY) {
		super.mouseMoved(mouseX, mouseY);
		sendInput(TInputContext.ofMouseMove(mouseX, mouseY));
	}
	public final @Override boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		if(super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount)) return true;
		else return sendInput(TInputContext.ofMouseScroll(mouseX, mouseY, horizontalAmount, verticalAmount));
	}
	public final @Override boolean mouseDragged(@NotNull MouseButtonEvent e, double deltaX, double deltaY) {
		if(super.mouseDragged(e, deltaX, deltaY)) return true;
		else return sendInput(TInputContext.ofMouseDrag(e.x(), e.y(), e.button(), deltaX, deltaY));
	}
	// ==================================================
	/**
	 * Emulates a user input event for this {@link TScreen}.
	 * @param context Information about the user's input.
	 * @return {@code true} if the input event was handled by a GUI element.
	 * @apiNote Does not affect the native GUI. Is {@link ApiStatus.Internal} and may change.
	 */
	//FIXME - Extremely high priority. I urgently need a "set in stone" input handling contract.
	//        I keep finding myself needing to tweak input handling. I need standardization.
	@ApiStatus.Internal
	@SuppressWarnings("DataFlowIssue")
	final boolean sendInput(TInputContext context)
	{
		//calculate hovered element for mouse-related inputs
		if(context.getInputType().isMouse()) {
			final @Nullable Double mouseX = context.getMouseX();
			final @Nullable Double mouseY = context.getMouseY();
			if(mouseX != null && mouseY != null)
				this.target.hovered.set(
						this.target.findElementAt(
								(int)mouseX.doubleValue(),
								(int)mouseY.doubleValue()),
						TScreenWrapper.class);
		}

		//broadcast phase
		this.target.inputCallback(TInputContext.InputDiscoveryPhase.BROADCAST, context);
		this.target.forEach(child -> child.inputCallback(TInputContext.InputDiscoveryPhase.BROADCAST, context), true);

		//preempt phase
		if(this.target.inputCallback(TInputContext.InputDiscoveryPhase.PREEMPT, context))
			return true;
		else if(this.target.findChild(child -> child.inputCallback(TInputContext.InputDiscoveryPhase.PREEMPT, context), true).isPresent())
			return true;

		//main phase
		switch(context.getInputType())
		{
			//mouse-press goes to the hovered element.
			case MOUSE_PRESS:
			{
				//TODO - Mouse click should bubble to hovered elements, not to parent elements!
				//mouse-press is sent to hovered element, with bubbling-to-parents logic
				final @Nullable var handled = sendInputBubbleMain(context, target.hovered.get());
				//element that handles the input becomes focused and dragged. no handling clears focus
				this.target.focused.set((handled instanceof TElement handledE) ?
						(handledE.isFocusable() ? handledE : null) : null,
						TScreenWrapper.class);
				this.target.dragged.set(handled, TScreenWrapper.class); //FIXME - Keep track of which mouse button is dragging an element. Right now all button releases can end the drag.
				//true is returned if an element did handle the input
				if(handled != null) return true; else break;
			}

			//mouse-drag goes to the dragged element,
			case MOUSE_DRAG: {
				final @Nullable var draggedEl = this.target.dragged.get();
				if(draggedEl != null && draggedEl.inputCallback(TInputContext.InputDiscoveryPhase.MAIN, context))
					return true;
				else break;
			}
			//mouse-release goes to the focused element
			case MOUSE_RELEASE: //INTENTIONAL! MOUSE RELEASE WILL FIRE ON FOCUSED ELEMENTS REGARDLESS OF HOVER!
			//key-press, key-release, and char-type go to focused element
			case KEY_PRESS:
			case KEY_RELEASE:
			case CHAR_TYPE:
			{
				//mouse release clears dragged element
				if(context.getInputType() == TInputContext.InputType.MOUSE_RELEASE) {
					//clear the dragged element, but do keep track of what element that was
					final @Nullable var dragged = this.target.dragged.get();
					this.target.dragged.set(null, TScreenWrapper.class);
					//then, if the dragged element does not have any focus, send mouse release
					//input to it (if focused, it will get that input anyway. here we just make
					//sure it gets the input in cases where it's not focused)
					if(dragged != null && this.target.focused.get() != dragged)
						dragged.inputCallback(TInputContext.InputDiscoveryPhase.MAIN, context);
				}
				//forward the input to the focused element or the target screen
				final var focusedEl = Optional.ofNullable(this.target.focused.get()).orElse(this.target);
				//if(focusedEl.inputCallback(TInputContext.InputDiscoveryPhase.MAIN, context))
				if(sendInputBubbleMain(context, focusedEl) != null)
					return true;
				else break;
			}

			//mouse-scroll goes to the hovered element
			case MOUSE_SCROLL:
			{
				//TODO - Mouse scroll should bubble to hovered elements, not to parent elements!
				//mouse-scroll is sent to hovered element, with bubbling-to-parents logic
				final @Nullable var handled = sendInputBubbleMain(context, target.hovered.get());
				//true is returned if an element did handle the input
				if(handled != null) return true; else break;
			}

			//not handled yet? this is the end. return false
			default: break;
		}

		//additional key-press logic
		if(context.getInputType() == TInputContext.InputType.KEY_PRESS)
		{
			//handle tab-navigation
			if(context.getScanCode() == SDL_SCANCODE_TAB)
			{
				//prepare for navigation
				final var          forward = !isShiftDown();
				@Nullable TElement current = this.target.focused.get();

				//determine next element that will gain focus
				if(current == null)
					current = forward ?
						TGuiUtils.nextFocusableTElement(this.target, true) :
						TGuiUtils.previousFocusableTElement(this.target, true);
				else
					current = forward ?
							TGuiUtils.nextFocusableTElement(current, false) :
							TGuiUtils.previousFocusableTElement(current, false);

				//assign focus, and return true
				this.target.focused.set(current, TScreenWrapper.class);
				return true;
			}
			//handle context menu key
			else if(context.getScanCode() == SDL_SCANCODE_APPLICATION) {
				//attempt to show the context menu of the focused element
				final @Nullable var focused = this.target.focused.get();
				if(focused != null && focused.showContextMenu() != null)
					return true; //return ONLY IF successful, no returning false!
			}
			//handle closing on escape
			else if(context.getScanCode() == SDL_SCANCODE_ESCAPE) { onClose(); return true; }
		}

		//additional mouse-press logic
		else if(context.getInputType() == TInputContext.InputType.MOUSE_PRESS) {
			//noinspection DataFlowIssue - handle right-clicking for opening context-menus
			if(context.getMouseButton() == SDL_BUTTON_RIGHT) {
				//attempt to show the context menu of the hovered element
				final @Nullable var hovered = this.target.hovered.get();
				if(hovered != null && hovered.showContextMenu() != null)
					return true; //return ONLY IF successful, no returning false!
			}
		}

		//default outcome; not handled
		return false;
	}

	/**
	 * {@link ApiStatus.Internal} method that sends an input to a {@link TElement}, bubbling
	 * the input to its parents if said element does not handle the input.
	 * @apiNote Uses {@link TInputContext.InputDiscoveryPhase#MAIN}.
	 */
	@ApiStatus.Internal
	private static final TElement sendInputBubbleMain(TInputContext context, @Nullable TElement element)
	{
		//null checks
		if(element == null) return null;

		//forward input to element, handling bubbling if element doesn't handle it
		while(element != null && !element.inputCallback(TInputContext.InputDiscoveryPhase.MAIN, context))
			element = element.getParent();

		//return element that handled the input, or null if none handled it
		return element;
	}
	// ==================================================
	/**
	 * Band-Aid method that helps {@link #keyPressed(KeyEvent)} emit "character typed" events.<br>
	 * FIXME - Implement proper typing handling functionality.
	 * @param sdlScanCode Pressed key SDL scan-code.
	 * @param isShiftDown Is shift key down?
	 * @param isCapsLockOn Is CapsLock turned on?
	 * @param isNumLockOn Is NumLock turned on?
	 * @return {@link Character} from SDL scan-code, or {@code 0} is character is not printable.
	 * @implNote Supports English keyboard layout only, which is problematic.
	 */
	@Deprecated
	@SuppressWarnings("DeprecatedIsStillUsed")
	public static final char getCharFromSdlScancode(
			int sdlScanCode,
			boolean isShiftDown, boolean isCapsLockOn, boolean isNumLockOn)
	{
		//handle [A to Z] keys
		if(sdlScanCode >= SDL_SCANCODE_A && sdlScanCode <= SDL_SCANCODE_Z) {
			final var isUppercase = isShiftDown ^ isCapsLockOn;
			final var baseChar    = (char) ('a' + (sdlScanCode - 4));
			return isUppercase ? Character.toUpperCase(baseChar) : baseChar;
		}

		//handle number keys [1 to 0]
		if(sdlScanCode >= SDL_SCANCODE_1 && sdlScanCode <= SDL_SCANCODE_0) {
			if(isShiftDown) {
				switch(sdlScanCode) {
					case SDL_SCANCODE_1: return '!';
					case SDL_SCANCODE_2: return '@';
					case SDL_SCANCODE_3: return '#';
					case SDL_SCANCODE_4: return '$';
					case SDL_SCANCODE_5: return '%';
					case SDL_SCANCODE_6: return '^';
					case SDL_SCANCODE_7: return '&';
					case SDL_SCANCODE_8: return '*';
					case SDL_SCANCODE_9: return '(';
					case SDL_SCANCODE_0: return ')';
				}
			} else {
				if(sdlScanCode == SDL_SCANCODE_0) return '0';
				return (char) ('1' + (sdlScanCode - SDL_SCANCODE_1));
			}
		}

		//punctuation and miscellaneous keys
		return switch(sdlScanCode)
		{
			//general punctuation keys
			case SDL_SCANCODE_SPACE        -> ' ';
			case SDL_SCANCODE_MINUS        -> isShiftDown ? '_' : '-';
			case SDL_SCANCODE_EQUALS       -> isShiftDown ? '+' : '=';
			case SDL_SCANCODE_LEFTBRACKET  -> isShiftDown ? '{' : '[';
			case SDL_SCANCODE_RIGHTBRACKET -> isShiftDown ? '}' : ']';
			case SDL_SCANCODE_BACKSLASH    -> isShiftDown ? '|' : '\\';
			case SDL_SCANCODE_SEMICOLON    -> isShiftDown ? ':' : ';';
			case SDL_SCANCODE_APOSTROPHE   -> isShiftDown ? '"' : '\'';
			case SDL_SCANCODE_GRAVE        -> isShiftDown ? '~' : '`'; //the key below 'Esc'
			case SDL_SCANCODE_COMMA        -> isShiftDown ? '<' : ',';
			case SDL_SCANCODE_PERIOD       -> isShiftDown ? '>' : '.';
			case SDL_SCANCODE_SLASH        -> isShiftDown ? '?' : '/';

			//numpad keys
			case SDL_SCANCODE_KP_DIVIDE    -> '/';
			case SDL_SCANCODE_KP_MULTIPLY  -> '*';
			case SDL_SCANCODE_KP_MINUS     -> '-';
			case SDL_SCANCODE_KP_PLUS      -> '+';
			case SDL_SCANCODE_KP_ENTER     -> '\n';
			case SDL_SCANCODE_KP_1         -> isNumLockOn ? '1' : (char) 0;
			case SDL_SCANCODE_KP_2         -> isNumLockOn ? '2' : (char) 0;
			case SDL_SCANCODE_KP_3         -> isNumLockOn ? '3' : (char) 0;
			case SDL_SCANCODE_KP_4         -> isNumLockOn ? '4' : (char) 0;
			case SDL_SCANCODE_KP_5         -> isNumLockOn ? '5' : (char) 0;
			case SDL_SCANCODE_KP_6         -> isNumLockOn ? '6' : (char) 0;
			case SDL_SCANCODE_KP_7         -> isNumLockOn ? '7' : (char) 0;
			case SDL_SCANCODE_KP_8         -> isNumLockOn ? '8' : (char) 0;
			case SDL_SCANCODE_KP_9         -> isNumLockOn ? '9' : (char) 0;
			case SDL_SCANCODE_KP_0         -> isNumLockOn ? '0' : (char) 0;
			case SDL_SCANCODE_KP_PERIOD    -> isNumLockOn ? '.' : (char) 0;
			case SDL_SCANCODE_KP_EQUALS    -> '=';

			//control characters
			//case SDL_SCANCODE_RETURN       -> '\n';
			//case SDL_SCANCODE_BACKSPACE    -> '\b';
			//case SDL_SCANCODE_TAB          -> '\t';

			default -> 0; //non-printable keys (F1 to F12, delete, arrows, etc.)
		};
	}
	// ==================================================
}
